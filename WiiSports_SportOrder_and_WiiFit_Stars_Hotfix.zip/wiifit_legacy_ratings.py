#!/usr/bin/env python3
"""Wii Fit Plus legacy exercise rating inspector / experimental editor.

The 144 one-byte per-Mii rating values are observed at:
    0x35CF + slot*0x9281 + legacy_board_index
The independent U32 personal-best scores are at:
    0x3661 + slot*0x9281 + 4*legacy_board_index

A Wii Fit Plus two-accumulator save checksum is stored at 0x4C198 and covers
[0,0x4C198). Outputs are separate decrypted FitPlus0/1.dat copies; does not
change top-10 rankings, other Miis or any unspecified metadata.

The exact in-game meaning of the 0..4 rating byte is not independently proven;
these are experimental fields, not a threshold-to-stars algorithm.

Usage:
 python wiifit_legacy_ratings.py inspect FitPlus0.dat 2 78
 python wiifit_legacy_ratings.py set FitPlus0.dat FitPlus1.dat 2 78 4 --out-folder new_pair
"""
from pathlib import Path
import argparse, struct

MII_STRIDE=0x9281
NUM_MIIS=8
NUM_BOARDS=144
RATING_BASE=0x35CF
PB_BASE=0x3661
CHECKSUM_OFFSET=0x4C198
FILE_BYTES=0x94000


def checksum(blob):
    if len(blob)!=FILE_BYTES or blob[:8]!=b'RPHE0000':
        raise ValueError('Expected 606208-byte Wii Fit Plus file with RPHE0000 signature')
    top=bottom=0
    for i in range(0,CHECKSUM_OFFSET,2):
        v=(blob[i]<<8)|blob[i+1]
        top=(top+v)&0xffff
        bottom=(bottom+(v^0xffff))&0xffff
    return (top<<16)|bottom

def verify(blob):
    stored=struct.unpack_from('>I',blob,CHECKSUM_OFFSET)[0]
    calc=checksum(blob)
    return stored==calc,stored,calc

def validate_slot(slot,board):
    if not 0<=slot<NUM_MIIS:raise ValueError('Mii slot must be 0–7')
    if not 0<=board<NUM_BOARDS:raise ValueError('Legacy board index must be 0–143')

def offsets(slot,board):
    validate_slot(slot,board)
    return slot*MII_STRIDE+RATING_BASE+board,slot*MII_STRIDE+PB_BASE+board*4

def inspect(blob,slot,board):
    r,p=offsets(slot,board)
    name=blob[slot*MII_STRIDE+8:slot*MII_STRIDE+30].decode('utf-16-be','replace').split('\0')[0]
    return {'slot':slot,'name':name,'board':board,'rating':blob[r],
            'pb':struct.unpack_from('>I',blob,p)[0],
            'rating_offset':f'0x{r:X}','pb_offset':f'0x{p:X}'}

def modify(blob,slot,board,level):
    if not 0<=level<=4:raise ValueError('Use experimental rating 0..4')
    if not verify(blob)[0]:raise ValueError('Original Wii Fit Plus checksum invalid; cannot safely patch')
    r,p=offsets(slot,board)
    out=bytearray(blob);out[r]=level
    struct.pack_into('>I',out,CHECKSUM_OFFSET,checksum(out))
    assert verify(out)[0]
    return bytes(out)

def main():
    parser=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawTextHelpFormatter)
    commands=parser.add_subparsers(dest='command',required=True)
    read=commands.add_parser('inspect');read.add_argument('file',type=Path);read.add_argument('slot',type=int);read.add_argument('board',type=int)
    write=commands.add_parser('set');write.add_argument('fitplus0',type=Path);write.add_argument('fitplus1',type=Path)
    write.add_argument('slot',type=int);write.add_argument('board',type=int);write.add_argument('rating',type=int)
    write.add_argument('--out-folder',required=True,type=Path)
    args=parser.parse_args()
    if args.command=='inspect':
        b=args.file.read_bytes()
        print('Checksum valid:',verify(b))
        print(inspect(b,args.slot,args.board))
        return
    b0=args.fitplus0.read_bytes();b1=args.fitplus1.read_bytes()
    if b0!=b1:raise ValueError('FitPlus0.dat and FitPlus1.dat differ; refusing to guess which to patch')
    result=modify(b0,args.slot,args.board,args.rating)
    if args.out_folder.exists():raise FileExistsError('Choose a new unused output folder to avoid overwriting saves')
    args.out_folder.mkdir(parents=True)
    (args.out_folder/'FitPlus0.dat').write_bytes(result)
    (args.out_folder/'FitPlus1.dat').write_bytes(result)
    before=inspect(b0,args.slot,args.board);after=inspect(result,args.slot,args.board)
    print('Before:',before,'After:',after,'valid checksum',verify(result)[0])
    print('Exported separate RAW pair. This is not an encrypted Wii SD data.bin or complete Dolphin NAND save.')

if __name__=='__main__':main()
