#!/usr/bin/env python3
"""Repair Wii Sports original sport-order labels in Wii Score Studio R9-R14.

The known binary float offsets are unchanged; only the sport->offset mapping is
corrected from a *user in-game validation*. Backups are created automatically.

Storage index:   0         1       2       3       4
Actual sport:    Baseball  Tennis  Boxing  Bowling  Golf
Previously shown Tennis    Baseball Bowling Golf    Boxing

Uses exact syntax rewriting with conservative aborts. Retains MAX_KNOWN
numerical preset values by *sport name*, not storage index, so prior thresholds
remain associated with the actual sport.
"""
from __future__ import annotations
import ast
import argparse
from pathlib import Path
import shutil

OLD = ('Tennis','Baseball','Bowling','Golf','Boxing')
NEW = ('Baseball','Tennis','Boxing','Bowling','Golf')

def patch(path: Path, dry_run=False):
    tree=ast.parse(path.read_text(encoding='utf-8'))
    matches=[]
    for node in tree.body:
        if not isinstance(node, ast.Assign):continue
        if any(isinstance(target,ast.Name) and target.id=='SKILLS' for target in node.targets):
            try: value=tuple(ast.literal_eval(node.value))
            except (ValueError,TypeError): continue
            matches.append((node, value))
    if len(matches)!=1:
        raise RuntimeError(f'{path.name}: expected exactly one top-level SKILLS tuple, found {len(matches)}')
    node, value=matches[0]
    if value==NEW:
        print(f'{path.name}: already corrected; unchanged')
        return False
    if value!=OLD:
        raise RuntimeError(f'{path.name}: unexpected sport ordering {value!r}; refusing to edit')
    txt=path.read_text(encoding='utf-8')
    lines=txt.splitlines(keepends=True)
    if node.lineno!=node.end_lineno:
        raise RuntimeError('Multiline SKILLS definition unsupported; refusing to rewrite')
    line=lines[node.lineno-1]
    # Only replace the assigned value substring using AST character positions.
    a=node.value.col_offset;b=node.value.end_col_offset
    original=line[a:b]
    if tuple(ast.literal_eval(original))!=OLD:
        raise RuntimeError('AST/line mismatch; refusing edit')
    replacement="('Baseball', 'Tennis', 'Boxing', 'Bowling', 'Golf')"
    lines[node.lineno-1]=line[:a]+replacement+line[b:]
    result=''.join(lines)
    compile(result,str(path),'exec')
    if dry_run:
        print(f'{path.name}: would change {value} -> {NEW}; no files changed')
        return True
    backup=path.with_suffix(path.suffix+'.before_sport_fix')
    if backup.exists():raise FileExistsError(f'Backup already exists: {backup}; refusing overwrite')
    shutil.copy2(path,backup)
    path.write_text(result,encoding='utf-8')
    print(f'{path.name}: corrected sport mapping; backed up to {backup.name}')
    return True

def main():
    p=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('studio_folder',type=Path,help='Extracted Wii Score Studio installation folder')
    p.add_argument('--dry-run',action='store_true')
    args=p.parse_args()
    root=args.studio_folder
    target=root/'WS_Original.py'
    if not target.is_file():p.error(f'Cannot find {target}. Select the directory with WS_Original.py.')
    training=root/'WS_Training_Medals.py'
    if training.exists():
        src=training.read_text(encoding='utf-8')
        # Critical: R14 training file imports SKILLS from WS_Original and the
        # TRAININGS mapping is keyed by actual sport names, so no replacement
        # of its labels or offsets is needed. We verify it does this.
        if 'from WS_Original import' not in src or 'SKILLS' not in src or 'SPORT_STRIDE' not in src:
            p.error('Training medal module uses an unexpected sport mapping. Aborting.')
    patch(target,args.dry_run)
    print('Note: Golf is index 4, Bowling index 3, Boxing index 2, Tennis index 1, Baseball index 0.')
    print('MAX_KNOWN / preset values are keyed by sport name and must remain unchanged.')
    print('The training rank/played counters use this corrected sport index too; their labels still need independent game-side validation.')

if __name__=='__main__':main()
