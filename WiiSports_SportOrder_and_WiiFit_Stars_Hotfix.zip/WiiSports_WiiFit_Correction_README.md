# Wii Score Studio R14 corrections — November 2026

## Original Wii Sports actual binary sport order (tested on hardware)

Old editor incorrectly assumed: Tennis, Baseball, Bowling, Golf, Boxing.

**Actual index 0..4: Baseball, Tennis, Boxing, Bowling, Golf.**

| Index | Actual sport | Correct user-verified natural skill maximum | Float32 exact preset |
|---|---|---|---|
| 0 | Baseball | 3368 | 45528324 |
| 1 | Tennis | 2399 | 4515FFF6 |
| 2 | Boxing | 3124 | 45434FFF |
| 3 | Bowling | 2213 | 450A5FFF |
| 4 | Golf | 3462 | 4558653D |

Apply `python apply_ws_r14_sport_mapping_fix.py path/to/your/extracted/Wii_Score_Studio_R14` or run with `--dry-run`. It backs up `WS_Original.py` and changes its single `SKILLS` definition. Do not change `MAX_KNOWN` numeric presets, which are keyed by the actual sport name. In R14 `WS_Training_Medals.py` imports SKILLS, so this also corrects which 0x79-byte sport record each training medal edit targets. **Training activity order within each sport is still inferred and not independently verified.** The exact float32 skill/medal bytes and global save checksum rules are unchanged.

## Wii Fit Plus independent ratings

A candidate 144-byte legacy activity rating array starts at per-Mii offset `0x35CF`; each legacy activity board uses one unsigned byte in 0..4. PB U32 starts at `0x3661`, with 4 bytes per board. At the Dance Yoga board index 78, Vincenzo slot 2 has PB 91 at `0x3799` (relative) and rating 4 at `0x361D` (relative). Changing a worldwide top-ten score alone does NOT update either per-Mii field.

Across eight profiles and 144 slots each in the provided Wii Fit Plus save, 1138/1152 entries agree in nonzero/nonzero presence between these ratings and PBs. Some exceptions can reflect separate completion flags or special activities. Thus **do not automatically derive star ratings from PB scores**. Exact meaning of rating 1/2/3/4 is not yet confirmed in-game.

`wiifit_legacy_ratings.py` is a separate conservative CLI for these two fields. It reads or changes the per-Mii rating independently, repairs the proven Wii Fit Plus dual-sum checksum at `0x4C198`, and writes NEW `FitPlus0.dat`/`FitPlus1.dat` raw files into an unused output folder. It does not overwrite your current Dolphin save or produce a signed Wii SD export. Test with copies only.

**Your original Dance Yoga sample verified byte-exact restoration** after editing rating 4→3→4 and repairing checksum.

## Mario Kart Wii

Do not duplicate the existing ghost-management ecosystem. [Ghost Manager](https://www.tt-rec.com/ghostmanager/) and [rksys.dat documentation](https://www.mkwiiki.org/wiki/Rksys.dat) cover time-trial entries, character/vehicle/controller data, other save sections, and checksums. For the unified editor, treat this as an external integration/reference rather than a new reverse-engineering target.

## Remaining work

Original Wii Sports numerical training scores (separate from medal rank and play count); separate opponent-strength progression; Golf and Bowling high-score history. Wii Fit Plus multi-stage completion flags vs times, and daily Wii Fit Age / body balance / piggy bank / special challenges still need in-game confirmed field mappings. None is claimed solved by this patch.
