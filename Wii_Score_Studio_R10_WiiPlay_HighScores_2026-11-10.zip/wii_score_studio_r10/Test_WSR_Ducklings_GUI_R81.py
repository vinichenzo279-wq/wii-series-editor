from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).parent))
from Wii_Score_Studio_GUI import App
from Wii_Score_Studio_Core import resort_validate
from WSR_Known_Fields import PERSONAL_FIELDS,read_record
import tkinter.simpledialog as simpledialog
import tkinter.messagebox as messagebox
source=Path('/mnt/data/wii_save_research/Sports2_pal.dat')
root=App();root.update_idletasks()
root.resort.open_document(source)
tab=root.resort_named
assert tab.doc is root.resort.doc
tab.player.set('01: Vincenzo')
tab.category.set('Personal scores');tab.change_category();tab.sport.set('Canoeing');tab.render()
rows=[(k,v) for k,v in tab.row_data.items() if v[0]=='record' and v[1].mode=='Stray Ducklings time']
assert len(rows)==1,rows
k,record=rows[0]
assert tab.tree.item(k,'values')[2]=='2:15.08',tab.tree.item(k,'values')
tab.tree.selection_set(k)
orig=simpledialog.askstring;error=messagebox.showerror
simpledialog.askstring=lambda *args,**kw:'2:14.99'
messagebox.showerror=lambda *args,**kw:(_ for _ in ()).throw(AssertionError(args))
try:
 tab.edit_selected()
finally:
 simpledialog.askstring=orig;messagebox.showerror=error
field=next(f for f in PERSONAL_FIELDS if f.mode=='Stray Ducklings time')
assert read_record(tab.doc.resort_bytes(),field,1)['shown']=='2:14.99'
assert resort_validate(tab.doc.resort_bytes())[0]
assert source.read_bytes()[0x9992:0x9994]==bytes.fromhex('34c4')
root.destroy()
print('GUI PASS: filtered Canoeing shows Stray Ducklings 2:15.08; edited to 2:14.99; repaired CRC; original intact')
