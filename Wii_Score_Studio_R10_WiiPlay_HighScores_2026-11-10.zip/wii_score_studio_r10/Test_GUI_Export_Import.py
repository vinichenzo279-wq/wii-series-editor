"""Requires Xvfb or a desktop: tests the UI's actual CSV roundtrip (no private data written to package)."""
from pathlib import Path
from tempfile import TemporaryDirectory
import csv
from unittest.mock import patch
from Wii_Score_Studio_GUI import App
root=Path('/mnt/data/wii_save_research')
a=App();a.withdraw()
a.london.open_document(root/'2012_newer')
assert a.london.doc.london_shooting_time(3)=='0:11.290'
assert '0:11.290' in a.london.tree.item('12')['values'][4]
with TemporaryDirectory() as tmp:
 csvfile=Path(tmp)/'scores.csv'
 with patch('Wii_Score_Studio_GUI.filedialog.asksaveasfilename',return_value=str(csvfile)),patch('Wii_Score_Studio_GUI.messagebox.showinfo'):
  a.london.csv_export()
 with csvfile.open(encoding='utf-8-sig',newline='') as f:
  rows=list(csv.DictReader(f));fields=list(rows[0])
 assert len(rows)==124 and 'shooting_time' in fields
 for r in rows:
  if r['slot']=='3' and r['event']=='12':r['shooting_time']='0:38.860';r['score']='470'
  if r['slot']=='2' and r['event']=='7':r['score']='30'
 with csvfile.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
 with patch('Wii_Score_Studio_GUI.filedialog.askopenfilename',return_value=str(csvfile)),patch('Wii_Score_Studio_GUI.messagebox.askyesno',return_value=True),patch('Wii_Score_Studio_GUI.messagebox.showinfo'),patch('Wii_Score_Studio_GUI.messagebox.showerror',side_effect=lambda *q,**kw: (_ for _ in ()).throw(AssertionError(q))):
  a.london.csv_import()
 assert a.london.doc.london_raw(3,12)==(470,0)
 assert a.london.doc.london_shooting_time(3)=='0:38.860'
 assert a.london.doc.london_raw(3,3)==(9,814)
 assert a.london.doc.london_raw(2,7)==(30,0)
print('PASS: Tk GUI, Shooting verified dual-record display, 124-row CSV roundtrip, independent points/time changes, and unchanged Long Jump')
a.destroy()
