"""Original Wii Sports (not Resort) RPSports.dat save inspector and float32 skill editor.

User supplied two decrypted RPSports.dat examples. Both independently validate
with the global two-accumulator checksum described in public transfer research.

The five sport labels follow menu order and are not independently verified by
single-sport before/after play. Player identities are shown as raw Mii/system
IDs; use your game's Mii list to confirm the index before writing.

Examples:
  python WiiSports_Original_Save_Tool_R1.py inspect RPSports.dat
  python WiiSports_Original_Save_Tool_R1.py set RPSports.dat 0 Tennis 0x4515FFF6 --output patched.dat
  python WiiSports_Original_Save_Tool_R1.py set RPSports.dat 0 Boxing 3124 --output patched.dat
"""
from pathlib import Path
import argparse,struct,json,math

MAGIC=b'RPSP0000'
BYTES=131072
RECORD_BASE=0x5F
RECORD_STRIDE=0x455
MAX_MII=100
SKILLS=('Tennis','Baseball','Bowling','Golf','Boxing')
SKILL_BASE=0x0E
SPORT_STRIDE=0x79
CHECKSUM_OFFSET=0x1B190
MAX_KNOWN={
 'Tennis':0x4515FFF6, 'Baseball':0x45528324,
 # User experimentally verified decimal maxima but did not supply precise float bits.
 'Bowling':0x450A5FFF, 'Golf':0x4558653D,'Boxing':0x45434FFF,
}

def verify(b):
 if len(b)!=BYTES or b[:8]!=MAGIC:
  raise ValueError('Not a 128-KiB original Wii Sports RPSports.dat (RPSP0000)')
 calc=checksum(b)
 stored=struct.unpack_from('>I',b,CHECKSUM_OFFSET)[0]
 return stored==calc,stored,calc

def checksum(b):
 n1=n2=0
 for i in range(0,CHECKSUM_OFFSET,2):
  x=(b[i]<<8)|b[i+1]
  n1=(n1+x)&0xFFFF
  n2=(n2+(x^0xFFFF))&0xFFFF
 return (n1<<16)|n2

def fix_checksum(b):
 value=checksum(b)
 struct.pack_into('>I',b,CHECKSUM_OFFSET,value)
 return value

def record_start(i):
 if not 0<=i<MAX_MII:raise ValueError('Mii record index must be 0–99')
 return RECORD_BASE+i*RECORD_STRIDE

def skill_offset(i,sport):
 sport_name=normalize_sport(sport)
 return record_start(i)+SKILL_BASE+SKILLS.index(sport_name)*SPORT_STRIDE

def normalize_sport(s):
 if str(s).isdigit():return SKILLS[int(s)]
 for x in SKILLS:
  if x.lower()==str(s).lower():return x
 raise ValueError('Sport must be Tennis, Baseball, Bowling, Golf or Boxing')

def player_info(b,i):
 r=record_start(i);status=b[r]
 # 8-byte identity pair is from published Wii Sports transfer research;
 # 4 additional subsequent bytes may be part of full identifier/crossrefs.
 out={'index':i,'status':status,'mii_id_hex':b[r+1:r+5].hex().upper(),
 'system_id_hex':b[r+5:r+9].hex().upper(),
 'identity_tail_hex':b[r+9:r+13].hex().upper(),
 'active':status!=0,'skill_float32':{},'skill_bits':{}}
 for sport in SKILLS:
  o=skill_offset(i,sport)
  raw=struct.unpack_from('>I',b,o)[0]
  out['skill_float32'][sport]=struct.unpack('>f',struct.pack('>I',raw))[0]
  out['skill_bits'][sport]=f'0x{raw:08X}'
 return out

def patch_skill(b,i,sport,val):
 sport=normalize_sport(sport)
 if b[record_start(i)]==0:raise ValueError('Mii slot is inactive; refusing to create a phantom Mii')
 if str(val).lower().startswith('0x'):
  raw=int(val,16)
  if not 0<=raw<=0x7F7FFFFF:raise ValueError('Expected positive finite float32 bits')
 else:
  value=float(val)
  if not math.isfinite(value) or value<0:raise ValueError('Enter positive finite float32 skill')
  raw=struct.unpack('>I',struct.pack('>f',value))[0]
 o=skill_offset(i,sport)
 old=struct.unpack_from('>I',b,o)[0]
 struct.pack_into('>I',b,o,raw)
 fix_checksum(b)
 return {'mii_index':i,'sport':sport,'offset_hex':hex(o),'old_bits':f'0x{old:08X}','new_bits':f'0x{raw:08X}',
         'stored_float32':struct.unpack('>f',struct.pack('>I',raw))[0]}

def main():
 ap=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawTextHelpFormatter)
 sub=ap.add_subparsers(dest='command',required=True)
 s=sub.add_parser('inspect');s.add_argument('path')
 s=sub.add_parser('set');s.add_argument('path');s.add_argument('mii_index',type=int);s.add_argument('sport');s.add_argument('value',help='float or exact bits, e.g. 0x4515FFF6');s.add_argument('--output',required=True)
 s=sub.add_parser('preset');s.add_argument('path');s.add_argument('mii_index',type=int);s.add_argument('--output',required=True)
 a=ap.parse_args();p=Path(a.path);orig=p.read_bytes();ok,stored,calc=verify(orig)
 if not ok:raise ValueError(f'Original file checksum wrong: stored {stored:08X}, computed {calc:08X}')
 if a.command=='inspect':
  print('Wii Sports original | Checksum valid | max 100 Mii slots')
  for i in range(MAX_MII):
   x=player_info(orig,i)
   if x['active']:print(json.dumps(x,ensure_ascii=False))
  return
 dest=Path(a.output)
 if dest.exists():raise FileExistsError('Choose a new output path (never overwrite your source)')
 if dest.resolve()==p.resolve():raise ValueError('Refusing to overwrite input')
 b=bytearray(orig)
 if a.command=='set':
  print(json.dumps(patch_skill(b,a.mii_index,a.sport,a.value),indent=2))
 elif a.command=='preset':
  for sport in SKILLS:
   print(json.dumps(patch_skill(b,a.mii_index,sport,hex(MAX_KNOWN[sport]))))
 assert verify(b)[0]
 dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 print(f'Wrote {dest}, checksum 0x{checksum(b):08X}. Not yet game-tested; backup and test in Dolphin.')
if __name__=='__main__':main()
