"""Read-only research: 21 consecutive BE32 character-use counters in London System.

8 character indexes verified by matching user-supplied in-game rankings to
an original historical Slot00 System file. Others remain unnamed, unproven.
"""
from pathlib import Path
import struct,csv,sys
START=0x85B4
COUNT=21
NAMES={1:'Mario',2:'Luigi',6:'Wario',7:'Waluigi',8:'Yoshi',11:'Sonic',16:'Shadow',18:'Metal Sonic'}
def char_counts(blob:bytes):
 if len(blob)!=65536:raise ValueError('Not a London System file')
 return [(i,START+i*4,struct.unpack_from('>I',blob,START+i*4)[0],NAMES.get(i,f'Unknown character index {i}')) for i in range(COUNT)]
if __name__=='__main__':
 if len(sys.argv)<2: print('Usage: python London_Character_Usage_Audit.py path/to/Slot00/System [output.csv]');sys.exit(1)
 rows=char_counts(Path(sys.argv[1]).read_bytes())
 if len(sys.argv)>=3:
  with open(sys.argv[2],'w',encoding='utf-8-sig',newline='') as f:
   w=csv.writer(f);w.writerow(['Character index','System offset','Times used','Character identification'])
   w.writerows([(i,f'0x{o:04X}',v,n) for i,o,v,n in rows])
 else:
  for i,o,v,n in sorted(rows,key=lambda x:-x[2]):print(f'{n:28s} id={i:02} offset=0x{o:04X} played={v}')
