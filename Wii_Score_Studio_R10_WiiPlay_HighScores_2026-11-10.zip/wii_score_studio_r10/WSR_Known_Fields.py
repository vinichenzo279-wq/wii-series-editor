"""Wii Sports Resort Sports2.dat field map derived from Aaron98990/wii-inspect.

Source: user-supplied wii-inspect-master (1).zip / highScores.bash, stamps.bash.
Only data backed by those scripts is labeled. Original files are not modified.
The 3-byte skill encoding is reconstructed directly from highScores.bash:
    12-bit level = byte[0] | ((byte[2]&0xf)<<8), byte[1] metadata.
All write operations mutate only a copy and leave CRC repair to caller.
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
import struct

NAME_BASE=0x82C0
STRIDE=0xDF4
MAX_PROFILES=100
SKILL_BASE=0x1A8
SKILL_STRIDE=3
HISTORY_LEN=25
SPORT_SKILLS=[
 'Swordplay Showdown','Swordplay Duel','Speed Slice','Power Cruising','Archery',
 'Frisbee Dog','Basketball 3-Point','Basketball Pickup','Bowling Standard',
 'Bowling 100-Pin','Bowling Spin Control','Canoeing','Table Tennis Return',
 'Table Tennis Match','Wakeboarding','Golf','Frisbee Golf','Cycling','Skydiving'
]
# Persistent Pro/Superstar achievements are independent of current skills.
# Verified against 204 distinct Mii records from user-supplied historical saves.
# There are 25 rank positions for 19 skill sports; unused positions belong to
# other activity types. Values: 0 none, 3 Pro silver, 4 Superstar gold.
RANK_BASE=0xAF
SPORT_RANK_SLOTS=(0,1,2,3,5,6,7,8,9,10,11,13,14,15,16,19,20,22,23)
RANK_LABELS={0:'None',3:'Pro (silver)',4:'Superstar (gold)'}

STAMP_BASES=[
 ('Swordplay Showdown',0x8CEC),('Swordplay Duel',0x8D00),('Speed Slice',0x8D14),
 ('Power Cruising',0x8D28),('Archery',0x8D50),('Frisbee Dog',0x8D64),
 ('Basketball 3-Point',0x8D78),('Basketball Pickup',0x8D8C),
 ('Bowling Standard',0x8D9C),('Bowling 100-Pin',0x8DB4),('Bowling Spin Control',0x8DC8),
 ('Canoeing',0x8DF0),('Table Tennis Return',0x8E04),('Table Tennis Match',0x8E18),
 ('Wakeboarding',0x8E2C),('Island Flyover',0x8E40),('Golf',0x8E68),
 ('Frisbee Golf',0x8E7C),('Cycling',0x8EA4),('Skydiving',0x8EB8)
]
# Author parser labels and scores in order: all are at BE16 fields, plus flag metadata
# for golf/frisbee and packed cycling entries.
@dataclass(frozen=True)
class Field:
  key:str
  sport:str
  mode:str
  off:int
  fmt:str
  scope:str

FIELDS=[]
def group(scope,sport,names,start,fmt,step=4):
  for i,mode in enumerate(names):
    FIELDS.append(Field(f'{scope}:{sport}:{i}',sport,mode,start+i*step,fmt,scope))
# Personal record exact offsets from highScores.bash; for per-Mii records add index*0xDF4
pers='personal'
group(pers,'Power Cruising',['Beach','Lagoon','Lighthouse','Marina','Cavern','Shoals'],0x8A6E,'u16_10')
group(pers,'Archery',['Beginner','Intermediate','Expert'],0x8A96,'u16')
group(pers,'Frisbee Dog',['Personal best'],0x8ABE,'u16')
group(pers,'Basketball 3-Point',['Personal best'],0x8AE6,'u16_10')
group(pers,'Bowling',['Standard','100-Pin','Spin Control'],0x8B0E,'u16',0x28)
group(pers,'Canoeing',['Beginner distance','Intermediate distance','Expert distance','Beginner target','Intermediate target','Expert target'],0x8B86,'u16_100')
# R8.1: Verified by user's 2:15.08 Stray Ducklings result on Vincenzo PAL profile 1.
# BE16 value 13508 at absolute 0x9992 = 0x8B9E + 0xDF4 (Mii index 1).
# This is the next four-byte record after the six Canoeing entries.
group(pers,'Canoeing',['Stray Ducklings time'],0x8B9E,'time_cs')
group(pers,'Table Tennis Return',['Personal best'],0x8BAE,'u16')
group(pers,'Wakeboarding',['Beginner','Intermediate','Expert'],0x8BD6,'u16')
group(pers,'Island Flyover',['I-Points (5 min)','Balloons (5 min)'],0x8BFE,'u16')
group(pers,'Golf',['Resort A','Resort B','Resort C','Classic A','Classic B','Classic C','3 holes Special','9 holes Resort','9 holes Classic','18 holes'],0x8C26,'s16_flag')
group(pers,'Frisbee Golf',['Resort A','Resort B','Resort C','Classic A','Classic B','Classic C','3 holes Special','9 holes Resort','9 holes Classic','18 holes'],0x8C4E,'s16_flag')
group(pers,'Skydiving',['Personal best'],0x8C9E,'u16')
# Wii-wide records from literal offsets in source (some source indices decimal hex-string positions)
wide='wii'
group(wide,'Power Cruising',['Beach','Lagoon','Lighthouse','Marina','Cavern','Shoals'],6572//2,'u16_10')
group(wide,'Archery',['Beginner','Intermediate','Expert'],8636//2,'u16')
group(wide,'Frisbee Dog',['Wii record'],10700//2,'u16')
group(wide,'Basketball 3-Point',['Wii record'],12764//2,'u16_10')
for mode,off in zip(['Standard','100-Pin','Spin Control'],[14828//2,16892//2,18956//2]):group(wide,'Bowling',[mode],off,'u16')
group(wide,'Canoeing',['Beginner distance','Intermediate distance','Expert distance'],21020//2,'u16_100')
group(wide,'Table Tennis Return',['Wii record'],23084//2,'u16')
group(wide,'Wakeboarding',['Beginner','Intermediate','Expert'],25148//2,'u16')
group(wide,'Golf',['Resort A','Resort B','Resort C','Classic A','Classic B','Classic C','3 holes Special','9 holes Resort','9 holes Classic','18 holes'],29276//2,'s16_flag')
group(wide,'Frisbee Golf',['Resort A','Resort B','Resort C','Classic A','Classic B','Classic C','3 holes Special','9 holes Resort','9 holes Classic','18 holes'],31340//2,'s16_flag')
group(wide,'Skydiving',['Wii record'],35468//2,'u16')
PERSONAL_FIELDS=[f for f in FIELDS if f.scope=='personal']
WII_FIELDS=[f for f in FIELDS if f.scope=='wii']
assert len(STAMP_BASES)==20 and len(SPORT_SKILLS)==19

def profile_base(idx):
 if not 0<=idx<MAX_PROFILES:raise ValueError('Invalid Mii slot')
 return idx*STRIDE

def _need(blob,off,n):
 if off<0 or off+n>len(blob): raise ValueError(f'Field outside Sports2.dat: 0x{off:x}+{n}')

def profile_names(blob):
 results=[]
 for idx in range(MAX_PROFILES):
  off=NAME_BASE+idx*STRIDE
  if off+20>len(blob):break
  chars=blob[off:off+20].decode('utf-16-be','replace').split('\0',1)[0].strip()
  if not chars or len(chars)>10 or '\ufffd' in chars or not all(c.isprintable() for c in chars):continue
  results.append((idx,chars))
 return results

def offset(f,profile=0): return f.off + (profile_base(profile) if f.scope=='personal' else 0)

def read_record(blob,f,profile=0):
 off=offset(f,profile);_need(blob,off,2)
 if f.fmt=='s16_flag':
  # Original bash script uses a neighboring flag to determine not-played entries.
  # Its exact meaning is not fully established. Always expose the signed score and
  # preserve the metadata bytes instead of guessing that a +0 is unplayed.
  v=struct.unpack_from('>h',blob,off)[0]
  return dict(raw=v,value=v,shown=str(v),valid=None,flag=blob[off-2:off].hex().upper(),offset=off)
 v=struct.unpack_from('>H',blob,off)[0]
 if f.fmt=='time_cs':
  # Zero denotes no time recorded. Saved integer is hundredths of a second.
  shown=f'{v//6000}:{(v//100)%60:02d}.{v%100:02d}' if v else 'not recorded'
  return dict(raw=v,value=v/100,shown=shown,valid=True,offset=off)
 scale={'u16_10':10,'u16_100':100}.get(f.fmt,1)
 return dict(raw=v,value=v/scale,shown=f'{v/scale:.{len(str(scale))-1}f}' if scale>1 else str(v),valid=True,offset=off)

def patch_record(blob,f,profile,value):
 off=offset(f,profile); _need(blob,off,2)
 if f.fmt=='s16_flag':
  n=int(value)
  if not -32768<=n<=32767:raise ValueError('Signed value out of range')
  struct.pack_into('>h',blob,off,n)
  # A new score in an unplayed golf event also needs a validity flag.
  # We do NOT invent the flag's encoding; leave it unchanged and report that separately.
  return off
 from decimal import Decimal
 if f.fmt=='time_cs':
  inp=str(value).strip()
  if inp in ('0','', 'not recorded'):
   v=0
  else:
   if ':' in inp:
    parts=inp.split(':')
    if len(parts)!=2: raise ValueError('Enter minutes:seconds.hundredths, e.g. 2:15.08')
    minutes=int(parts[0]);seconds=Decimal(parts[1])
    if minutes<0 or seconds<0 or seconds>=60:raise ValueError('Invalid minutes or seconds')
    centis=(minutes*60+seconds)*100
   else:
    parts=inp.split('.')
    if len(parts)==3:  # Alternative 2.15.08 notation
     minutes=int(parts[0]);seconds=int(parts[1]);hundredths=int(parts[2])
     if minutes<0 or not 0<=seconds<60 or not 0<=hundredths<100:raise ValueError('Invalid minutes or seconds')
     centis=minutes*6000+seconds*100+hundredths
    else:centis=Decimal(inp)*100 # total decimal seconds, e.g. 135.08
   if Decimal(centis)!=Decimal(centis).to_integral_value():raise ValueError('Time must have hundredth-second precision')
   v=int(centis)
  if not 0<=v<=65535:raise ValueError('Time must fit 0 to 10:55.35')
  struct.pack_into('>H',blob,off,v)
  return off
 scale={'u16_10':10,'u16_100':100}.get(f.fmt,1)
 d=Decimal(str(value))*scale
 if d!=d.to_integral_value():raise ValueError(f'Value must have resolution 1/{scale}')
 n=int(d)
 if not 0<=n<=65535:raise ValueError('Unsigned value out of range')
 struct.pack_into('>H',blob,off,n)
 return off

def read_skill(blob,profile,sport,entry):
 if not 0<=sport<len(SPORT_SKILLS) or not 0<=entry<HISTORY_LEN: raise ValueError('Invalid skill history selection')
 off=NAME_BASE+profile_base(profile)+SKILL_BASE+sport*(HISTORY_LEN*SKILL_STRIDE)+entry*SKILL_STRIDE
 _need(blob,off,3)
 return dict(offset=off,score=blob[off]+((blob[off+2]&0x0f)<<8),metadata=blob[off+1],other_nibble=blob[off+2]>>4)

def patch_skill(blob,profile,sport,entry,score):
 v=int(score)
 if not 0<=v<=2500:raise ValueError('Expected a displayed skill between 0 and 2500')
 off=read_skill(blob,profile,sport,entry)['offset']
 blob[off]=v&255
 blob[off+2]=(blob[off+2]&0xf0)|(v>>8)
 return off

def decode_stamp(raw):
 if raw==0:return ''
 year=(raw>>20)&0x7ff;month=((raw>>16)&15)+1;day=(raw>>11)&31;hour=(raw>>6)&31;minute=raw&63
 try:return datetime(year,month,day,hour,minute).strftime('%Y-%m-%d %H:%M')
 except (ValueError,OverflowError):return f'raw 0x{raw:08X}'

def encode_stamp(s):
 if not s or s.strip().lower() in ('none','clear','0'):return 0
 v=datetime.strptime(s.strip(),'%Y-%m-%d %H:%M')
 if not 1<=v.year<=2047:raise ValueError('Year out of range')
 return (v.year<<20)|((v.month-1)<<16)|(v.day<<11)|(v.hour<<6)|v.minute

def read_stamp(blob,profile,sport,number):
 if not 0<=sport<len(STAMP_BASES) or not 0<=number<5:raise ValueError('Invalid stamp')
 off=STAMP_BASES[sport][1]+profile_base(profile)+number*4
 _need(blob,off,4)
 n=struct.unpack_from('>I',blob,off)[0]
 return dict(offset=off,raw=n,shown=decode_stamp(n),acquired=n!=0)

def patch_stamp(blob,profile,sport,number,date_text):
 orig=read_stamp(blob,profile,sport,number)
 struct.pack_into('>I',blob,orig['offset'],encode_stamp(date_text))
 return orig['offset']

# Unmapped: Cycling packed score/times, duckling time, exact individual stamp names,
# advanced sport data / skill modifiers, game mode flags, and full Wii holder names.


def read_rank(blob,profile,sport):
 if not 0<=sport<len(SPORT_RANK_SLOTS):raise ValueError('Invalid sport index')
 off=NAME_BASE+profile_base(profile)+RANK_BASE+2*SPORT_RANK_SLOTS[sport]
 _need(blob,off,1)
 raw=blob[off]
 return dict(offset=off,raw=raw,shown=RANK_LABELS.get(raw,f'Unknown ({raw})'))

def patch_rank(blob,profile,sport,rank):
 rank=int(rank)
 if rank not in RANK_LABELS:raise ValueError('Rank must be 0 (none), 3 (Pro), or 4 (Superstar)')
 off=read_rank(blob,profile,sport)['offset']
 blob[off]=rank
 return off

def award_rank_for_skill(blob,profile,sport,skill):
 """Optional upward-only award; never demotes or clears an existing rank."""
 old=read_rank(blob,profile,sport)['raw']
 desired=4 if skill>=2000 else 3 if skill>=1000 else 0
 if desired>old:
  patch_rank(blob,profile,sport,desired)
  return True
 return False
