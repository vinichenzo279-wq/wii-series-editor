# R9 validation status (local tests)

- Existing London 2012, Resort known-field, Resort skill preset, and Resort duckling parser tests pass.
- New original Wii Sports PAL encrypted `RSPP/data.bin` opened with all required files (`banner.bin`, `RPSports.dat`).
- `RPSports.dat` checksum algorithm matched two independent valid saves byte-for-byte; the user reference stored `0xC78A5FAE`, Aaron's stored `0x2FA4F794`.
- Changing Tennis for Mii record index 0 to exact bits `0x4515FFF6` modifies only four score bytes and four global checksum bytes. Full Dolphin NAND ZIP export retains `banner.bin` and the edited `RPSports.dat`. Verified round-trip on the produced ZIP.
- New GUI tab loads four active Wii Sports profiles from user's save, edits float32 skill, recalculates checksum and refreshes table (Tk under virtual X display).
- Game Library detects `SIIP`, `RZTP`/`RZTE`, and `RSPP`/`RSPE`; full encrypted PAL archive sample opened correctly for the three tested games.
- Resort consolidated save from the user's current PAL `private.zip` has checksum validated, all 100 stamps and 19 current skills at 2500 for *Vico* (Mii index 1). Exactly 231 bytes changed, all confined to that one Mii record and the four CRC bytes. Wii-wide scores and other Miis remain untouched.
- Exported Resort Dolphin NAND ZIP includes `banner.bin`, `Sports2.dat`, `wc24dl.vff`, and `wc24pubk.mod`. Its `Sports2.dat` matches the separately exported raw file exactly.
- A legacy `Test_GUI_Library_R5.py` automatic test uses an interactive modal dialog and did not terminate in the headless runner; that does not affect the other explicit open/patch/export tests.

**Still need in-game verification:** original Wii Sports skill editing and compiled Resort profile / Stray Ducklings 1:59.99. Original Wii Sports sport names for the 5 ordered float fields are strong menu-order mappings, not confirmed individually with one sport played.
