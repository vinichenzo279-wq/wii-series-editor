#!/usr/bin/env python3
"""No private saves required. Runs synthetic data and binary round-trip tests."""
from pathlib import Path
from tempfile import TemporaryDirectory
from Wii_Score_Studio_Core import SaveDocument, london_repair_checksum, london_validate, resort_crc, resort_validate
import struct, zipfile

def check():
    london=bytearray(65536)
    london[:8]=bytes.fromhex('0000000100030060')
    struct.pack_into('>HH',london,0xE50,9,814)
    london_repair_checksum(london)
    doc=SaveDocument('SIIP',{'Slot03/System':london},'synthetic',{'Slot03/System':bytes(london)})
    assert doc.london_display(3,3)=='9.814'
    doc.london_patch(3,3,'9.999')
    assert doc.london_raw(3,3)==(9,999)
    assert london_validate(doc.entries['Slot03/System'])[0]
    assert doc.entries['Slot03/System'][0xE50:0xE54]==bytes.fromhex('000903e7')
    assert doc.changes==1
    with TemporaryDirectory() as tmp:
        out=Path(tmp)/'edited.zip';doc.export_nand_zip(out)
        with zipfile.ZipFile(out) as z:
            payload=z.read('Wii/title/00010000/53494950/data/Slot03/System')
            assert payload[0xE50:0xE54]==bytes.fromhex('000903e7')
            assert london_validate(payload)[0]
    doc.undo_all();assert doc.london_display(3,3)=='9.814'
    sport=bytearray(0x120);sport[:4]=b'WSP2';struct.pack_into('>I',sport,8,0x100)
    struct.pack_into('>H',sport,0x80,1234)
    struct.pack_into('>I',sport,12,resort_crc(sport))
    w=SaveDocument('RZTE',{'Sports2.dat':sport},'synthetic',{'Sports2.dat':bytes(sport)})
    assert resort_validate(w.resort_bytes())[0]
    assert w.resort_read(0x80,'U16 / 100')=='12.34'
    w.resort_patch(0x80,'U16 / 100','56.78')
    assert w.resort_read(0x80,'U16 / 100')=='56.78'
    assert resort_validate(w.resort_bytes())[0]
    with TemporaryDirectory() as tmp:
        out=Path(tmp)/'resort.zip';w.export_nand_zip(out)
        with zipfile.ZipFile(out) as z:
            payload=z.read('Wii/title/00010000/525A5445/data/Sports2.dat')
            assert resort_validate(payload)[0]
    print('PASS: London decimal & byte encoding, undo, ZIP export; WSR CRC repair, fixed-point decimal, US title path')

if __name__=='__main__':check()
