# Stray Ducklings record field discovery

User-verified Wii Sports Resort PAL example: `Vincenzo` (Mii index 1), Canoeing skill `1296`, Beginner distance `274.81 m`, 3 Canoeing stamps and a Stray Ducklings time `2:15.08`.

Decrypted `Sports2.dat`:

- Per-Mii record stride: `0xDF4` (3572 bytes).
- Stray Ducklings score offset for Mii index 0: `0x8B9E`.
- For Mii index 1: `0x8B9E + 0xDF4 = 0x9992`.
- Bytes at `0x9992–0x9993`: `34 C4` (big-endian unsigned 16-bit = 13508).
- Stored in **centiseconds**, so 13508 / 100 = 135.08 seconds = **2:15.08**.
- Next two bytes at `0x9994–0x9995` currently `00 00`; meaning not established, preserved.

The address `0x8B9E` is exactly the next four-byte record after the **six Canoeing distances/target records** listed in `Aaron98990/wii-inspect/highScores.bash`. This and the exact score match strongly identify the field. A whole-file byte search in the relevant PAL save finds the 16-bit value `34 C4` only here.

Another archive contains `Vico` with a recorded value `12035` = **2:00.35** at its corresponding Mii offset. Additional plausible times such as 3:14.23 and 5:02.48 are tabulated in the accompanying `WSR_Stray_Ducklings_Identified_Archive_Records.csv`.

**Limits:** the exact semantics of any neighboring metadata bytes are still unverified. A separate Wii-wide record holder or global-best time might exist elsewhere and has not been identified. The score editor only modifies the two confirmed personal-time bytes plus the CRC32 as necessary.
