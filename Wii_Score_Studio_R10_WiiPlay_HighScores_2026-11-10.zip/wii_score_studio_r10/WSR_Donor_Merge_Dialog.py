"""Explicit per-Mii donor merge, without silently mixing Mii identity or Wii-wide records."""
from __future__ import annotations
from pathlib import Path
import tkinter as tk
from tkinter import ttk,filedialog,messagebox
import zipfile
from WSR_Known_Fields import profile_names,SPORT_SKILLS,STAMP_BASES,PERSONAL_FIELDS
from WSR_Bulk_Editing import donor_merge
from Wii_Score_Studio_Core import SaveDocument, resort_fix_checksum, resort_validate, scan_save_zips


class DonorMergeDialog(tk.Toplevel):
 def __init__(self,parent,doc,targetidx,done):
  super().__init__(parent)
  self.doc=doc;self.targetidx=targetidx;self.done=done;self.donor=None;self.sources=[]
  self.title('Consolidate Wii Sports Resort Mii records from a donor save')
  self.geometry('850x520');self.transient(parent);self.grab_set();self.resizable(True,True)
  f=ttk.Frame(self,padding=17);f.pack(fill='both',expand=True)
  tt=next((name for i,name in profile_names(doc.resort_bytes()) if i==targetidx),f'index {targetidx}')
  ttk.Label(f,text=f'Target: {tt} (slot {targetidx:02d}) in current save',font=('Segoe UI',13,'bold')).pack(anchor='w')
  ttk.Label(f,text='Copy selected fields only. The target Mii identity, other Miis, and Wii-wide records remain unchanged.',wraplength=780).pack(anchor='w',pady=(5,12))
  bar=ttk.Frame(f);bar.pack(fill='x',pady=4)
  ttk.Button(bar,text='Choose donor file or ZIP…',command=self.browse).pack(side='left')
  self.pathvar=tk.StringVar(value='No donor loaded')
  ttk.Label(bar,textvariable=self.pathvar,wraplength=570).pack(side='left',padx=12)
  f2=ttk.Frame(f);f2.pack(fill='x',pady=8)
  ttk.Label(f2,text='Source inside ZIP:').grid(row=0,column=0,sticky='w')
  self.source=tk.StringVar();self.sourcecombo=ttk.Combobox(f2,textvariable=self.source,state='readonly',width=68)
  self.sourcecombo.grid(row=0,column=1,padx=10,sticky='ew');self.sourcecombo.bind('<<ComboboxSelected>>',lambda e:self.load_source())
  ttk.Label(f2,text='Donor Mii:').grid(row=1,column=0,sticky='w',pady=10)
  self.donormii=tk.StringVar();self.miicombo=ttk.Combobox(f2,textvariable=self.donormii,state='readonly',width=38)
  self.miicombo.grid(row=1,column=1,padx=10,sticky='w');f2.columnconfigure(1,weight=1)
  opts=ttk.LabelFrame(f,text='Choose categories to import (select target sport or All)',padding=12);opts.pack(fill='x',pady=(5,12))
  self.skills=tk.BooleanVar(value=True);self.stamps=tk.BooleanVar(value=True);self.records=tk.BooleanVar(value=False)
  ttk.Checkbutton(opts,text='Skill ratings',variable=self.skills).grid(row=0,column=0,sticky='w')
  ttk.Checkbutton(opts,text='Add missing stamps',variable=self.stamps).grid(row=1,column=0,sticky='w')
  ttk.Checkbutton(opts,text='Copy numeric personal records (not Wii-wide)',variable=self.records).grid(row=2,column=0,sticky='w')
  self.fullhistory=tk.BooleanVar(value=False)
  ttk.Checkbutton(opts,text='Replace all 25 skill-history values instead of only newest entry',variable=self.fullhistory).grid(row=0,column=1,sticky='w',padx=15)
  self.sport=tk.StringVar(value='All')
  all_sports=sorted(set(SPORT_SKILLS+[x[0] for x in STAMP_BASES]+[x.sport for x in PERSONAL_FIELDS]))
  ttk.Label(opts,text='Sport:').grid(row=3,column=0,sticky='w',pady=(10,0))
  ttk.Combobox(opts,textvariable=self.sport,values=['All']+all_sports,state='readonly',width=33).grid(row=3,column=1,sticky='w',padx=15,pady=(10,0))
  self.status=tk.StringVar(value='Choose a donor save to preview changes.')
  ttk.Label(f,textvariable=self.status,wraplength=780,foreground='#536b7e').pack(anchor='w',pady=5)
  ttk.Label(f,text='Note: importing scores copies the selected donor values even if worse. Golf imports its nearby validity flag. Cross-save Mii ownership is intentionally not rewritten.',wraplength=770,foreground='#825e27').pack(anchor='w',pady=10)
  buttons=ttk.Frame(f);buttons.pack(fill='x',side='bottom',pady=(18,0))
  ttk.Button(buttons,text='Preview changes',command=self.preview).pack(side='left')
  ttk.Button(buttons,text='Apply to current Mii',command=self.apply).pack(side='left',padx=10)
  ttk.Button(buttons,text='Cancel',command=self.destroy).pack(side='right')
  self.path=None

 def browse(self):
  fp=filedialog.askopenfilename(parent=self,title='Choose donor Sports2.dat, data.bin or ZIP',filetypes=[('Wii saves','*.dat *.bin *.zip'),('All files','*.*')])
  if not fp:return
  try:
   self.path=Path(fp);self.sources=[]
   if self.path.suffix.lower()=='.zip':
    with zipfile.ZipFile(self.path) as z:
     for info in z.infolist():
      if info.is_dir():continue
      if info.file_size>1_000_000:continue
      if info.filename.lower().endswith(('.dat','.bin')):
       with z.open(info) as fh:header=fh.read(4)
       if header==b'WSP2':self.sources.append(('raw',info.filename))
     for n,game in scan_save_zips(self.path):
      if game in ('RZTP','RZTE'):self.sources.append(('encrypted',n))
    if not self.sources:raise ValueError('No Wii Sports Resort Sports2.dat or SD data.bin found in this ZIP')
   else:self.sources=[('file',self.path.name)]
   choices=[f'{kind}: {key}' for kind,key in self.sources]
   self.sourcecombo['values']=choices;self.source.set(choices[0]);self.pathvar.set(self.path.name)
   self.load_source()
  except Exception as exc:messagebox.showerror('Donor error',str(exc),parent=self)

 def load_source(self):
  if not self.path:return
  try:
   n=self.sourcecombo.current(); n=0 if n<0 else n
   kind,key=self.sources[n]
   if kind=='raw':
    with zipfile.ZipFile(self.path) as z:blob=z.read(key)
   elif kind=='encrypted':blob=bytes(SaveDocument.open(self.path,'RZTP',key).resort_bytes())
   else:blob=bytes(SaveDocument.open(self.path,'RZTP').resort_bytes())
   good,_,_=resort_validate(blob)
   if not good:raise ValueError('Donor Sports2.dat CRC32 invalid')
   self.donor=blob; self.donorplayers=profile_names(blob)
   labels=[f'{idx:02d}: {name}' for idx,name in self.donorplayers]
   self.miicombo['values']=labels;self.donormii.set(labels[0] if labels else '')
   self.status.set(f'{len(labels)} named Miis found. Donor CRC32 valid. Select donor and preview.')
  except Exception as exc:messagebox.showerror('Cannot read donor',str(exc),parent=self)

 def _planned(self):
  if self.donor is None:raise ValueError('Choose a donor save')
  donor_label=self.donormii.get()
  if not donor_label:raise ValueError('Select donor Mii')
  srcidx=int(donor_label.split(':')[0]); copy=bytearray(self.doc.resort_bytes())
  summary=donor_merge(copy,self.targetidx,self.donor,srcidx,sport=self.sport.get(),skills=self.skills.get(),skill_history=self.fullhistory.get(),stamps=self.stamps.get(),records=self.records.get())
  changes=sum(a!=b for a,b in zip(copy,self.doc.resort_bytes()))
  return srcidx,copy,summary,changes
 def preview(self):
  try:
   srcidx,data,s,c=self._planned()
   self.status.set(f'Preview: {c} bytes changed before CRC. New skill entries: {s["skills_changed"]}; stamps added: {s["stamps_added"]}; personal records copied: {s["records_changed"]}.')
  except Exception as exc:messagebox.showerror('Preview error',str(exc),parent=self)
 def apply(self):
  try:
   srcidx,copy,s,count=self._planned()
   if count==0:return messagebox.showinfo('No changes','Everything selected is already identical or completed.',parent=self)
   if not messagebox.askyesno('Confirm cross-save import',f'Copy donor Mii {self.donormii.get()} into target slot {self.targetidx:02d}?\n\n{count} byte differences, {s["skills_changed"]} skill entries, {s["stamps_added"]} stamps and {s["records_changed"]} personal scores.\n\nOriginal source saves will not be overwritten.',parent=self):return
   resort_fix_checksum(copy)
   assert resort_validate(copy)[0]
   self.doc.resort_bytes()[:]=copy
   self.done();self.destroy()
  except Exception as exc:messagebox.showerror('Import failed',str(exc),parent=self)
