"""Audit-first Wii Sports Resort record consolidation.

Uses user-supplied Aaron98990/wii-inspect field map (via WSR_Known_Fields.py).
Reads all decrypted Sports2.dat files in --sources. Never overwrites originals.
Preserves target Mii identity and all other Mii slots.

The record eligibility thresholds are deliberately conservative review rules,
not assertions of mathematical impossibility. Every rejected value is logged.
"""
from __future__ import annotations
import argparse, csv, json, struct, sys
from pathlib import Path
from datetime import datetime
from collections import Counter
from WSR_Known_Fields import (
 PERSONAL_FIELDS,SPORT_SKILLS,STAMP_BASES,profile_names,read_record,read_skill,
 read_stamp,patch_skill,patch_record,offset,decode_stamp
)
from Wii_Score_Studio_Core import resort_validate,resort_fix_checksum

# Deliberately wide plausible bounds. Independent leaderboard data can be
# lower than a TAS result; these are human-review filters, not verified maxima.
CAPS={
 'Power Cruising':(0,260),
 'Archery':(0,120),
 'Frisbee Dog':(0,1500),
 'Basketball 3-Point':(0,60),
 'Bowling':(0,3000),
 'Canoeing':(0,600),
 'Table Tennis Return':(0,999),
 'Wakeboarding':(0,6500),
 'Island Flyover':(0,1000),
 'Skydiving':(0,500),
}
# Conservative ceilings for the magnitude of a better-than-par golf result.
# These are record-selection guards, NOT mathematical golf limits.
LOWER_GOLF={
 'Resort A':-9,'Resort B':-9,'Resort C':-10,
 'Classic A':-9,'Classic B':-9,'Classic C':-10,
 '3 holes Special':-9,'9 holes Resort':-20,'9 holes Classic':-22,'18 holes':-35
}
LOWER_FRISBEE={
 'Resort A':-8,'Resort B':-8,'Resort C':-8,
 'Classic A':-8,'Classic B':-9,'Classic C':-8,
 '3 holes Special':-8,'9 holes Resort':-20,'9 holes Classic':-21,'18 holes':-36
}

def eligible(f,r):
 v=r['value']; raw=r['raw']
 if raw==0:
  return (False,'zero/unplayed or no improvement record')
 if f.sport=='Canoeing' and 'target' in f.mode:
  return (False,'target distance, not a high score')
 if f.fmt=='time_cs':
  return (20<=v<=600, 'outside 20–600-second review window' if not 20<=v<=600 else '')
 if f.sport in ('Golf','Frisbee Golf'):
  lo=(LOWER_GOLF if f.sport=='Golf' else LOWER_FRISBEE).get(f.mode,-10)
  return (lo<=v<=100, f'outside review range {lo}..100' if not lo<=v<=100 else '')
 if f.sport in CAPS:
  low,high=CAPS[f.sport]
  if f.sport=='Bowling':high=3000 if f.mode=='100-Pin' else 300
  if f.sport=='Island Flyover' and f.mode.startswith('I-Points'):high=80
  if f.sport=='Canoeing' and 'distance' in f.mode:
   # Review limits based on archived extreme values and public race charts;
   # not a claim these are the engine's true physical maxima.
   high={'Beginner distance':350,'Intermediate distance':440,'Expert distance':520}[f.mode]
  valid=low<v<=high
  return(valid, f'outside review range ({low},{high}]' if not valid else '')
 return (False,'unmapped scoring range')

def sort_best(f,item):
 val=item['value'];return val if f.fmt in ('s16_flag','time_cs') else -val

def load_sources(folder):
 arr=[]; rejected=[]
 for p in sorted(Path(folder).glob('Sports2*.dat')):
  try:
   b=p.read_bytes()
   if b[:4]!=b'WSP2':continue
   ok,_,_=resort_validate(b)
   if not ok:rejected.append((str(p),'CRC incorrect'));continue
   arr.append((p,b,profile_names(b)))
  except Exception as e:rejected.append((str(p),str(e)))
 return arr,rejected

def consolidate(target,idx,sources,out,duck='1:59.99',all_skill_history=False):
 target=Path(target);out=Path(out); original=target.read_bytes();valid,_,_=resort_validate(original)
 if not valid:raise ValueError('Target Sports2.dat CRC does not validate')
 names=profile_names(original)
 if idx not in dict(names):raise ValueError(f'No active Mii at index {idx}')
 data=bytearray(original);targetname=dict(names)[idx];audit=[];excluded=[]
 candidates={(f.sport,f.mode,f.off):[] for f in PERSONAL_FIELDS}
 stamps={(s,k):[] for s in range(20) for k in range(5)}
 skills={s:[] for s in range(19)}
 for p,src,miis in sources:
  for mi,name in miis:
   provenance={'filename':p.name,'path':str(p),'index':mi,'mii':name}
   for f in PERSONAL_FIELDS:
    r=read_record(src,f,mi)
    item={**provenance, 'field':f,'src':src, **r}
    ok,reason=eligible(f,r)
    if ok:candidates[(f.sport,f.mode,f.off)].append(item)
    elif r['raw']:
     excluded.append([f.sport,f.mode,str(r['shown']),p.name,mi,name,reason])
   for s in range(19):
    v=read_skill(src,mi,s,0)['score']
    if v==2500:skills[s].append({**provenance,'value':v})
   for s in range(20):
    for k in range(5):
     row=read_stamp(src,mi,s,k)
     if row['raw']:
      stampdate=decode_stamp(row['raw'])
      try:
       d=datetime.strptime(stampdate,'%Y-%m-%d %H:%M')
      except ValueError:continue
      if datetime(2009,1,1)<=d<=datetime(2026,11,10):
       stamps[(s,k)].append({**provenance,'date':d,'raw':row['raw']})
 recordchanges=0
 for f in PERSONAL_FIELDS:
  if f.sport=='Canoeing' and 'target' in f.mode:continue
  cand=candidates[(f.sport,f.mode,f.off)]
  orig=read_record(original,f,idx)
  if not cand:
   audit.append(['record',f.sport,f.mode,orig['shown'],orig['shown'],'unchanged','no eligible archived value','','',''])
   continue
  best=min(cand,key=lambda c:(sort_best(f,c),c['filename'],c['index']))
  # The aim is to build a plausible best record, including sanitizing a hacked target.
  # Keep score flag bytes together with the neighboring Golf/Frisbee score.
  ofs=offset(f,idx);so=offset(f,best['index']);n=4 if f.fmt=='s16_flag' else 2
  targetstart=ofs-2 if n==4 else ofs
  sourcestart=so-2 if n==4 else so
  if data[targetstart:targetstart+n]!=best['src'][sourcestart:sourcestart+n]:
   data[targetstart:targetstart+n]=best['src'][sourcestart:sourcestart+n]
   recordchanges+=1
  now=read_record(data,f,idx)
  audit.append(['record',f.sport,f.mode,orig['shown'],now['shown'],'merged','selected by conservative plausibility filter',best['filename'],best['index'],best['mii']])
 # Explicit, synthetic below-public-chart duckling time (user requested faster than WR).
 duckfield=next(f for f in PERSONAL_FIELDS if f.sport=='Canoeing' and f.mode=='Stray Ducklings time')
 before=read_record(data,duckfield,idx)['shown']
 if duck:
  patch_record(data,duckfield,idx,duck)
  audit.append(['synthetic', 'Canoeing','Stray Ducklings time',before,duck,'user-requested','faster than published 2:09.93; not an earned run','','',''])
 # Earliest *valid* acquired timestamp for each of 100 stamps.
 stampcount=0
 for s in range(20):
  for k in range(5):
   cand=stamps[(s,k)]
   old=read_stamp(data,idx,s,k)
   if not cand:
    audit.append(['stamp',STAMP_BASES[s][0],str(k+1),old['shown'],old['shown'],'unchanged','not found in archive','','',''])
    continue
   choice=min(cand,key=lambda x:(x['date'],x['filename'],x['index']))
   if choice['raw']!=old['raw']:
    struct.pack_into('>I',data,old['offset'],choice['raw']);stampcount+=1
   audit.append(['stamp',STAMP_BASES[s][0],str(k+1),old['shown'],decode_stamp(choice['raw']),'earliest archived', 'earliest across available Miis and saves',choice['filename'],choice['index'],choice['mii']])
 # Latest skill to 2500. Do not touch Mii ID, skill history metadata, past games.
 skillchanges=0
 for s,sp in enumerate(SPORT_SKILLS):
  old=read_skill(data,idx,s,0)['score']
  histories=list(range(25)) if all_skill_history else [0]
  for h in histories:
   if read_skill(data,idx,s,h)['score']!=2500:
    patch_skill(data,idx,s,h,2500);skillchanges+=1
  source=skills[s][0] if skills[s] else None
  audit.append(['skill',sp,'current/history',str(old),'2500','preset','2500 found in archived current entries; patch latest only by default',source['filename'] if source else '',source['index'] if source else '',source['mii'] if source else ''])
 resort_fix_checksum(data)
 if not resort_validate(data)[0]:raise AssertionError('CRC32 invalid after merge')
 assert len(data)==len(original)
 out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data)
 with out.with_suffix('.audit.csv').open('w',newline='',encoding='utf-8-sig') as fh:
  w=csv.writer(fh);w.writerow(['Category','Sport','Mode/stamp','Before','After','Action','Reason','Donor file','Donor Mii index','Donor name']);w.writerows(audit)
 with out.with_suffix('.excluded.csv').open('w',newline='',encoding='utf-8-sig') as fh:
  w=csv.writer(fh);w.writerow(['Sport','Mode','Value','Source file','Index','Name','Exclusion reason']);w.writerows(excluded)
 report={'target_source':str(target),'target_mii':targetname,'target_index':idx,'out':str(out),'source_files':len(sources),'record_changes':recordchanges,'stamp_changes':stampcount,'skill_entries_changes':skillchanges,'ducklings_override':duck,'checksum_before':original[12:16].hex(),'checksum_after':data[12:16].hex(),'changed_bytes':sum(x!=y for x,y in zip(original,data)), 'earned_stamps':sum(read_stamp(data,idx,s,k)['acquired'] for s in range(20) for k in range(5)), 'skills_2500':sum(read_skill(data,idx,s,0)['score']==2500 for s in range(19))}
 out.with_suffix('.summary.json').write_text(json.dumps(report,indent=2),encoding='utf-8');return report

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--target',required=True);ap.add_argument('--index',type=int,default=1);ap.add_argument('--sources',required=True);ap.add_argument('--output',required=True)
 ap.add_argument('--duck',default='1:59.99',help='Time or blank to retain archived best; uses time centiseconds')
 ap.add_argument('--all-skill-history',action='store_true')
 a=ap.parse_args();sources,bad=load_sources(a.sources)
 if bad:print('Rejected source files:',bad)
 if not sources:raise RuntimeError('No valid source Sports2.dat files')
 print(json.dumps(consolidate(a.target,a.index,sources,a.output,a.duck,a.all_skill_history),indent=2))
if __name__=='__main__':main()
