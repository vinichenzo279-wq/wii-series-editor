from pathlib import Path
from struct import unpack_from
from tempfile import TemporaryDirectory
import sys,zipfile,hashlib
sys.path.insert(0,str(Path(__file__).parent))
from WSR_Known_Fields import *
from Wii_Score_Studio_Core import resort_validate,resort_fix_checksum,SaveDocument
f=next(x for x in PERSONAL_FIELDS if x.sport=='Canoeing' and x.mode=='Stray Ducklings time')
assert f.off==0x8B9E and f.fmt=='time_cs'
raw=Path('/mnt/data/wii_save_research/Sports2_pal.dat');original=raw.read_bytes()
assert resort_validate(original)[0]
assert profile_names(original)[1]==(1,'Vincenzo')
assert read_skill(original,1,11,0)['score']==1296
beginner=next(x for x in PERSONAL_FIELDS if x.sport=='Canoeing' and x.mode=='Beginner distance')
assert read_record(original,beginner,1)['value']==274.81
assert sum(read_stamp(original,1,11,i)['acquired'] for i in range(5))==3
old=read_record(original,f,1)
assert old['offset']==0x9992 and old['shown']=='2:15.08' and old['raw']==13508,old
for value in ['2:15.08','2.15.08','135.08']:
 b=bytearray(original)
 patch_record(b,f,1,value)
 assert b[0x9992:0x9994]==b'\x34\xc4'
 assert read_record(b,f,1)['shown']=='2:15.08'
for value in ['2:14.99','2.14.99','134.99']:
 b=bytearray(original)
 patch_record(b,f,1,value)
 assert read_record(b,f,1)['shown']=='2:14.99'
 assert read_record(b,beginner,1)['shown']=='274.81'
 assert sum(read_stamp(b,1,11,i)['acquired'] for i in range(5))==3
 assert not resort_validate(b)[0]
 resort_fix_checksum(b)
 assert resort_validate(b)[0]
 assert {i for i,(before,after) in enumerate(zip(original,b)) if before!=after}<={12,13,14,15,0x9992,0x9993}
for t in ['9:59.999','11:00.00','1:60.00','0:02.333']:
 try:patch_record(bytearray(original),f,1,t)
 except (ValueError,ArithmeticError):pass
 else:raise AssertionError(f'Accepted invalid {t}')
# separate saved profile has a 2:00.35 result
b=Path('/mnt/data/wii_save_research/Sports2_wii_sports_resort_mine_50.dat').read_bytes()
assert read_record(b,f,0)['shown']=='2:00.35'
# preserve source file, write an exported clone with Dolphin ZIP
with TemporaryDirectory() as td:
 doc=SaveDocument.from_raw(raw)
 patch_record(doc.resort_bytes(),f,1,'2:14.99')
 resort_fix_checksum(doc.resort_bytes())
 zpath=Path(td)/'test.zip';doc.export_nand_zip(zpath)
 with zipfile.ZipFile(zpath) as z:
  blob=z.read('Wii/title/00010000/525A5450/data/Sports2.dat')
 assert resort_validate(blob)[0]
 assert read_record(blob,f,1)['shown']=='2:14.99'
assert raw.read_bytes()==original
print('PASS: known time 2:15.08, skill 1296, beginner 274.81, three stamps, 2:00.35 alternative, format editing, CRC repair, NAND ZIP, original intact')
