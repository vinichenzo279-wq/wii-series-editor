from pathlib import Path
from tempfile import TemporaryDirectory
import csv,struct,hashlib,sys,zipfile
from WSR_Player_Layout import *
from Wii_Score_Studio_Core import SaveDocument,resort_validate,resort_crc,resort_fix_checksum
p=Path('/mnt/data/wii_save_research/Sports2_pal.dat');s=p.read_bytes()
players=parse_miis(s)
assert len(players)>20,len(players)
assert players[0].index==0 and players[0].name=='BALKANBOYS'
assert players[1].name=='Vincenzo' and players[1].name_offset==0x90B4
assert players[4].name=='Viktor' and players[4].name_offset==0xBA90
assert players[5].name=='chenzo'
assert value_rows(s,1)[0]['value']==2500
assert value_rows(s,1)[0]['offset']==0x925E
assert value_rows(s,0)[0]['value']==1900
assert len(value_rows(s,3))==75
assert resort_validate(s)[0]
basehash=hashlib.sha256(s).hexdigest()
doc=SaveDocument.from_raw(p)
old=bytes(doc.resort_bytes());rows=value_rows(old,3)
flag=rows[0]['extra'];oldval=rows[0]['value']
newval=1500 if oldval!=1500 else 1501
prior,off=patch_candidate(doc.resort_bytes(),3,0,newval,resort_fix_checksum)
assert prior==oldval and doc.resort_bytes()[off+2]==flag
assert resort_validate(doc.resort_bytes())[0]
assert sum(x!=y for x,y in zip(old,doc.resort_bytes()))<=6
assert hashlib.sha256(p.read_bytes()).hexdigest()==basehash
with TemporaryDirectory() as t:
 path=Path(t)/'R6_TEST.zip';doc.export_nand_zip(path)
 with zipfile.ZipFile(path) as z:
  bb=z.read('Wii/title/00010000/525A5450/data/Sports2.dat')
  assert resort_validate(bb)[0]
  assert struct.unpack_from('>H',bb,off)[0]==newval
matches,total=candidates_for_score(s,1,'25',100,0)
assert isinstance(matches,list) and total>=0
# other region snapshot should have same stride and names
us=Path('/mnt/data/wii_save_research/Sports2_us.dat').read_bytes()
assert parse_miis(us)[0].index==0
assert len(parse_miis(us))>25
assert resort_validate(us)[0]
print('PASS: WSR PAL and US Mii name/stride decoding, tentative 75-field layout, CRC repair, one-field patch, untouched input, Dolphin ZIP export')
