#!/usr/bin/env python3
"""Wii Score Studio R4: reversible save edits for London 2012 and Wii Sports Resort.

No personal saves are embedded. Reads encrypted Wii SD data.bin, Dolphin NAND folders,
raw files, or zip archives. Exports the *decrypted* Dolphin NAND representation only:
encrypted SD data.bin requires new ECC signatures, not provided here.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from decimal import Decimal, InvalidOperation
from typing import Dict, Optional
import io, json, re, struct, zipfile, zlib

SD_KEY=bytes.fromhex('ab01b9d8e1622b08afbad84dbfc2a55d')
SD_IV=bytes.fromhex('216712e6aa1f689f95c5a22324dc6a98')
TITLES={'SIIP':'0001000053494950','RZTP':'00010000525A5450','RZTE':'00010000525A5445','RSPP':'0001000052535050','RSPE':'0001000052535045','RHAP':'0001000052484150','RHAE':'0001000052484145'}
from London_Event_Catalog import EVENTS, human_score, parse_typed, SHOOTING_EVENT, SHOOTING_SECONDARY_DELTA, parse_shooting_time, format_shooting_time
LONDON_EVENTS={i:m["name"] for i,m in EVENTS.items()}

LONDON_HEAD=0x424; LONDON_STRIDE=0x364; LONDON_EVENT_COUNT=31


def aes_cbc_decrypt(buf:bytes, iv:bytes)->bytes:
    try:
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    except ImportError as e:
        raise RuntimeError('Install cryptography to open encrypted Wii SD exports: py -3 -m pip install cryptography') from e
    c=Cipher(algorithms.AES(SD_KEY), modes.CBC(iv)).decryptor()
    return c.update(buf)+c.finalize()


def check_system(buf):
    return len(buf)==65536 and buf[:8]==bytes.fromhex('0000000100030060')


def london_checksum(buf:bytes)->int:
    """Mario & Sonic London 2012: BE32 sum over entire 64 KiB System,
    treating stored checksum at 0x70..0x73 as zero. Confirmed on nine valid saves.
    """
    if not check_system(buf):raise ValueError('Not a valid 65536-byte London System structure')
    # Sum all original words and subtract the stored checksum word, avoiding a
    # 64K copy. Since the checksum occupies exactly one BE32 word, this is
    # equivalent to setting it to zero before summation.
    words=(v[0] for v in struct.iter_unpack('>I',buf))
    return (sum(words)-struct.unpack_from('>I',buf,0x70)[0]) & 0xFFFFFFFF


def london_validate(buf:bytes):
    expected=struct.unpack_from('>I',buf,0x70)[0]
    calculated=london_checksum(buf)
    return expected==calculated,expected,calculated


def london_repair_checksum(buf:bytearray)->int:
    value=london_checksum(buf)
    struct.pack_into('>I',buf,0x70,value)
    return value


def resort_crc(buf: bytes)->int:
    if buf[:4]!=b'WSP2' or len(buf)<0x20:raise ValueError('Not a Wii Sports Resort Sports2.dat (WSP2)')
    end=struct.unpack_from('>I',buf,8)[0]
    if end<0x10 or end>len(buf):raise ValueError(f'Invalid WSR checksum end 0x{end:X}')
    return zlib.crc32(buf[0x10:end]) & 0xffffffff


def resort_validate(buf:bytes):
    expected=struct.unpack_from('>I',buf,12)[0]
    got=resort_crc(buf)
    return expected==got,expected,got


def resort_fix_checksum(buf:bytearray):
    crc=resort_crc(buf)
    struct.pack_into('>I',buf,12,crc)
    return crc


def scan_save_zips(zip_path, game=None):
    with zipfile.ZipFile(zip_path) as z:
        found=[]
        for n in z.namelist():
            norm=n.replace('\\','/')
            if norm.lower().endswith('/data.bin') or norm.lower()=='data.bin':
                match=re.search(r'/(SIIP|RZTP|RZTE|RSPP|RSPE|RHAP|RHAE)/data\.bin$',norm,re.I)
                g=match.group(1).upper() if match else None
                if not game or g==game:found.append((n,g))
            elif norm.lower().endswith('/slot00/system') or norm.lower()=='sports2.dat':
                # Decrypted source folder in a zip: supported through separate raw extraction
                pass
        return found


def decode_sd_archive(data:bytes):
    if len(data)<0xf140 or data[0xf0c4:0xf0c6]!=b'Bk':
        raise ValueError('Not a Wii SD backup data.bin')
    banner=aes_cbc_decrypt(data[:0xf0c0],SD_IV)
    title=banner[:8].hex().upper()
    game=next((g for g,t in TITLES.items() if title==t),None)
    if not game:raise ValueError(f'Unsupported Wii save title {title}')
    # Wii SD exports place the original decrypted NAND banner.bin at offset 0x20
    # of their encrypted archive header. Earlier versions silently lost it,
    # producing an incomplete Dolphin NAND folder during Save As export.
    banner_len=struct.unpack_from('>I',banner,8)[0]
    if not (0x72a0<=banner_len<=0xf0a0 and 0x20+banner_len<=len(banner)):
        raise ValueError(f'Invalid Wii banner size 0x{banner_len:X}')
    if banner[0x20:0x24]!=b'WIBN':
        raise ValueError('Wii SD archive lacks a valid WIBN banner')
    n=struct.unpack_from('>I',data,0xf0cc)[0]
    if n>1000:raise ValueError('Suspicious file count')
    off=0xf140; entries={'banner.bin':bytearray(banner[0x20:0x20+banner_len])}
    for idx in range(n):
        h=data[off:off+0x80]
        if len(h)!=0x80 or h[:4]!=bytes.fromhex('03adf17e'):
            raise ValueError(f'Invalid file header {idx}, offset 0x{off:X}')
        size=struct.unpack_from('>I',h,4)[0]
        typ=h[0x0a]
        name=h[0x0b:0x50].split(b'\0')[0].decode('utf-8','replace')
        name=name.replace('\\','/')
        if not name or any(part in ('.','..') for part in name.split('/')) or name.startswith('/'):
            raise ValueError('Unsafe save entry '+name)
        if typ==1:
            enc_len=(size+63)//64*64
            raw=data[off+0x80:off+0x80+enc_len]
            if len(raw)!=enc_len:raise ValueError('Truncated save payload')
            v=aes_cbc_decrypt(raw,h[0x50:0x60])[:size]
            entries[name]=bytearray(v)
        elif typ==2:
            entries.setdefault(name,None)
            enc_len=0
        else:raise ValueError(f'Unknown save file type {typ}')
        off+=0x80+enc_len
    return game,entries


def check_source(game:str,entries:dict):
    if game=='SIIP':
        names=[f'Slot{i:02d}/System' for i in range(4)]
        actual=[x for x in names if x in entries and entries[x] is not None]
        if not actual:raise ValueError('No London 2012 SlotXX/System found')
        for x in actual:
            if not check_system(entries[x]):raise ValueError('Unrecognized System file: '+x)
    elif game in ('RHAP','RHAE'):
        from WP_Play import verify
        if 'RPParty.dat' not in entries or entries['RPParty.dat'] is None:
            raise ValueError('Missing Wii Play RPParty.dat')
        if not verify(entries['RPParty.dat'])[0]:raise ValueError('Wii Play checksum mismatch')
    elif game in ('RSPP','RSPE'):
        from WS_Original import verify
        if 'RPSports.dat' not in entries or entries['RPSports.dat'] is None:
            raise ValueError('Missing original Wii Sports RPSports.dat')
        if not verify(entries['RPSports.dat'])[0]:raise ValueError('Wii Sports checksum mismatch')
    else:
        if 'Sports2.dat' not in entries or not entries['Sports2.dat']:
            raise ValueError('No Sports2.dat in Wii Sports Resort save')
        if entries['Sports2.dat'][:4]!=b'WSP2':raise ValueError('Invalid WSR file magic')


@dataclass
class SaveDocument:
    game:str
    entries:Dict[str,Optional[bytearray]]
    description:str=''
    baseline:dict=field(default_factory=dict)
    @classmethod
    def from_data_bin(cls,data:bytes,source:str=''):
        game,entries=decode_sd_archive(data)
        check_source(game,entries)
        return cls(game,entries,source,{k:bytes(v) if v is not None else None for k,v in entries.items()})
    @classmethod
    def from_folder(cls,path:Path,game_hint=None):
        p=Path(path)
        if not p.is_dir():raise ValueError('Choose a folder')
        # Accept Dolphin's `data` folder, its parent, or a directory with `Slot00/System`.
        candidates=[p,p/'data']
        for game,t in TITLES.items():
            candidates += [p/'Wii'/'title'/'00010000'/t[-8:]/'data',p/'title'/'00010000'/t[-8:]/'data']
        for folder in candidates:
            if not folder.is_dir():continue
            # Avoid recursively scanning an entire Dolphin User directory.
            if not any((folder/x).is_file() for x in ('Sports2.dat','RPSports.dat','RPParty.dat')) and not any((folder/f'Slot{i:02d}'/'System').is_file() for i in range(4)):
                continue
            entries={}
            for f in folder.rglob('*'):
                key=f.relative_to(folder).as_posix()
                if f.is_dir():entries[key]=None
                elif f.is_file(): entries[key]=bytearray(f.read_bytes())
            try:
                game=('SIIP' if any(x.endswith('/System') for x in entries) else
                      ('RZTE' if '525a5445' in str(folder).lower() else 'RZTP') if 'Sports2.dat' in entries else
                      ('RSPE' if '52535045' in str(folder).lower() else 'RSPP') if 'RPSports.dat' in entries else
                      ('RHAE' if '52484145' in str(folder).lower() else 'RHAP') if 'RPParty.dat' in entries else None)
                if game:check_source(game,entries)
                else:continue
                return cls(game,entries,str(folder),{k:bytes(v) if v is not None else None for k,v in entries.items()})
            except ValueError:continue
        raise ValueError('No recognized Dolphin save folder found (System / Sports2.dat / RPSports.dat / RPParty.dat)')
    @classmethod
    def from_raw(cls,path:Path,game_hint=None):
        p=Path(path)
        data=p.read_bytes()
        if check_system(data):
            name=f'Slot{int(p.parent.name[4:6]):02d}/System' if re.fullmatch(r'Slot[0-3][0-9]',p.parent.name) else 'Slot00/System'
            game='SIIP'
        elif data[:4]==b'WSP2':
            game=('RZTE' if ('_us' in p.name.lower() or 'rzte' in str(p).lower()) else 'RZTP')
            name='Sports2.dat'
        elif data[:8]==b'RPPT0000':
            game=('RHAE' if ('_us' in p.name.lower() or 'rhae' in str(p).lower()) else 'RHAP')
            name='RPParty.dat'
        elif data[:8]==b'RPSP0000':
            game=('RSPE' if ('_us' in p.name.lower() or 'rspe' in str(p).lower()) else 'RSPP')
            name='RPSports.dat'
        else: raise ValueError('Unrecognized raw System / Sports2.dat / RPSports.dat file')
        entries={name:bytearray(data)}
        check_source(game,entries)
        return cls(game,entries,str(p),{name:data})
    @classmethod
    def open(cls,path:Path,game=None,zip_entry=None):
        p=Path(path)
        if p.is_dir(): return cls.from_folder(p,game)
        if p.suffix.lower()=='.zip':
            choices=scan_save_zips(p,game if game=='SIIP' else None)
            if game in ('RZTP','RZTE'):
                choices=[x for x in choices if x[1] in ('RZTP','RZTE')]
            if game in ('RHAP','RHAE'):
                choices=[x for x in choices if x[1] in ('RHAP','RHAE')]
            if game in ('RSPP','RSPE'):
                choices=[x for x in choices if x[1] in ('RSPP','RSPE')]
            if not choices:raise ValueError('No Wii SD data.bin exports found inside zip')
            name=zip_entry or choices[0][0]
            if name not in dict(choices):raise ValueError('Selected data.bin path is not in ZIP')
            with zipfile.ZipFile(p) as z:return cls.from_data_bin(z.read(name),f'{p.name} → {name}')
        if p.name.lower()=='data.bin':return cls.from_data_bin(p.read_bytes(),str(p))
        return cls.from_raw(p,game)
    def _file(self,key):
        if key not in self.entries or self.entries[key] is None:raise ValueError('Missing '+key)
        return self.entries[key]
    @property
    def slots(self):
        return sorted(int(re.fullmatch(r'Slot(\d\d)/System',x).group(1)) for x,v in self.entries.items() if v is not None and re.fullmatch(r'Slot(\d\d)/System',x))
    @property
    def changes(self):
        return sum(bytes(x)!=self.baseline.get(k) for k,x in self.entries.items() if x is not None)
    def london_raw(self,slot:int,event:int):
        if not 0<=event<LONDON_EVENT_COUNT:raise ValueError('Event must be 0–30')
        return struct.unpack_from('>HH',self._file(f'Slot{slot:02d}/System'),LONDON_HEAD+LONDON_STRIDE*event)
    def london_display(self,slot:int,event:int):
        whole,part=self.london_raw(slot,event)
        return f'{whole}.{part:03d}' if part<1000 else f'{whole} + {part} [raw]'
    def london_human(self,slot:int,event:int):
        return human_score(event,*self.london_raw(slot,event))
    def london_patch_typed(self,slot:int,event:int,user_value):
        return self.london_patch_raw(slot,event,*parse_typed(event,user_value))
    def london_patch(self,slot:int,event:int,decimal_value):
        try:x=Decimal(str(decimal_value))
        except InvalidOperation:raise ValueError('Enter a decimal, e.g. 9.814')
        if not x.is_finite() or x<0 or x>=65536:raise ValueError('Out of range')
        whole=int(x); p=(x-Decimal(whole))*1000
        if p!=p.to_integral_value(): raise ValueError('Only three fractional digits are supported')
        return self.london_patch_raw(slot,event,whole,int(p))
    def london_patch_raw(self,slot,event,whole,part):
        whole=int(whole);part=int(part)
        if not (0<=whole<=65535 and 0<=part<=65535):raise ValueError('Each raw component must be 0..65535')
        blob=self._file(f'Slot{slot:02d}/System');off=LONDON_HEAD+LONDON_STRIDE*event
        old=struct.unpack_from('>HH',blob,off)
        struct.pack_into('>HH',blob,off,whole,part)
        london_repair_checksum(blob)
        return old
    def london_shooting_time_raw(self,slot:int):
        off=LONDON_HEAD+LONDON_STRIDE*SHOOTING_EVENT+SHOOTING_SECONDARY_DELTA
        return struct.unpack_from('>HH',self._file(f'Slot{slot:02d}/System'),off)
    def london_shooting_time(self,slot:int):
        return format_shooting_time(*self.london_shooting_time_raw(slot))
    def london_patch_shooting_time_raw(self,slot:int,whole:int,part:int):
        whole=int(whole);part=int(part)
        if not (0<=whole<=65535 and 0<=part<1000):raise ValueError('Time must be whole seconds plus 0–999 milliseconds')
        blob=self._file(f'Slot{slot:02d}/System')
        off=LONDON_HEAD+LONDON_STRIDE*SHOOTING_EVENT+SHOOTING_SECONDARY_DELTA
        old=struct.unpack_from('>HH',blob,off)
        struct.pack_into('>HH',blob,off,whole,part)
        london_repair_checksum(blob)
        return old
    def london_patch_shooting_time(self,slot:int,value:str):
        return self.london_patch_shooting_time_raw(slot,*parse_shooting_time(value))
    def london_compound(self,slot:int,event:int):
        first=self.london_human(slot,event)
        if event==SHOOTING_EVENT:return f'{first} / {self.london_shooting_time(slot)}'
        return first
    def resort_bytes(self):return self._file('Sports2.dat')
    def resort_read(self,offset,fmt):
        b=self.resort_bytes();n=TYPE_FORMATS[fmt][0]
        if not (0<=offset<=len(b)-n):raise ValueError('Offset outside the file')
        if fmt=='Hex 4':return b[offset:offset+4].hex(' ').upper()
        code,scale=TYPE_FORMATS[fmt][1:3]
        v=struct.unpack_from('>'+code,b,offset)[0]
        return str(Decimal(v)/Decimal(scale)) if scale!=1 else str(v)
    def resort_patch(self,offset,fmt,value):
        b=self.resort_bytes();n,code,scale=TYPE_FORMATS[fmt]
        if not (0x10<=offset<=len(b)-n):raise ValueError('Offset out of bounds or in WSR header')
        if fmt=='Hex 4':
            raw=bytes.fromhex(value.strip().replace('0x',''))
            if len(raw)!=4:raise ValueError('Enter exactly four hexadecimal bytes')
        else:
            try:x=Decimal(str(value))*Decimal(scale)
            except InvalidOperation:raise ValueError('Invalid number')
            if not x.is_finite() or x!=x.to_integral_value():raise ValueError(f'{fmt} cannot represent that precision exactly')
            try:raw=struct.pack('>'+code,int(x))
            except struct.error as ex:raise ValueError('Out of range for '+fmt) from ex
        old=bytes(b[offset:offset+n]);b[offset:offset+n]=raw
        resort_fix_checksum(b)
        return old
    def resort_search(self,value,fmt,limit=2000):
        if fmt=='Hex 4':raw=bytes.fromhex(value.strip())
        else:
            n,code,scale=TYPE_FORMATS[fmt]
            d=Decimal(value)*Decimal(scale)
            if d!=d.to_integral_value():raise ValueError('Not precisely representable')
            raw=struct.pack('>'+code,int(d))
        if not raw:raise ValueError('Empty search')
        b=self.resort_bytes();pos=0;results=[];total=0
        while (i:=b.find(raw,pos))!=-1:
            total+=1
            if len(results)<limit:results.append(i)
            pos=i+1
        return results,total
    def undo_all(self):
        for k,v in self.baseline.items():self.entries[k]=bytearray(v) if v is not None else None
    def _verify_integrity_before_export(self):
        if self.game=='SIIP':
            for slot in self.slots:
                key=f'Slot{slot:02d}/System'
                blob=self._file(key)
                # Repair stale checksums in old R5-edited saves too. When the
                # checksum is already correct, writing the same word preserves
                # the original System byte-for-byte.
                london_repair_checksum(blob)
                valid,stored,computed=london_validate(blob)
                if not valid:
                    raise ValueError(f'Could not repair London Slot{slot:02d} checksum')
        elif self.game in ('RHAP','RHAE'):
            from WP_Play import repair,verify
            save=self._file('RPParty.dat')
            repair(save)
            if not verify(save)[0]:raise ValueError('Could not repair Wii Play checksum')
        elif self.game in ('RSPP','RSPE'):
            from WS_Original import verify,fix_checksum
            save=self._file('RPSports.dat')
            fix_checksum(save)
            if not verify(save)[0]:raise ValueError('Could not repair Wii Sports checksum')
        elif self.game in ('RZTP','RZTE'):
            if bytes(self.resort_bytes())!=self.baseline.get('Sports2.dat'):
                resort_fix_checksum(self.resort_bytes())

    def export_nand_zip(self,path):
        self._verify_integrity_before_export()
        target=Path(path)
        if target.exists():raise ValueError('Output already exists. Choose a new name')
        title=TITLES[self.game][-8:]
        with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
            for key,v in self.entries.items():
                path=f'Wii/title/00010000/{title}/data/{key}'
                if v is None:z.writestr(path.rstrip('/')+'/',b'')
                else:z.writestr(path,v)
            z.writestr('INSTALL_README.txt',f'Wii Score Studio — {self.game}\n\nThis is a DECRYPTED Dolphin NAND save folder, NOT a signed SD data.bin.\n\nClose Dolphin. Back up its existing Wii/title/00010000/{title}/data folder.\nExtract the Wii/ directory from this ZIP into your active Dolphin user directory\n(usually Documents/Dolphin Emulator/ on Windows, or File > Open User Folder).\nAllow replacing the matching save files only after backing them up.\nStart the game and verify that edited records persist after a restart.\nIf successful, use Dolphin’s export Wii save command to make a signed data.bin.\n')
        return target
    def export_nand_folder(self,folder):
        self._verify_integrity_before_export()
        root=Path(folder);base=root/'Wii'/'title'/'00010000'/TITLES[self.game][-8:]/'data'
        files=[(base / Path(key),v) for key,v in self.entries.items()]
        existing=[str(p) for p,v in files if v is not None and p.exists()]
        if existing: raise ValueError('Would overwrite existing files; choose an empty destination: '+existing[0])
        for p,v in files:
            if v is None:p.mkdir(parents=True,exist_ok=True)
            else:
                p.parent.mkdir(parents=True,exist_ok=True)
                p.write_bytes(v)
        return base

# name : byte size, struct code, divisor (fixed point)
TYPE_FORMATS={
 'U8':(1,'B',1),'U16 BE':(2,'H',1),'S16 BE':(2,'h',1),
 'U16 / 10':(2,'H',10),'S16 / 10':(2,'h',10),
 'U16 / 100':(2,'H',100),'S16 / 100':(2,'h',100),
 'U32 BE':(4,'I',1),'S32 BE':(4,'i',1),'Hex 4':(4,'',1),
}
