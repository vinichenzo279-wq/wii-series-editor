"""Experimental Wii Play (RHAP/RHAE) RPParty.dat records.

Grounding: compared valid SD exports in user's 2025/2026 backups.
Each record starts at 0x2B + index * 0xCE, ID is first 13 bytes,
first five shooting scores at +0x0D, subsequent games have a one-byte
pre-score status followed by five big-endian uint32s (each 21 bytes).
Whole-file dual 16-bit checksum at 0x50A0, over bytes [0x0,0x50A0).

IMPORTANT: game ordering follows documented Wii Play event list and matching
score magnitudes, but not all labels have in-game validation. The 1-byte flags
must not be modified until decoded. Empty 0 scores are valid slots.
"""
import struct
from pathlib import Path

MAGIC=b'RPPT0000'
SIZE=0x8000
CHECKSUM_OFFSET=0x50A0
PLAYER_BASE=0x2B
PLAYER_STRIDE=0xCE
MAX_PLAYERS=100
GAMES=(
    'Shooting Range','Find Mii','Table Tennis','Pose Mii','Laser Hockey',
    'Billiards','Fishing','Charge!','Tanks!',
)

def checksum(buf):
    if len(buf)!=SIZE or buf[:8]!=MAGIC:
        raise ValueError('Not a 32-KiB Wii Play RPParty.dat')
    top=bottom=0
    for pos in range(0,CHECKSUM_OFFSET,2):
        word=(buf[pos]<<8)|buf[pos+1]
        top=(top+word)&0xffff
        bottom=(bottom+(word^0xffff))&0xffff
    return (top<<16)|bottom

def verify(buf):
    expected=struct.unpack_from('>I',buf,CHECKSUM_OFFSET)[0]
    calculated=checksum(buf)
    return expected==calculated,expected,calculated

def repair(buf):
    calculated=checksum(buf)
    struct.pack_into('>I',buf,CHECKSUM_OFFSET,calculated)
    return calculated

def id_offset(player):
    if not 0<=player<MAX_PLAYERS:raise ValueError('Player index must be 0–99')
    return PLAYER_BASE+PLAYER_STRIDE*player

def score_offset(player,game,rank=0):
    if not 0<=game<len(GAMES):raise ValueError('Game index must be 0–8')
    if not 0<=rank<5:raise ValueError('Rank index must be 0–4')
    off=id_offset(player)+13
    if game:off+=20+(game-1)*21+1
    return off+rank*4

def status_offset(player,game):
    if not 1<=game<=8:raise ValueError('Status flag not mapped for Shooting Range')
    return id_offset(player)+13+20+(game-1)*21

def player_identity(buf,player):
    raw=buf[id_offset(player):id_offset(player)+13]
    return raw.hex().upper()

def active_players(buf):
    # Last bytes of some inactive records may hold stale score data; treat the
    # complete 13-byte identity as the best available active-record test.
    return [i for i in range(MAX_PLAYERS) if any(buf[id_offset(i):id_offset(i)+13])]

def read_scores(buf,player,game):
    return [struct.unpack_from('>I',buf,score_offset(player,game,k))[0] for k in range(5)]

def read_status(buf,player,game):
    return None if game==0 else buf[status_offset(player,game)]

def patch_score(buf,player,game,rank,value):
    if not any(buf[id_offset(player):id_offset(player)+13]):
        raise ValueError('Inactive Mii record; refusing to initialize it')
    val=int(value)
    if val<0 or val>0xffffffff:raise ValueError('Score must be 0–4,294,967,295')
    off=score_offset(player,game,rank)
    old=struct.unpack_from('>I',buf,off)[0]
    struct.pack_into('>I',buf,off,val)
    repair(buf)
    return old

def snapshot(buf):
    return [{'index':i,'id':player_identity(buf,i),'games':{name:read_scores(buf,i,k) for k,name in enumerate(GAMES)}} for i in active_players(buf)]

if __name__=='__main__':
    import argparse,json
    p=argparse.ArgumentParser()
    p.add_argument('save',type=Path)
    p.add_argument('--set',nargs=4,metavar=('MII','GAME','RANK','SCORE'))
    p.add_argument('--output',type=Path)
    a=p.parse_args();b=bytearray(a.save.read_bytes())
    valid,stored,calculated=verify(b)
    if not valid:raise SystemExit(f'Invalid checksum stored={stored:08X}, expected={calculated:08X}')
    if a.set:
        if a.output is None or a.output.exists() or a.output.resolve()==a.save.resolve():
            raise SystemExit('Choose --output NEW_UNUSED_FILE; original will never be overwritten')
        m,g,r,score=map(int,a.set)
        print('old score=',patch_score(b,m,g,r,score))
        assert verify(b)[0]
        a.output.write_bytes(b)
        print('written=',a.output)
    else:print(json.dumps(snapshot(b),indent=2))
