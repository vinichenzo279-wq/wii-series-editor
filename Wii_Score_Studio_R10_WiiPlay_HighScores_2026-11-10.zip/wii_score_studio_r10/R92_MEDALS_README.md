# Wii Score Studio R9.2 — independent Resort medal editing

This updates the original R9 editor without changing its London/Wii Sports save formats.

**Resort achievement ranks are independent of current skills.** 0 = none,
3 = Pro silver, 4 = Superstar gold. Reaching a threshold awards a medal,
but dropping below the threshold does not revoke it.

- Resort labeled tab > **Rank medals (19)**: view and edit each medal regardless of skill.
- Independent medal preset: selected sport or all 19, including clearing a medal.
- Skill presets default to **preserve all medals**. Optional checkbox awards
  eligible medal(s) *upward only* when setting skill, without revoking any.
- The packaged consolidated Vico R9.2 save separately grants gold across 19
  sports as an intentional override. It does not enforce skill/medal agreement.
- This rank table has 25 byte positions for 19 skill sports, with gaps for
  other modes; mapping verified against 204 distinct archived Mii records.
- All edits repair the usual Resort CRC32. Originals are left untouched.

**Testing still needed:** in-game medals for the new consolidated save; the
R9.2 independent medal GUI operation; and the earlier R9.1 duckling record.
The existing R7 score/skill/stamp editors have already passed earlier user tests.
