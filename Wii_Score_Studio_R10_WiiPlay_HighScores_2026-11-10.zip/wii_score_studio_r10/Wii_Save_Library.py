#!/usr/bin/env python3
"""Read-only index of Nintendo Wii SD-export and Dolphin NAND title save folders.

Supported editor game IDs are separated from *discovered* save IDs. Discovering a
folder does not imply that its binary record layout has been reverse engineered.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import json, os, re

SUPPORTED = {
    'SIIP': ('Mario & Sonic: London 2012 (PAL)', 'London 2012'),
    'RZTP': ('Wii Sports Resort (PAL)', 'Wii Sports Resort'),
    'RZTE': ('Wii Sports Resort (USA)', 'Wii Sports Resort'),
    'RSPP': ('Wii Sports original (PAL)', 'Wii Sports original'),
    'RSPE': ('Wii Sports original (USA)', 'Wii Sports original'),
    'RHAP': ('Wii Play (PAL)', 'Wii Play'),
    'RHAE': ('Wii Play (USA)', 'Wii Play'),
}
TITLE_TYPES = {'00010000': 'Disc game', '00010001': 'Channel',
               '00010004': 'Game/channel', '00010002': 'System title'}
KNOWN_RESEARCH = {
    'RFNP':'Wii Fit (PAL)', 'RFNE':'Wii Fit (USA)',
    'RFPP':'Wii Fit Plus (PAL)', 'RFPE':'Wii Fit Plus (USA)',
}
BACKLOG = [
    ('Mario Party 8 / 9', 'Mini-game records and party statistics', 'Research only'),
    ('Rayman Wii games', 'Times, scores, challenges and unlocks', 'Research only'),
    ('Fortune Street', 'Game statistics, achievements, results', 'Research only'),
    ('Virtua Tennis 2009', 'Grand Slam / championship completion flags', 'Research only'),
    ('Wii Sports (training/medals)', 'Training medals, records and fitness-age fields', 'Under research; skills editable'),
    ('Wii Play', 'Per-minigame top five highscores', 'Experimental editing; in-game untested'),
    ('Wii Fit / Plus', 'Fitness records, scoreboards, exercise history', 'Research only'),
    ('Super Mario Galaxy 2', 'Progress and possible clear-time records', 'External format resources exist'),
    ('Donkey Kong Country Returns', 'Time trials, medal records and progress', 'Research only'),
    ("Kirby's Return to Dream Land", 'Challenge-stage times / medals', 'Research only'),
]
GAME_ID_RE = re.compile(r'^[A-Za-z0-9]{4}$')
HEX_ID_RE = re.compile(r'^[0-9a-fA-F]{8}$')

@dataclass(frozen=True)
class SaveLocation:
    game_id: str
    label: str
    kind: str                # "SD export" or "Dolphin NAND"
    path: Path               # data.bin or .../data folder
    title_type: str
    size: int
    editor: str | None       # London 2012, Wii Sports Resort, or None
    file_count: int

    @property
    def status(self):
        return 'Editable' if self.editor else 'Discovered · format not mapped'

    @property
    def pretty_size(self):
        return f'{self.size / 1048576:,.2f} MB' if self.size >= 1048576 else f'{self.size / 1024:,.1f} KB'


def ascii_low_id(hex8: str) -> str:
    """Decode four ASCII game-id bytes from NAND 8-hex-character low title ID."""
    if not HEX_ID_RE.fullmatch(hex8):
        return hex8.upper()
    raw = bytes.fromhex(hex8)
    try:
        out = raw.decode('ascii')
    except UnicodeDecodeError:
        return hex8.upper()
    return out if GAME_ID_RE.fullmatch(out) else hex8.upper()


def _one_level(path: Path):
    try:
        return sorted((x for x in path.iterdir() if x.is_dir() and not x.is_symlink()), key=lambda x:x.name.lower())
    except (OSError, PermissionError):
        return []


def _file_summary(folder: Path):
    """Inspect only data files at two levels; never traverse arbitrary game trees."""
    size = count = 0
    for child in _one_level(folder):
        try:
            for f in child.iterdir():
                if f.is_file() and not f.is_symlink():
                    size += f.stat().st_size
                    count += 1
        except OSError:
            pass
    try:
        for f in folder.iterdir():
            if f.is_file() and not f.is_symlink():
                size += f.stat().st_size
                count += 1
    except OSError:
        pass
    return size, count


def _label(game_id):
    return SUPPORTED.get(game_id, (KNOWN_RESEARCH.get(game_id,f'Unknown title ({game_id})'), None))


def _sd_roots(p: Path):
    # User may select <SD>, private, wii, title, or a single 4-letter ID folder.
    options = [p, p/'private'/'wii'/'title', p/'wii'/'title', p/'title',
               p/'private'/'wii', p/'wii', p/'private']
    return [x for x in dict.fromkeys(options) if x.is_dir()]


def _nand_roots(p: Path):
    # User may select Dolphin/User, Dolphin/User/Wii, title, or a title-type directory.
    options = [p, p/'Wii'/'title', p/'title', p/'User'/'Wii'/'title',
               p/'Dolphin Emulator'/'Wii'/'title', p/'saves'/'dolphin-emu'/'User'/'Wii'/'title']
    return [x for x in dict.fromkeys(options) if x.is_dir()]


def scan_save_folder(path: str | Path) -> list[SaveLocation]:
    """Discover title saves. No source file is opened for writing or decrypted."""
    p = Path(path).expanduser().resolve()
    if not p.is_dir():
        raise ValueError(f'Not a readable directory: {p}')
    found: dict[str, SaveLocation] = {}

    def sd_game(folder: Path):
        if not GAME_ID_RE.fullmatch(folder.name):
            return
        f = folder/'data.bin'
        if not f.is_file() or f.is_symlink():
            return
        try:
            size = f.stat().st_size
        except OSError:
            return
        game_id=folder.name.upper()
        label,editor = _label(game_id)
        found[str(f)] = SaveLocation(game_id,label,'SD export',f,'00010000',size,editor,1)

    def nand_game(folder: Path, category: str):
        if not HEX_ID_RE.fullmatch(folder.name):
            return
        data=folder/'data'
        if not data.is_dir() or data.is_symlink():
            return
        size,count=_file_summary(data)
        if count==0:
            return
        game_id=ascii_low_id(folder.name)
        label,editor=_label(game_id)
        found[str(data)] = SaveLocation(game_id,label,'Dolphin NAND',data,category,size,editor,count)

    for root in _sd_roots(p):
        sd_game(root)
        for child in _one_level(root):
            sd_game(child)

    for root in _nand_roots(p):
        # Direct selection of an individual save's 'data' directory.
        if root.name.lower() == 'data' and HEX_ID_RE.fullmatch(root.parent.name):
            nand_game(root.parent,root.parent.parent.name.lower() if root.parent.parent.name.lower() in TITLE_TYPES else 'unknown')
        # High title ID type/00010000/<low game ID>/data
        if root.name.lower() in TITLE_TYPES:
            for child in _one_level(root):
                nand_game(child,root.name.lower())
        # Low title ID hex can itself be selected.
        if HEX_ID_RE.fullmatch(root.name):
            nand_game(root,root.parent.name.lower() if root.parent.name.lower() in TITLE_TYPES else 'unknown')
        # Discover type directories one level down.
        for category in _one_level(root):
            if category.name.lower() in TITLE_TYPES:
                for child in _one_level(category):
                    nand_game(child,category.name.lower())
    return sorted(found.values(), key=lambda x:(0 if x.editor else 1,x.label.lower(),x.game_id,x.kind))


def _config_path():
    base = Path(os.environ['APPDATA']) if os.name == 'nt' and os.environ.get('APPDATA') else Path.home()/'.config'
    return base/'WiiScoreStudio'/'settings.json'


def get_saved_library_path() -> str:
    try:
        v=json.loads(_config_path().read_text(encoding='utf-8')).get('library_path','')
        return str(v) if isinstance(v,str) else ''
    except (OSError,ValueError,TypeError):
        return ''


def set_saved_library_path(path: str):
    """Remember only a folder path in local app settings, never game-save bytes."""
    dest = _config_path()
    dest.parent.mkdir(parents=True,exist_ok=True)
    temp=dest.with_suffix('.tmp')
    temp.write_text(json.dumps({'library_path':str(Path(path).expanduser().resolve())},indent=2),encoding='utf-8')
    temp.replace(dest)
