# Wii Score Studio R10 — Wii Play records

## What's new

* **Wii Play** (`RHAP` PAL and `RHAE` US) is the fourth integrated game. The Game Library recognizes both regions, scans SD `private/wii/title/` exports and Dolphin `Wii/title/` NAND folders, then opens the new **Wii Play — Nine Games** editor.
* Select the saved Mii by **index + raw 13-byte identity**, choose a game, and edit any of its **five ranked results**. **New top score** inserts a new best and shifts the previous top four down.
* Wii Play `RPParty.dat` checksum at `0x50A0` is rebuilt automatically (two 16-bit additive sums, protected range `[0, 0x50A0)`). Validated against two independent real backups. Score writes update only the selected four-byte score plus checksum bytes.
* Exports a **new decrypted Dolphin NAND ZIP/folder** preserving the original `banner.bin`. Never edits the original save in place. Re-export through Dolphin if an SD `data.bin` is required.
* London 2012, Wii Sports Resort (including independent skill medals and Stray Ducklings), and original Wii Sports skill editor remain included from R9.2.
* Wii Fit (RFNP/RFNE) and Wii Fit Plus (RFPP/RFPE) are now **recognized by name in the library**, but still research-only. User archives contain `FitPlus0.dat`, `FitPlus1.dat`, `FitPlus2.dat` and are available for analysis; no unsafe generic writes.

## Run on Windows

1. Unzip R10 and run `Launch_Wii_Score_Studio.bat` (Python 3 and tkinter needed). Install the crypto dependency only if the program asks for it (use `Install_Crypto_If_Needed.bat`).
2. Under **Game Library**, select a Dolphin user directory or `private/wii/title` directory and scan. Double-click `RHAP` (or use Open save in the Wii Play tab).
3. Choose one Mii, one minigame, and a saved rank. Select **Edit selected rank** or **New top score**.
4. Choose **Save as Dolphin ZIP**, back up your active save folder, and extract the new ZIP's `Wii/` into the active Dolphin user directory. The output is **not** a newly signed SD `data.bin`.
5. Launch Wii Play, confirm the edited score and that the original medals and other players are intact. Game-side acceptance has **not yet been tested**.

## Wii Play reverse-engineered layout

`RPParty.dat`, 32 KiB, magic `RPPT0000`.

- Checksum stored `0x50A0` as big-endian unsigned 32-bit integer. Sum every big-endian U16 word from offset `0x0000` through `0x509F`; accumulator A adds words, accumulator B adds one's complements; both wrap mod 65536, final `(A << 16) | B`. Verified `private.zip`: `2919AE97`, `private2.zip`: `2188B628`.
- 100 player records: index `i` raw identity starts at `0x2B + i * 0xCE`, 13 bytes. Records indexed by raw IDs; Wii Mii database names not yet decoded.
- Game 0 Shooting Range: five BE32 scores at Mii record `+0x0D + 4 * rank`.
- Games 1–8: each has a 1-byte status and five BE32 scores, `+0x0D+20+(game-1)*21`, then status (1 byte), then five ranked scores (20 bytes).
- Game order used: Shooting Range, Find Mii, Table Tennis, Pose Mii, Laser Hockey, Billiards, Fishing, Charge!, Tanks! This agrees with the user-provided approximate scores for a nine-game leaderboard. **The record category labels and status meaning are not all in-game verified**.
- Score edits preserve the status byte, all other Miis, the banner, and all other game save files. Changing a high score does not necessarily award a platinum medal; the editor does not alter such achievements automatically.

## Testing

**Passed on sample saves supplied by user:** 32-KiB detection, both checksums, 100-record stride indexing, top-five decoding, isolated score patch, status preservation, checksum update, SD-to-NAND export, banner preservation, GUI tab load/edit/export under Xvfb, and legacy regression tests for London/Resort and Game Library.

**Not verified in actual game:** Wii Play accepted score edits and medal/status semantics, original Wii Sports skill save, Resort's consolidated Mii and Quack% time. Individual edited London and Resort score/stamp/skill writes were previously reported accepted by the user.

## The next Wii Sports research target

Mii IDs and original Wii Sports skill floats are accessible in `RPSports.dat`, but **displayed skill ≠ opponent matchmaking strength** according to the user's gameplay experiments. Therefore the current skill-only presets don't imply suitably strong opponents. Training high scores, medal grades, fitness ages and opponent progression are still not decoded; they should be derived by game-code trace or before/after experiments. No adjacent bytes are labeled as these fields without evidence. A matching `RFL_DB.dat` would help map the player's stored identity bytes to Mii names.

## Wii Fit research

The supplied RFPP save holds `FitPlus0.dat` and `FitPlus1.dat` (606,208 bytes each; both begin `RPHE0000`) and `FitPlus2.dat` (245,760 bytes, `RFP@0000`). Existing sources describe date, Mii information and body test data for the first files. We have not yet mapped and checksum-tested Wii Fit's minigame scores, stamps, or unlocks. The Game Library recognizes it but won't edit it.

External background: `https://github.com/kaefert/wii-fit-parser`; Wii Play PAL identifier: `https://www.gametdb.com/Wii/RHAP01`.
