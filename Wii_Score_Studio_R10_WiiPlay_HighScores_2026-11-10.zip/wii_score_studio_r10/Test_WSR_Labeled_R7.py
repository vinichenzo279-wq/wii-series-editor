from pathlib import Path
import sys,zipfile,struct,hashlib
sys.path.insert(0,str(Path(__file__).parent))
from WSR_Known_Fields import *
from Wii_Score_Studio_Core import SaveDocument,resort_fix_checksum,resort_validate
src=Path('/mnt/data/wii_save_research/Sports2_pal.dat')
blob=src.read_bytes()
assert resort_validate(blob)[0]
players=profile_names(blob)
assert players[0][1]=='BALKANBOYS' and players[1][1]=='Vincenzo' and len(players)>10
sample=zipfile.ZipFile('/mnt/data/wii-inspect-master (1).zip').read('wii-inspect-master/personal/Sports2.dat')
assert resort_validate(sample)[0]
checks={
 ('Power Cruising','Beach'):'206.7',('Power Cruising','Lagoon'):'189.0',('Archery','Beginner'):'111',
 ('Frisbee Dog','Personal best'):'1500',('Basketball 3-Point','Personal best'):'27.0',
 ('Bowling','100-Pin'):'3000',('Canoeing','Beginner distance'):'250.55',('Canoeing','Expert distance'):'310.00',
 ('Canoeing','Beginner target'):'205.00',('Table Tennis Return','Personal best'):'328',
 ('Wakeboarding','Beginner'):'3437',('Skydiving','Personal best'):'209'
}
for key,correct in checks.items():
 f=next(x for x in PERSONAL_FIELDS if (x.sport,x.mode)==key)
 val=read_record(sample,f,0)['shown']
 assert val==correct,(key,val,correct)
print('SOURCE VERIFICATION: all',len(checks),'known score samples matched Aaron source outputs')
assert sum(read_stamp(sample,0,sp,k)['acquired'] for sp in range(20) for k in range(5))>70
assert read_stamp(blob,0,0,0)['shown']=='2025-12-06 13:53'
assert decode_stamp(encode_stamp('2023-08-17 23:59'))=='2023-08-17 23:59'
print('STAMP: exact timestamp decoding and encoding OK')
# True 3-byte fields: preserve middle byte + high nibble of third byte.
for ix in (0,1):
 for sport in range(19):
  for n in range(25):
   d=read_skill(blob,ix,sport,n)
   assert 0<=d['score']<=4095
p=read_skill(blob,1,0,0)
assert p['score']==2500
assert read_skill(blob,0,0,0)['score']==2000
m=bytearray(blob);prior=bytes(m)
q=read_skill(m,1,0,0)
where=patch_skill(m,1,0,0,2345)
assert where==q['offset'] and read_skill(m,1,0,0)['score']==2345
assert m[where+1]==prior[where+1] and (m[where+2]&0xf0)==(prior[where+2]&0xf0)
resort_fix_checksum(m);assert resort_validate(m)[0]
assert sum(a!=b for a,b in zip(m,blob))<=6
print('SKILL: packed 12-bit score patch preserves adjacent metadata and repairs CRC32')
# Edits supported by core: independent copy edits and export
p2=SaveDocument.from_raw(src)
before=bytes(p2.resort_bytes());before_hash=hashlib.sha256(src.read_bytes()).hexdigest()
scorefield=next(f for f in PERSONAL_FIELDS if f.sport=='Canoeing' and f.mode=='Beginner distance')
v=read_record(p2.resort_bytes(),scorefield,1)
patch_record(p2.resort_bytes(),scorefield,1,'123.45')
assert read_record(p2.resort_bytes(),scorefield,1)['shown']=='123.45'
assert not resort_validate(p2.resort_bytes())[0]
resort_fix_checksum(p2.resort_bytes()); assert resort_validate(p2.resort_bytes())[0]
sg=read_stamp(p2.resort_bytes(),1,0,0)
patch_stamp(p2.resort_bytes(),1,0,0,'2026-11-10 12:00')
assert read_stamp(p2.resort_bytes(),1,0,0)['shown']=='2026-11-10 12:00'
resort_fix_checksum(p2.resort_bytes()); assert resort_validate(p2.resort_bytes())[0]
assert hashlib.sha256(src.read_bytes()).hexdigest()==before_hash
import tempfile
with tempfile.TemporaryDirectory() as td:
 out=Path(td)/'WSR_R7_test.zip';p2.export_nand_zip(out)
 with zipfile.ZipFile(out) as z:
  s=z.read('Wii/title/00010000/525A5450/data/Sports2.dat')
  assert resort_validate(s)[0]
  assert read_record(s,scorefield,1)['shown']=='123.45'
  assert read_stamp(s,1,0,0)['shown']=='2026-11-10 12:00'
print('EXPORT: modified copy, NAND ZIP, original unchanged, CRC32 valid')
