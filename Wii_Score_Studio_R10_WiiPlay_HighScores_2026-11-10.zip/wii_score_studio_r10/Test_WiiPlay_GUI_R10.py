import tempfile,zipfile,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from Wii_Score_Studio_GUI import App
from WP_Play import read_scores,verify,patch_score
if __name__=='__main__':
    path=Path(sys.argv[1])
    with zipfile.ZipFile(path) as z:
      source=next(n for n in z.namelist() if n.lower().endswith('/rhap/data.bin'))
    app=App()
    app.withdraw()
    app.wii_play.open_document(path,source)
    assert app.wii_play.mii_box['values']
    assert app.wii_play.tree.get_children()
    p=int(app.wii_play.mii.get().split('|')[0]);v=read_scores(app.wii_play.doc._file('RPParty.dat'),p,0)[0]
    patch_score(app.wii_play.doc._file('RPParty.dat'),p,0,0,v+20)
    app.wii_play.render()
    assert int(app.wii_play.tree.item('0','values')[1])==v+20
    assert verify(app.wii_play.doc._file('RPParty.dat'))[0]
    with tempfile.TemporaryDirectory() as temp:
      out=Path(temp)/'edited.zip';app.wii_play.doc.export_nand_zip(out)
      with zipfile.ZipFile(out) as z:assert read_scores(z.read('Wii/title/00010000/52484150/data/RPParty.dat'),p,0)[0]==v+20
    app.destroy()
    print('PASS GUI Wii Play: loaded Mii, viewed nine games, edited score, exported.')
