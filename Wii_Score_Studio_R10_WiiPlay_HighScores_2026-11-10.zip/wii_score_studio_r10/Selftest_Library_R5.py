#!/usr/bin/env python3
"""R5: title discovery uses folders only; saves remain unchanged."""
from __future__ import annotations
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
import hashlib,os,struct,zipfile
from Wii_Save_Library import ascii_low_id,scan_save_folder,get_saved_library_path,set_saved_library_path
from Wii_Score_Studio_Core import SaveDocument,london_repair_checksum,london_validate,resort_crc,resort_validate

assert ascii_low_id('53494950')=='SIIP'
assert ascii_low_id('525A5450')=='RZTP'
assert ascii_low_id('525a5445')=='RZTE'
assert ascii_low_id('00AA00BB')=='00AA00BB'

with TemporaryDirectory() as tmp:
 root=Path(tmp)
 # SD save hierarchy, including two unknown game IDs.
 sd=root/'sdcard'/'private'/'wii'/'title'
 (sd/'SIIP').mkdir(parents=True)
 (sd/'SIIP'/'data.bin').write_bytes(b'fake sample SD data')
 (sd/'RZTP').mkdir()
 (sd/'RZTP'/'data.bin').write_bytes(b'fake sample Resort SD data')
 (sd/'ABCE').mkdir()
 (sd/'ABCE'/'data.bin').write_bytes(b'unknown but valid for scanning')
 (sd/'XYZP').mkdir()
 (sd/'XYZP'/'content.bin').write_bytes(b'not a save')
 for candidate in [root/'sdcard',root/'sdcard'/'private',root/'sdcard'/'private'/'wii',sd,sd/'SIIP']:
  result=scan_save_folder(candidate)
  assert any(x.game_id=='SIIP' for x in result), (candidate,result)
  assert all(x.path.name=='data.bin' for x in result)
  assert all(x.game_id!='XYZP' for x in result)
 result=scan_save_folder(sd)
 assert len(result)==3 and len([x for x in result if x.editor])==2
 assert next(x for x in result if x.game_id=='ABCE').editor is None
 assert next(x for x in result if x.game_id=='SIIP').kind=='SD export'

 nand=root/'Dolphin'/'User'/'Wii'/'title'/'00010000'
 l=nand/'53494950'/'data'/'Slot03'
 l.mkdir(parents=True)
 london=bytearray(65536);london[:8]=bytes.fromhex('0000000100030060');struct.pack_into('>HH',london,0x0e50,9,814);london_repair_checksum(london)
 (l/'System').write_bytes(london)
 r=nand/'525A5445'/'data';r.mkdir(parents=True)
 resort=bytearray(0x130);resort[:4]=b'WSP2';struct.pack_into('>I',resort,8,0x100);struct.pack_into('>I',resort,12,resort_crc(resort))
 (r/'Sports2.dat').write_bytes(resort)
 unknown=nand/'41424350'/'data';unknown.mkdir(parents=True)
 (unknown/'record.dat').write_bytes(b'RANDOM UNKNOWN SAVE BYTES')
 for parent in [root/'Dolphin'/'User',root/'Dolphin'/'User'/'Wii',nand.parent,nand,nand/'53494950']:
  result=scan_save_folder(parent)
  assert any(x.game_id=='SIIP' for x in result), (parent,result)
  assert any(x.kind=='Dolphin NAND' for x in result)
 result=scan_save_folder(nand)
 assert len(result)==3,(result)
 assert {x.game_id for x in result}=={'SIIP','RZTE','ABCP'}
 assert {x.file_count for x in result}=={1}
 for game in ('SIIP','RZTE'):
  entry=next(x for x in result if x.game_id==game)
  doc=SaveDocument.open(entry.path)
  assert doc.game==game,(doc.game,game)
  if game=='SIIP':assert doc.london_raw(3,3)==(9,814)
  else:assert resort_validate(doc.resort_bytes())[0]
  source=next(f for f in entry.path.rglob('*') if f.is_file())
  before=hashlib.sha256(source.read_bytes()).digest()
  if game=='SIIP':
   doc.london_patch(3,3,'9.999')
   assert london_validate(doc.entries['Slot03/System'])[0]
  else:doc.resort_patch(0x80,'U16 BE','7')
  with TemporaryDirectory() as out:
   result_path=Path(out)/'export.zip'
   doc.export_nand_zip(result_path)
   assert result_path.is_file()
  assert hashlib.sha256(source.read_bytes()).digest()==before,'Source was accidentally mutated'

 with patch('Wii_Save_Library._config_path',return_value=root/'settings'/'settings.json'):
  assert get_saved_library_path()==''
  set_saved_library_path(sd)
  assert get_saved_library_path()==str(sd.resolve())
print('PASS: SD and Dolphin NAND folder discovery at multiple parent levels, region IDs, unknown games, read-only scan, editing in memory, Save As export, settings persistence.')
