from pathlib import Path
from tempfile import TemporaryDirectory
import csv,zipfile,struct
from London_Event_Catalog import parse_shooting_time, format_shooting_time
from Wii_Score_Studio_Core import SaveDocument, london_validate
root=Path('/mnt/data/wii_save_research')
old=SaveDocument.from_folder(root/'2012_older')
new=SaveDocument.from_folder(root/'2012_newer')
assert len(new.slots)==4
expected={0:(454,0,45,810),1:(352,0,43,480),2:(480,0,12,480),3:(480,0,11,290)}
for slot,(score,part,sec,ms) in expected.items():
 assert new.london_raw(slot,12)==(score,part)
 assert new.london_shooting_time_raw(slot)==(sec,ms)
assert old.london_raw(1,12)==(344,0) and old.london_shooting_time(1)=='0:41.760'
assert new.london_compound(3,12)=='480 pts / 0:11.290'
assert parse_shooting_time('0:38.860')==(38,860)
assert parse_shooting_time('38.86 seconds')==(38,860)
assert parse_shooting_time('1:23.456')==(83,456)
assert format_shooting_time(83,456)=='1:23.456'
for val in ('1:74.999','0:38.8601','-1','nonsense','999999999'):
 try:parse_shooting_time(val)
 except (ValueError, ArithmeticError):pass
 else:raise AssertionError('bad time accepted: '+val)
prev=bytes(new.entries['Slot03/System'])
new.london_patch_shooting_time(3,'0:38.860')
after=bytes(new.entries['Slot03/System'])
diffs={i for i,(a,b) in enumerate(zip(prev,after)) if a!=b}
assert diffs and diffs<={0x70,0x71,0x72,0x73,0x2f18,0x2f19,0x2f1a,0x2f1b},diffs
assert london_validate(after)[0]
assert new.london_raw(3,12)==(480,0)
new.london_patch_typed(3,12,'476')
assert new.london_shooting_time(3)=='0:38.860'
new.london_patch_typed(3,3,'9.999')
assert new.london_raw(3,3)==(9,999)
with TemporaryDirectory() as temp:
 p=Path(temp)/'edited.zip'
 new.export_nand_zip(p)
 with zipfile.ZipFile(p) as z:
  blob=z.read('Wii/title/00010000/53494950/data/Slot03/System')
  assert struct.unpack_from('>HH',blob,0x2cd4)==(476,0)
  assert struct.unpack_from('>HH',blob,0x2f18)==(38,860)
  assert struct.unpack_from('>HH',blob,0xe50)==(9,999)
  assert len(blob)==65536
  assert london_validate(blob)[0]
new.undo_all()
assert new.london_shooting_time(3)=='0:11.290' and new.london_raw(3,3)==(9,814)
print('PASS: eight shooting points/time snapshot pairs, independent time edit, correct +0x244 field, no collateral changes, ZIP export, and undo')
