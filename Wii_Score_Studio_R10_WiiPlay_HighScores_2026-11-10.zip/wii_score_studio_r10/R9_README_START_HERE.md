# Wii Score Studio R9 — London 2012, Wii Sports Resort, and original Wii Sports

## Launch

Extract the `Wii_Score_Studio_R9...zip` to a local folder and double-click `Launch_Wii_Score_Studio.bat`. Windows Python 3 and Tkinter are required. If encrypted SD `data.bin` loading needs `cryptography`, run `Install_Crypto_If_Needed.bat` once.

**Game Library:** select a `private/wii/title` folder or a Dolphin `User/Wii/title` folder. The scanner recognizes game IDs automatically. The existing London 2012 and Resort tabs are retained.

**New:** `Wii Sports — Float32 Skills` accepts PAL `RSPP` and US `RSPE` encrypted Wii exports, extracted Dolphin save folders or raw 131,072-byte `RPSports.dat` files. Select an **active Mii record by numerical slot and raw Mii ID**. You can edit the exact four-byte float or use presets for the independently confirmed maximum skill in each sport. The user-supplied values were: Tennis `4515FFF6`, Baseball `45528324`, Bowling `450A5FFF`, Golf `4558653D`, Boxing `45434FFF`. The sport label order follows the main Wii Sports menu, consistent with the five 0x79-spaced floats; it has *not* been independently confirmed via a one-sport savestate before/after test. The player name cannot be derived from the raw IDs without a verified Mii database map; don't assume player index 0 is your main Mii.

Original Wii Sports save checksum: 32-bit total at `0x1B190` is (sum16 of all BE16 words from `0` through `0x1B18F` << 16) | (sum16 of each word XOR 0xFFFF). Verified against both the user's and Aaron's real `RPSports.dat` files. The read/write code repairs it automatically. Actual Wii Sports in-game acceptance is not yet tested. Training medals, training records, Wii Fitness age and per-Mii migration are **NOT** decoded yet.

**Resort:** all 19 skills, 100 stamps, known personal/Wii-wide fields including Stray Ducklings, existing R8.1 batch edits and donor merge, and CRC32 repair remain available. **London:** the in-game-validated checksum-corrected high-score editing remains unchanged.

**Save:** `Save as Dolphin ZIP` writes an *unencrypted NAND save*, including the original `banner.bin` and any other files in the source. It is **not** a re-signed Wii SD `data.bin`. Back up the matching folder and extract `Wii/` into Dolphin's user directory with Dolphin closed; load and test. Do not replace your only original save.

## Resort best-score consolidation (separate completed test file)

`WSR_R9_Consolidated_Current_Vico_Dolphin_IMPORT.zip` was generated from the user's newest supplied encrypted `private.zip` PAL `RZTP` save, target **Vico at Mii index 1**. It leaves the Mii's identity, every other Mii and Wii-wide records untouched.

The consolidation sets the newest entry in each of 19 skill histories to 2500, unites the earliest valid stamp acquisition timestamps found for each of 100 stamps across the available archived Miis and saves, and selects the strongest candidate personal scores within **conservative review ranges**. It explicitly excludes Archery above 120; very high Wakeboarding and Power Cruising records; and extraordinarily low Golf/Frisbee Golf numbers. Those review ranges are not proven maximum legal limits, especially for TAS. The complete `*.audit.csv` and `*.excluded.csv` explain each decision, including any value replaced with a worse-looking but more plausible score.

Stray Ducklings is deliberately changed to **1:59.99**, an artificial user-requested time, distinct from genuine historical results. The online leaderboard checked showed **2:09.93**, and the best archived user value was already **2:00.35**. That particular edit still awaits in-game testing.

To regenerate from your own raw `Sports2.dat` archive files, use:

```
python WSR_Consolidate_R9.py --target path/to/Sports2.dat --index 1 --sources path/to/decrypted_archives --output consolidated.dat
```

The CLI scans `Sports2*.dat` directly inside the chosen source directory; it does not read encrypted `data.bin` by itself. It writes a new raw save plus source audit/exclusion CSVs, never overwriting input. See `WSR_Consolidate_R9.py` for the clearly annotated review thresholds. To make an encrypted-sourced *complete* Dolphin NAND ZIP from such output, open the original full save in Wii Score Studio and import/edit the matching raw file or use the provided completed import ZIP.

## Wii Sports next research

- The original saves have fixed-size Mii records starting at `0x5F + index*0x455`; Mii ID and system ID follow a status byte, with further identity metadata. 100 nominal slots; four are active in the supplied user save. `RFL_DB.dat` from the same Dolphin/Wii Mii database would help resolve actual names and Mii migration.
- Float skills are BE IEEE-754 values at per-player relative offsets `0x0E`, `0x87`, `0x100`, `0x179`, and `0x1F2`.
- Each sport occupies approximately `0x79` bytes between consecutive skill floats. This is the likely next region to inspect for training records/medals; their exact offsets remain unknown.
- Wii Fitness ages and Mii-linked lifetime records may be elsewhere in the same `0x455`-byte block; they must not be edited blindly.

## Verification

Static tests passed on the real archives: the original Wii Sports checksums of two independent saves; an exact-precision Tennis change and checksum repair with only four score/checksum bytes changed; correct Wii title ID and `banner.bin` in exported ZIP; Resort's consolidation checksum and preservation of non-target player data; existing London/Resort parse/edit tests and GUI smoke. **No in-game Wii Sports or consolidated Resort validation has yet happened.**
