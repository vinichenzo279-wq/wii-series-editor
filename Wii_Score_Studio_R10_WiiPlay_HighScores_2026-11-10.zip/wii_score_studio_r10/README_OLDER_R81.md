# Wii Score Studio R8.1 — Stray Ducklings discovered

## What's new

**Wii Sports Resort → Resort — Scores / Skills / Stamps → Personal scores → Canoeing** now includes **Stray Ducklings time**. Use `M:SS.hh` (e.g. `2:15.08`) or total seconds (`135.08`) when editing. `0` clears the field; an unrecorded value displays as `not recorded`.

Confirmed by the user-provided Wii Sports Resort PAL save: Mii record 1 `Vincenzo`, current Canoeing skill **1296**, Beginner distance **274.81 m**, exactly **three** Canoeing stamps, and Stray Ducklings **2:15.08**. The save encodes the time as **13508** centiseconds (hex `34 C4`) at `Sports2.dat + 0x9992`. Relative per-Mii offset is `0x8B9E + 0xDF4 × Mii index`. This is the seventh Canoeing score field, after Aaron's six mapped scores. The previous release R7 did not include this field.

Independent archive cross-checks: an older `Vico` has **2:00.35**, `Rizen` **3:14.23**, `Arnold` **5:02.48**, and `Jack` **5:40.69** at the same per-Mii field offset. No game-side test of **editing Stray Ducklings specifically** has occurred yet; the user has already confirmed edits of other Resort scores, skills and stamps worked in-game.

## Also included from R8 development

- **Skill presets:** 1000, 1999, 2000 or 2500 for the selected sport or all 19 sports. Default is the newest/current history entry; optional entire 25-entry skill history.
- **Cross-save Mii consolidation:** import selected donor Mii skills, earned stamp dates and personal score fields into a chosen target Mii without overwriting identity or Wii-wide records. Donor scores overwrite target scores as requested; they are not automatically compared for which result is better.
- **Archive inventory:** list Miis and skill ratings from decrypted `Sports2.dat` backups.
- **Automatic Wii Sports Resort CRC32 repair** and existing Dolphin NAND ZIP export.
- **London 2012 editor retained**, including its previously verified per-profile checksum fix.

## Run

Extract this package into its own folder, then run `Launch_Wii_Score_Studio.bat` on Windows. If a dependency is missing, use `Install_Crypto_If_Needed.bat` once. Choose an existing save from Game Library, or load a standalone decrypted Resort `Sports2.dat`. Do not put your private saves inside the application directory.

## Verification completed

- 2:15.08 exact bytes and score matched to Mii, skill, Beginner high score and three stamps.
- 14 nonzero duckling-time records identified across 11 decrypted snapshot files (some archives are duplicates).
- Tested `2:15.08`, `2.15.08`, and `135.08` input; tested edits to `2:14.99` without modifying adjacent fields.
- Automatic CRC32 validation after edits, valid exported Dolphin NAND ZIP, source file unchanged.
- R7 named-score test suite and R8 GUI skill preset/merge tests passed.

**Not yet decoded:** a separate Wii-wide/overall Stray Ducklings leaderboard record, if one exists; the game may only expose a personal best. Do not assume the UI's score will update until checked in game.
