"""London 2012 Wii event-record identification from four save profiles and public Wii leaderboards.

Confidence refers to semantic identification only. Numeric stored field is >HH throughout.
Do NOT confuse this with the Nintendo 3DS game: different event lists and scores.
"""
from decimal import Decimal, InvalidOperation

# idx -> event name, category, format, confidence, evidence
# `time`: seconds, possibly displayed as m:ss.mmm
# `distance`: metres, in >HH with fraction /1000
# `points`: score integer or decimal, in >HH with fraction /1000
# `nonrecord`: zero in all supplied profiles; reason/event identity not independently verified
EVENT_ROWS = [
(0,'100m Sprint','Track','time','strong','8-9 seconds, menu event order'),
(1,'110m Hurdles','Track','time','strong','11-13 seconds, menu event order'),
(2,'4×100m Relay','Track','time','strong','~30-35 seconds, menu event order'),
(3,'Long Jump','Field','distance','verified','Old 9.455 to new 9.814; leaderboard ~9.845 m'),
(4,'Hammer Throw','Field','distance','strong','~95-97 m, leaderboard ~97.160'),
(5,'Discus Throw','Field','distance','strong','~76-84 m, leaderboard ~84.073'),
(6,'Javelin Throw','Field','distance','strong','~97-99 m, leaderboard ~99.044'),
(7,'Uneven Bars','Gymnastics','points','strong','30.000, leaderboard 30.00 max'),
(8,'Trampoline','Gymnastics','points','strong','23.250–45.000, leaderboard 38.75'),
(9,'Rhythmic Ribbon','Gymnastics','points','strong','55–58 pts, leaderboard 58.196'),
(10,'100m Freestyle','Aquatics','time','verified','User confirmed Slot03 43.665 s in-game; 42–45 sec range'),
(11,'Synchronized Swimming','Aquatics','points','verified','User confirmed Slot03 54.680 pts in-game'),
(12,'Shooting – Pistol','Shooting','points','verified','User confirmed Slot03 480 pts / 0:11.290; secondary time stored at event+0x244'),
(13,'Non-numeric event slot A','Head-to-head','nonrecord','unmapped','No numeric PB in supplied saves; one of Badminton, Beach Volleyball, Table Tennis, Football, Fencing'),
(14,'Non-numeric event slot B','Head-to-head','nonrecord','unmapped','No numeric PB in supplied saves; one of Badminton, Beach Volleyball, Table Tennis, Football, Fencing'),
(15,'Canoe Sprint 1000m','Canoeing','time','verified','User confirmed Slot03 3:14.425 in-game; leaderboard 3:08.375'),
(16,'Equestrian – Show Jumping','Equestrian','time','strong','59–70 sec, leaderboard 1:01.843'),
(17,'Track Cycling – Team Pursuit','Cycling','time','strong','71–80 sec, leaderboard 1:14.202'),
(18,'Non-numeric event slot C','Head-to-head','nonrecord','unmapped','No numeric PB in supplied saves; one of Badminton, Beach Volleyball, Table Tennis, Football, Fencing'),
(19,'Non-numeric event slot D','Head-to-head','nonrecord','unmapped','No numeric PB in supplied saves; one of Badminton, Beach Volleyball, Table Tennis, Football, Fencing'),
(20,'Non-numeric event slot E','Head-to-head','nonrecord','unmapped','No numeric PB in supplied saves; one of Badminton, Beach Volleyball, Table Tennis, Football, Fencing'),
(21,'Dream Sprint','Dream','time','strong','44–59 sec, leaderboard 46.978'),
(22,'Dream Hurdles','Dream','points','strong','125–469 pts, leaderboard 191'),
(23,'Dream Long Jump','Dream','distance','verified','User confirmed Slot03 300.580 m in-game'),
(24,'Dream Discus','Dream','points','strong','125–413 pts, leaderboard 249'),
(25,'Dream Rafting','Dream','points','strong','247–999 pts, leaderboard 636'),
(26,'Dream Uneven Bars','Dream','points','strong','373–999 pts, leaderboard 430'),
(27,'Dream Spacewalk','Dream','time','strong','69–116 sec, leaderboard 1:13.088'),
(28,'Dream Fencing [no numeric PB]','Dream','nonrecord','strong','Zero in all supplied profiles; Dream Fencing is a head-to-head event'),
(29,'Dream Trampoline','Dream','points','strong','411–729 pts, leaderboard 658'),
(30,'Dream Equestrian','Dream','time','strong','100–119 sec, leaderboard 1:49.873'),
]
# Strict integer-score events. Other points events can contain decimal components.
INTEGER_POINTS=frozenset((12,22,24,25,26,29))
EVENTS={i:dict(index=i,name=name,category=cat,kind=kind,confidence=conf,evidence=evidence,
               score_unit=('seconds' if kind=='time' else 'metres' if kind=='distance' else 'points' if kind=='points' else 'none'),
               typed_precision=('integer' if i in INTEGER_POINTS else 'thousandths' if kind!='nonrecord' else 'raw only'),
               better=('lower' if kind=='time' else 'higher' if kind!='nonrecord' else 'not applicable'))
        for i,name,cat,kind,conf,evidence in EVENT_ROWS}
assert len(EVENTS)==31 and list(EVENTS)==list(range(31))

RANKING_SOURCE='https://www.videogamesrecords.net/en/game/3158-mario-sonic-at-the-london-2012-olympic-games/group/11564-event-records'
EVENT_SOURCE='https://strategywiki.org/wiki/Mario_%26_Sonic_at_the_London_2012_Olympic_Games/Walkthrough'

def base_score(whole,part):
    if part>=1000: return f'{whole} + {part} [RAW]'
    return f'{whole}.{part:03d}'

def human_score(index,whole,part):
    m=EVENTS[index]
    if m['kind']=='nonrecord':return '—' if (whole,part)==(0,0) else base_score(whole,part)+' [raw]'
    if part>=1000:return base_score(whole,part)
    if index in INTEGER_POINTS and part==0:return f'{whole} pts'
    if m['kind']=='time':
        if whole>=60:return f'{whole//60}:{whole%60:02d}.{part:03d}'
        return f'{whole}.{part:03d} s'
    if m['kind']=='distance':return base_score(whole,part)+' m'
    return f'{whole}.{part:03d} pts' if part else f'{whole} pts'

def parse_typed(index,text):
    """Convert user-formatted London records to the exact two >U16 components.

    `m:ss.mmm` is accepted for time events. Other text accepts `m` or `pts` suffix.
    Raw entry never changes any event-specific category or character metadata.
    """
    kind=EVENTS[index]['kind']
    if kind=='nonrecord':raise ValueError('This slot has no verified numerical event. Use raw U16 entry if intentional.')
    s=str(text).strip().lower()
    for suffix in ('metres','meters','pts','points','seconds','sec'):
        if s.endswith(suffix):s=s[:-len(suffix)].strip();break
    if s.endswith(('m','s')):s=s[:-1].strip()
    if ':' in s:
        if kind!='time':raise ValueError('mm:ss.mmm is only valid for a time event')
        lead,seconds=s.split(':',1)
        if not lead.isdecimal():raise ValueError('Minutes must be a non-negative integer')
        sv=Decimal(seconds)
        if not (Decimal(0)<=sv<Decimal(60)):raise ValueError('Seconds must be from 0 to 59.999')
        x=Decimal(int(lead)*60)+sv
    else:
        x=Decimal(s)
    if not x.is_finite() or not (Decimal(0)<=x<Decimal(65536)):raise ValueError('Value out of bounds')
    whole=int(x)
    frac=(x-Decimal(whole))*1000
    if frac!=frac.to_integral_value():raise ValueError('Maximum precision is 0.001')
    if index in INTEGER_POINTS and frac!=0:raise ValueError('This event stores whole-number points; enter an integer (or use raw U16 editing)')
    return whole,int(frac)


# Based on comparison of all four SIIP profiles in two historical save exports.
# The secondary time field is +0x244 bytes from the ordinary event score.
# In-game validation: Slot03 is 480 pts / 0:11.290, matching both fields exactly.
SHOOTING_EVENT = 12
SHOOTING_SECONDARY_DELTA = 0x244

def parse_shooting_time(text):
    """Parse seconds or m:ss.mmm to two big-endian U16s; no float rounding."""
    s=str(text).strip().lower()
    for suffix in ('seconds','second','secs','sec'):
        if s.endswith(suffix):s=s[:-len(suffix)].strip();break
    if s.endswith('s'):s=s[:-1].strip()
    if ':' in s:
        lead, seconds=s.split(':',1)
        if not lead.isdecimal():raise ValueError('Time minutes must be a non-negative integer')
        seconds=Decimal(seconds)
        if not (0<=seconds<60):raise ValueError('Seconds after the colon must be <60')
        x=Decimal(int(lead)*60)+seconds
    else:
        x=Decimal(s)
    if not x.is_finite() or not (0<=x<65536):raise ValueError('Time must be 0–65535.999 seconds')
    whole=int(x)
    ms=(x-Decimal(whole))*1000
    if ms!=ms.to_integral_value():raise ValueError('Time must use no more than three decimal places')
    return whole,int(ms)

def format_shooting_time(whole,ms):
    if ms>=1000:return f'{whole} + {ms} [raw]'
    return f'{whole//60}:{whole%60:02d}.{ms:03d}'
