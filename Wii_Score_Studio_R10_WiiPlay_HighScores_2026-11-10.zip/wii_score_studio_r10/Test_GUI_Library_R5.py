"""Optional GUI smoke test. Needs a display/Xvfb; no source files written."""
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
import struct
from Wii_Score_Studio_Core import resort_crc
from Wii_Score_Studio_GUI import App
with TemporaryDirectory() as tmp:
    root=Path(tmp)
    sd=root/'private'/'wii'/'title'/'ABCE'
    sd.mkdir(parents=True)
    (sd/'data.bin').write_bytes(b'unknown save bytes')
    game=root/'Wii'/'title'/'00010000'/'53494950'/'data'/'Slot03'
    game.mkdir(parents=True)
    raw=bytearray(65536)
    raw[:8]=bytes.fromhex('0000000100030060')
    struct.pack_into('>HH',raw,0xe50,9,814)
    (game/'System').write_bytes(raw)
    sports=root/'Wii'/'title'/'00010000'/'525a5445'/'data'
    sports.mkdir(parents=True)
    raw=bytearray(0x120);raw[:4]=b'WSP2';struct.pack_into('>I',raw,8,0x100);struct.pack_into('>I',raw,12,resort_crc(raw))
    (sports/'Sports2.dat').write_bytes(raw)
    with patch('Wii_Score_Studio_GUI.get_saved_library_path',return_value=''),patch('Wii_Score_Studio_GUI.set_saved_library_path'):
        app=App();app.withdraw()
        app.library.root.set(str(root));app.library.scan()
        assert len(app.library.discovered)==3
        assert app.library.tree.get_children()==('0','1','2')
        loc=next(v for v in app.library.discovered if v.game_id=='SIIP')
        app.open_library_save(loc)
        assert app.london.doc.london_raw(3,3)==(9,814)
        assert app.nb.select()==str(app.london)
        loc=next(v for v in app.library.discovered if v.game_id=='RZTE')
        app.open_library_save(loc)
        assert app.resort.doc.game=='RZTE'
        assert app.nb.select()==str(app.resort)
        assert any(v.game_id=='ABCE' and v.editor is None for v in app.library.discovered)
        app.destroy()
print('PASS: R5 GUI library detects 3 saves, opens London and Resort in correct tabs, and retains unknown save research-only.')
