"""Run with user's own RPParty.dat or sample fixture environment (not shipped)."""
import sys,struct,tempfile,zipfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import WP_Play as wp
from Wii_Score_Studio_Core import SaveDocument,decode_sd_archive

def run_fixture(blob):
    valid,stored,calc=wp.verify(blob)
    assert valid, (stored,calc)
    p=wp.active_players(blob)
    assert p
    assert len(blob)==wp.SIZE
    for m in p:
        for g in range(9):
            for rank in range(5):
                off=wp.score_offset(m,g,rank)
                assert off%1==0 and off>=0
                assert struct.unpack_from('>I',blob,off)[0]==wp.read_scores(blob,m,g)[rank]
    m=p[0]
    x=bytearray(blob); old_score=wp.read_scores(x,m,0)[0]
    old_status=[wp.read_status(x,m,g) for g in range(9)]
    wp.patch_score(x,m,0,0,old_score+1)
    changed=[i for i,(a,b) in enumerate(zip(blob,x)) if a!=b]
    assert set(changed) <= set(range(wp.score_offset(m,0,0),wp.score_offset(m,0,0)+4))|set(range(wp.CHECKSUM_OFFSET,wp.CHECKSUM_OFFSET+4)),changed
    assert wp.read_scores(x,m,0)[0]==old_score+1
    assert [wp.read_status(x,m,g) for g in range(9)]==old_status
    assert wp.verify(x)[0]
    assert all(wp.read_scores(x,m,g)==wp.read_scores(blob,m,g) for g in range(1,9))
    return len(p),old_score,changed

if __name__=='__main__':
    import argparse
    args=argparse.ArgumentParser();args.add_argument('path',type=Path);a=args.parse_args()
    players,best,changed=run_fixture(a.path.read_bytes())
    print('PASS Wii Play:',players,'active Miis, top result',best,'changed bytes',changed)
