"""Research-based Mii indexing for Wii Sports Resort PAL and US Sports2.dat.

Offsets and stride were independently verified on user-provided decrypted saves.
The 75 *candidate* numerical pairs are not a labeled per-sport score map:
treat sport identifications and the meaning of third bytes as UNVERIFIED.
"""
from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal
import struct
from typing import Iterable

MIIS_START = 0x82C0
PLAYER_STRIDE = 0xDF4
NAME_SIZE = 20  # UTF-16BE, maximum ten code units
VALUES_REL = 0x1AA
VALUE_STRIDE = 3
VALUE_COUNT = 75

@dataclass(frozen=True)
class ResortMii:
 index: int
 name: str
 name_offset: int
 value_offset: int


def parse_miis(blob: bytes) -> list[ResortMii]:
 if blob[:4] != b'WSP2': raise ValueError('Not Wii Sports Resort Sports2.dat')
 out=[]
 for index in range((len(blob)-MIIS_START-NAME_SIZE)//PLAYER_STRIDE+1):
  p=MIIS_START+index*PLAYER_STRIDE
  raw=blob[p:p+NAME_SIZE]
  name=raw.decode('utf-16-be','replace').split('\0',1)[0].strip()
  # Avoid misreading uninitialized slots or binary as Mii names.
  if not (name and len(name)<=10 and all(c.isprintable() and c != '\ufffd' for c in name)):
   continue
  q=p+VALUES_REL
  if q+VALUE_COUNT*VALUE_STRIDE>len(blob): continue
  out.append(ResortMii(index,name,p,q))
 return out


def value_rows(blob: bytes, player_index:int):
 p=MIIS_START+player_index*PLAYER_STRIDE+VALUES_REL
 if p+VALUE_COUNT*VALUE_STRIDE>len(blob): raise ValueError('Mii record outside save bounds')
 out=[]
 for i in range(VALUE_COUNT):
  off=p+VALUE_STRIDE*i
  v=struct.unpack_from('>H',blob,off)[0]
  flag=blob[off+2]
  out.append(dict(index=i,offset=off,value=v,extra=flag,possible_skill=v<=2500))
 return out


def patch_candidate(blob:bytearray,player_index:int,entry_index:int,value:int,repair):
 if not 0<=entry_index<VALUE_COUNT:raise ValueError('Entry number out of range')
 if not 0<=int(value)<=2500:raise ValueError('Experimental skill values must be from 0 to 2500')
 off=MIIS_START+player_index*PLAYER_STRIDE+VALUES_REL+entry_index*VALUE_STRIDE
 if off+3>len(blob):raise ValueError('Outside file')
 old=struct.unpack_from('>H',blob,off)[0]
 third=blob[off+2]
 struct.pack_into('>H',blob,off,int(value))
 repair(blob)
 assert blob[off+2]==third,'Unexpected extra-byte change'
 return old,off


def candidates_for_score(blob:bytes,player_index:int,score:str,scale:int=100,tolerance:str='0', max_rows:int=150):
 """Return U16 BE matches within *this* MiI block, not a global search.

 No verified per-sport value map yet; matches are only hypotheses.
 """
 d=Decimal(str(score)); t=Decimal(str(tolerance))
 if not d.is_finite() or not t.is_finite() or t<0: raise ValueError('Invalid score/tolerance')
 target=d*scale
 p=MIIS_START+player_index*PLAYER_STRIDE
 end=min(p+PLAYER_STRIDE,len(blob))
 if p<0 or end-p<4:raise ValueError('Invalid Mii index')
 out=[]
 # Use aligned 16-bit fields; also permit odd offsets since WSR has packed records.
 for off in range(p,end-1):
  v=struct.unpack_from('>H',blob,off)[0]
  if abs(Decimal(v)-target) <= t*scale:
   out.append(dict(offset=off,raw=v,display=str(Decimal(v)/scale),distance=abs(Decimal(v)-target)/scale))
 out.sort(key=lambda z:(z['distance'],z['offset']))
 return out[:max_rows],len(out)
