"""Headless smoke test for R8 presets, donor importing and the existing GUI."""
from pathlib import Path
import tkinter as tk
from tkinter import messagebox
from Wii_Score_Studio_GUI import App
from Wii_Score_Studio_Core import resort_validate
from WSR_Known_Fields import read_skill,read_stamp

source=Path('/mnt/data/wii_save_research/Sports2_pal.dat')
original=source.read_bytes()
root=App();root.update_idletasks()
root.resort.open_document(source)
tab=root.resort_named
assert tab.doc is root.resort.doc and tab.player.get()
tab.player.set('01: Vincenzo');tab.category.set('Skill history (19×25)');tab.change_category()
oldask=messagebox.askyesno;oldshow=messagebox.showerror;oldinfo=messagebox.showinfo
messagebox.askyesno=lambda *a,**k: True
messagebox.showerror=lambda *a,**k: (_ for _ in ()).throw(AssertionError('GUI error: '+str(a)))
messagebox.showinfo=lambda *a,**k:None
try:
 tab.preset.set('1999');tab.preset_history.set('Current / newest only');tab.apply_preset(True)
 b=tab.doc.resort_bytes()
 assert all(read_skill(b,1,s,0)['score']==1999 for s in range(19))
 assert all(read_skill(b,1,s,1)['score']==read_skill(original,1,s,1)['score'] for s in range(19))
 assert resort_validate(b)[0]
 tab.preset.set('2500');tab.preset_history.set('Entire 25-entry history');tab.sport.set('Frisbee Golf');tab.apply_preset(False)
 assert all(read_skill(b,1,16,h)['score']==2500 for h in range(25))
 assert all(read_skill(b,1,15,h)['score']==read_skill(original,1,15,h)['score'] for h in range(1,25))
 assert resort_validate(b)[0]
 assert original==source.read_bytes()
 dlg=__import__('WSR_Donor_Merge_Dialog').DonorMergeDialog(tab,tab.doc,1,tab.render)
 dlg.path=Path('/mnt/data/wii_save_research/Sports2_wii_sports_resort_all_stamps_50.dat');dlg.sources=[('file',dlg.path.name)];dlg.sourcecombo['values']=['file: '+dlg.path.name];dlg.source.set('file: '+dlg.path.name);dlg.load_source()
 assert dlg.donor is not None
 donor_index=next(i for i,name in dlg.donorplayers if sum(read_stamp(dlg.donor,i,s,h)['acquired'] for s in range(20) for h in range(5))==100)
 dlg.donormii.set(next(v for v in dlg.miicombo['values'] if v.startswith(f'{donor_index:02d}:')))
 dlg.skills.set(False);dlg.stamps.set(True);dlg.records.set(False);dlg.apply()
 b=tab.doc.resort_bytes()
 assert all(read_stamp(b,1,s,h)['acquired'] for s in range(20) for h in range(5))
 assert resort_validate(b)[0]
 assert original==source.read_bytes()
 print('R8 GUI smoke: preset 1999 all current / 2500 Frisbee whole history / donor union 100 stamps / CRC32 valid / original unchanged')
except Exception:
 raise
finally:
 messagebox.askyesno=oldask;messagebox.showerror=oldshow;messagebox.showinfo=oldinfo
 root.destroy()
