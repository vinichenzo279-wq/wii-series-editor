@echo off
cd /d "%~dp0"
where py >nul 2>&1
if %ERRORLEVEL% EQU 0 (
  py -3 Wii_Score_Studio_GUI.py
) else (
  python Wii_Score_Studio_GUI.py
)
if errorlevel 1 (
 echo.
 echo Could not launch the editor. Install Python 3 with tkinter,
 echo and for encrypted data.bin support: py -3 -m pip install cryptography
 pause
)
