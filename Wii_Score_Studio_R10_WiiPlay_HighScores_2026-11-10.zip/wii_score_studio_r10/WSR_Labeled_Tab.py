"""Source-derived Wii Sports Resort score/skill/stamp editor for Wii Score Studio R7.
Requires Wii_Score_Studio_Core.SaveDocument, already used by R6.
Known data offsets are taken from Aaron98990/wii-inspect, supplied by the user.
"""
import csv
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
from pathlib import Path
from WSR_Known_Fields import (
  PERSONAL_FIELDS,WII_FIELDS,SPORT_SKILLS,STAMP_BASES,profile_names,
  read_record,patch_record,read_skill,patch_skill,read_stamp,patch_stamp,
  profile_base,read_stamp,decode_stamp,read_rank,patch_rank,award_rank_for_skill,RANK_LABELS
)
from Wii_Score_Studio_Core import resort_validate,resort_fix_checksum
from WSR_Bulk_Editing import PRESET_VALUES,apply_skill_preset,archive_inventory
from WSR_Donor_Merge_Dialog import DonorMergeDialog

class ResortLabeledTab(ttk.Frame):
 def __init__(self,notebook,app):
  super().__init__(notebook,padding=12);self.app=app;self.doc=None;self.players=[]
  ttk.Label(self,text='Wii Sports Resort — named records, skill histories and stamps',style='Title.TLabel').pack(anchor='w')
  ttk.Label(self,text='Source: wii-inspect highScores.bash / stamps.bash, plus verified Stray Ducklings field. Originals untouched; edits repair Sports2.dat CRC32.',wraplength=1100).pack(anchor='w',pady=(2,8))
  bar=ttk.Frame(self);bar.pack(fill='x',pady=5)
  ttk.Label(bar,text='Player:').pack(side='left')
  self.player=tk.StringVar();self.players_combo=ttk.Combobox(bar,textvariable=self.player,width=28,state='readonly');self.players_combo.pack(side='left',padx=8)
  self.players_combo.bind('<<ComboboxSelected>>',lambda e:self.render())
  ttk.Label(bar,text='Category:').pack(side='left',padx=(16,0))
  self.category=tk.StringVar(value='Personal scores')
  self.category_box=ttk.Combobox(bar,textvariable=self.category,state='readonly',values=['Personal scores','Wii-wide scores','Skill history (19×25)','Rank medals (19)','Stamps (20×5)'],width=27)
  self.category_box.pack(side='left',padx=8);self.category_box.bind('<<ComboboxSelected>>',lambda e:self.change_category())
  ttk.Label(bar,text='Sport filter:').pack(side='left',padx=(16,0))
  self.sport=tk.StringVar(value='All');self.sport_box=ttk.Combobox(bar,textvariable=self.sport,width=24,state='readonly');self.sport_box.pack(side='left',padx=8)
  self.sport_box.bind('<<ComboboxSelected>>',lambda e:self.render())
  ttk.Button(bar,text='Refresh',command=self.render).pack(side='left',padx=3)
  fr=ttk.Frame(self);fr.pack(fill='both',expand=True,pady=8)
  cols=('sport','mode','value','offset','raw')
  self.tree=ttk.Treeview(fr,columns=cols,show='headings',selectmode='browse')
  for k,l,w in [('sport','Sport',210),('mode','Event / history index',260),('value','Stored value',190),('offset','Offset',116),('raw','Raw / flags',215)]:
   self.tree.heading(k,text=l);self.tree.column(k,width=w,anchor='w' if k in ('sport','mode') else 'center')
  sc=ttk.Scrollbar(fr,orient='vertical',command=self.tree.yview);self.tree.configure(yscrollcommand=sc.set)
  self.tree.pack(side='left',fill='both',expand=True);sc.pack(side='right',fill='y')
  self.tree.bind('<Double-Button-1>',lambda e:self.edit_selected());self.tree.bind('<Return>',lambda e:self.edit_selected())
  act=ttk.Frame(self);act.pack(fill='x')
  ttk.Button(act,text='Edit selected value',command=self.edit_selected,style='Accent.TButton').pack(side='left')
  ttk.Button(act,text='Export visible table to CSV…',command=self.export_csv).pack(side='left',padx=8)
  ttk.Button(act,text='Fill missing stamps…',command=self.fill_missing_stamps).pack(side='left',padx=8)
  ttk.Button(act,text='Send selected offset to raw editor',command=self.send_to_raw).pack(side='left',padx=8)
  # R8: one-click skill ratings. Entries are newest-first: History 01 is current.
  preset=ttk.LabelFrame(self,text='Quick skill presets — current Mii only',padding=10)
  preset.pack(fill='x',pady=(7,1))
  pbar=ttk.Frame(preset);pbar.pack(fill='x')
  ttk.Label(pbar,text='Skill:').pack(side='left')
  self.preset=tk.StringVar(value='2500')
  ttk.Combobox(pbar,textvariable=self.preset,values=[str(x) for x in PRESET_VALUES],width=9).pack(side='left',padx=7)
  ttk.Label(pbar,text='History:').pack(side='left',padx=(14,0))
  self.preset_history=tk.StringVar(value='Current / newest only')
  ttk.Combobox(pbar,textvariable=self.preset_history,values=['Current / newest only','Entire 25-entry history'],state='readonly',width=24).pack(side='left',padx=7)
  ttk.Button(pbar,text='Set selected sport',command=lambda:self.apply_preset(False)).pack(side='left',padx=6)
  ttk.Button(pbar,text='Set all 19 sports',command=lambda:self.apply_preset(True),style='Accent.TButton').pack(side='left',padx=6)
  self.award_with_skill=tk.BooleanVar(value=False)
  ttk.Checkbutton(preset,text='Optionally award eligible Pro/Superstar medals when raising skill (never downgrade)',variable=self.award_with_skill).pack(anchor='w',pady=(5,0))
  rankbar=ttk.Frame(preset);rankbar.pack(fill='x',pady=(5,0))
  ttk.Label(rankbar,text='Independent medal edit:').pack(side='left')
  self.rank_preset=tk.StringVar(value='Superstar (gold)')
  ttk.Combobox(rankbar,textvariable=self.rank_preset,values=['None','Pro (silver)','Superstar (gold)'],state='readonly',width=19).pack(side='left',padx=6)
  ttk.Button(rankbar,text='Set selected sport',command=lambda:self.apply_rank_preset(False)).pack(side='left',padx=5)
  ttk.Button(rankbar,text='Set all 19 sports',command=lambda:self.apply_rank_preset(True)).pack(side='left',padx=5)
  quick=ttk.Frame(preset);quick.pack(fill='x',pady=(5,0))
  ttk.Label(quick,text='One-click all-sport presets:').pack(side='left')
  for skill in PRESET_VALUES:
   ttk.Button(quick,text=f'All {skill}',command=lambda value=skill:(self.preset.set(str(value)),self.apply_preset(True))).pack(side='left',padx=4)
  ttk.Label(quick,text='History 01 is newest. Current-only by default; full 25-entry history is optional.',foreground='#627989').pack(side='left',padx=10)
  merges=ttk.Frame(self);merges.pack(fill='x',pady=(4,1))
  ttk.Button(merges,text='Consolidate from another Wii Sports Resort save…',command=self.open_donor_merge).pack(side='left')
  ttk.Button(merges,text='Inventory a folder of Resort backups…',command=self.export_archive_inventory).pack(side='left',padx=8)
  ttk.Label(merges,text='Mii identity and Wii-wide records preserved',foreground='#657789').pack(side='left',padx=8)
  self.state=tk.StringVar(value='Open a Resort save via Game Library or Resort tab.')
  ttk.Label(self,textvariable=self.state,foreground='#527182',wraplength=1200).pack(fill='x',pady=(7,0))
  self.row_data={}
 def attach_document(self,doc):
  self.doc=doc;self.players=profile_names(doc.resort_bytes())
  vals=[f'{i:02d}: {name}' for i,name in self.players]
  self.players_combo['values']=vals
  if not self.player.get() in vals and vals:self.player.set(vals[0])
  self.change_category()
 def player_index(self):
  if not self.player.get():raise ValueError('Select a Mii')
  return int(self.player.get().split(':',1)[0])
 def change_category(self):
  cat=self.category.get()
  choices=['All']+sorted(set(f.sport for f in (WII_FIELDS if cat=='Wii-wide scores' else PERSONAL_FIELDS))) if cat in ('Personal scores','Wii-wide scores') else ['All']+(SPORT_SKILLS if cat.startswith('Skill') or cat.startswith('Rank') else [x[0] for x in STAMP_BASES])
  self.sport_box['values']=choices
  if self.sport.get() not in choices:self.sport.set('All')
  self.render()
 def render(self):
  self.tree.delete(*self.tree.get_children());self.row_data={}
  if not self.doc:return
  blob=self.doc.resort_bytes();idx=self.player_index();cat=self.category.get();filt=self.sport.get()
  def insert(label,mode,shown,off,raw,payload):
   k=str(len(self.row_data));self.row_data[k]=payload
   self.tree.insert('', 'end',iid=k,values=(label,mode,str(shown),f'0x{off:05X}',raw))
  if cat in ('Personal scores','Wii-wide scores'):
   for f in (WII_FIELDS if cat=='Wii-wide scores' else PERSONAL_FIELDS):
    if filt!='All' and f.sport!=filt:continue
    d=read_record(blob,f,idx)
    insert(f.sport,f.mode,d['shown'],d['offset'],str(d['raw']) + ((' / flag '+d.get('flag','')) if 'flag' in d else ''),('record',f,idx))
  elif cat.startswith('Skill'):
   for si,sp in enumerate(SPORT_SKILLS):
    if filt!='All' and sp!=filt:continue
    for n in range(25):
     d=read_skill(blob,idx,si,n)
     insert(sp,('History 01 — newest' if n==0 else f'History {n+1:02d}'),d['score'],d['offset'],f'meta 0x{d["metadata"]:02X} / high nibble 0x{d["other_nibble"]:X}',('skill',idx,si,n))
  elif cat.startswith('Rank'):
   for si,sp in enumerate(SPORT_SKILLS):
    if filt!='All' and sp!=filt:continue
    d=read_rank(blob,idx,si)
    insert(sp,'Persistent achievement',d['shown'],d['offset'],f'Rank byte: {d["raw"]} / Current skill: {read_skill(blob,idx,si,0)["score"]}',('rank',idx,si))
  elif cat.startswith('Stamps'):
   for si,(sp,_) in enumerate(STAMP_BASES):
    if filt!='All' and sp!=filt:continue
    for n in range(5):
     d=read_stamp(blob,idx,si,n)
     insert(sp,f'Stamp {n+1}',d['shown'] or 'not earned',d['offset'],f'0x{d["raw"]:08X}',('stamp',idx,si,n))
  valid,stored,computed=resort_validate(blob)
  self.state.set(f'Player {idx} · {len(self.row_data)} visible fields · Resort CRC32 {"VALID" if valid else "INVALID"}. Changes remain in memory until Save As through Resort.')
 def edit_selected(self):
  if not self.doc:return
  sel=self.tree.selection()
  if not sel:return
  k=sel[0];row=self.row_data[k];before=self.tree.item(k,'values');cat=row[0]
  try:
   if cat=='record':
    _,f,idx=row
    q=f'{f.sport} — {f.mode}: current {before[2]}'+ (' (signed value; validity flag not updated)' if f.fmt=='s16_flag' else '')
    val=simpledialog.askstring('Edit sport record',q,initialvalue=before[2],parent=self)
    if val is None:return
    patch_record(self.doc.resort_bytes(),f,idx,val)
   elif cat=='skill':
    _,idx,si,n=row
    val=simpledialog.askinteger('Edit skill history',f'{SPORT_SKILLS[si]} — entry {n+1}'+(' (newest)' if n==0 else ' (historical)')+'\nSaved as packed 12-bit skill; metadata preserved.',initialvalue=int(before[2]),minvalue=0,maxvalue=2500,parent=self)
    if val is None:return
    patch_skill(self.doc.resort_bytes(),idx,si,n,val)
   elif cat=='rank':
    _,idx,si=row
    val=simpledialog.askinteger('Edit independent medal',f'{SPORT_SKILLS[si]}\n0 = none; 3 = Pro (silver); 4 = Superstar (gold).\nIndependent from displayed skill; a Mii can have 0 skill and gold.',initialvalue=read_rank(self.doc.resort_bytes(),idx,si)['raw'],minvalue=0,maxvalue=4,parent=self)
    if val is None:return
    patch_rank(self.doc.resort_bytes(),idx,si,val)
   else:
    _,idx,si,n=row
    val=simpledialog.askstring('Edit stamp date',f'{STAMP_BASES[si][0]} — stamp {n+1}\nEnter YYYY-MM-DD HH:MM or 0 to clear.',initialvalue=before[2] if before[2]!='not earned' else '',parent=self)
    if val is None:return
    patch_stamp(self.doc.resort_bytes(),idx,si,n,val)
   resort_fix_checksum(self.doc.resort_bytes())
   self.render();self.tree.selection_set(k);self.tree.see(k)
  except Exception as ex:messagebox.showerror('Edit failed',str(ex),parent=self)
 def apply_preset(self,all_sports:bool):
  if not self.doc:return messagebox.showinfo('No save','Open a Resort save first.',parent=self)
  try:
   score=int(self.preset.get().strip())
   if not 0<=score<=2500:raise ValueError('Skill value must be 0–2500')
   sport='All' if all_sports else self.sport.get()
   if not all_sports and sport=='All':
    return messagebox.showinfo('Select sport','Choose a specific sport in the Sport filter, or click Set all 19 sports.',parent=self)
   from WSR_Known_Fields import SPORT_SKILLS
   if sport!='All' and sport not in SPORT_SKILLS:
    return messagebox.showinfo('Select skill sport','Select a sport from the Skill history category first.',parent=self)
   idx=self.player_index();history='all' if self.preset_history.get()=='Entire 25-entry history' else 'current'
   trial=bytearray(self.doc.resort_bytes())
   summary=apply_skill_preset(trial,idx,score,sport,history)
   rank_changes=0
   if self.award_with_skill.get():
    selected=range(19) if sport=='All' else [SPORT_SKILLS.index(sport)]
    for si in selected:
     if award_rank_for_skill(trial,idx,si,score):rank_changes+=1
   if not summary['entries_changed'] and not rank_changes:
    return messagebox.showinfo('Already set','The selected skills and optional awards already match.',parent=self)
   ask=(f'Mii: {self.player.get()}\nSports: {summary["sports"]}\n'
        f'History: {"all 25 entries" if history=="all" else "newest entry only"}\n'
        f'Change {summary["entries_changed"]} skill values to {score}?\n'
        f'New rank awards: {rank_changes} (existing medals never downgraded).\n\n'
        'All other skill-history metadata is preserved. The original save stays unchanged.')
   if not messagebox.askyesno('Apply skill preset',ask,parent=self):return
   resort_fix_checksum(trial)
   assert resort_validate(trial)[0]
   self.doc.resort_bytes()[:]=trial
   if self.category.get()!='Skill history (19×25)':
    self.category.set('Skill history (19×25)');self.change_category()
   else:self.render()
  except Exception as e:messagebox.showerror('Skill preset failed',str(e),parent=self)

 def apply_rank_preset(self,all_sports:bool):
  if not self.doc:return messagebox.showinfo('No save','Open a Resort save first.',parent=self)
  try:
   from WSR_Known_Fields import SPORT_SKILLS
   val=next(k for k,v in RANK_LABELS.items() if v==self.rank_preset.get())
   sport=self.sport.get()
   if not all_sports and sport not in SPORT_SKILLS:
    return messagebox.showinfo('Choose sport','Select a sport, or choose Set all 19 sports.',parent=self)
   idx=self.player_index();trial=bytearray(self.doc.resort_bytes())
   selected=list(range(19)) if all_sports else [SPORT_SKILLS.index(sport)]
   changes=[]
   for si in selected:
    prev=read_rank(trial,idx,si)['raw']
    if prev!=val:
     patch_rank(trial,idx,si,val);changes.append((SPORT_SKILLS[si],prev,val))
   if not changes:return messagebox.showinfo('Already set','Selected medals already have that value.',parent=self)
   if not messagebox.askyesno('Edit independent medals',f'Change {len(changes)} rank medals to {RANK_LABELS[val]}?\n\nSkill levels are NOT modified. Existing medals can intentionally be downgraded or cleared.',parent=self):return
   resort_fix_checksum(trial)
   assert resort_validate(trial)[0]
   self.doc.resort_bytes()[:]=trial
   self.category.set('Rank medals (19)');self.change_category()
  except Exception as e:messagebox.showerror('Medal editing failed',str(e),parent=self)

 def open_donor_merge(self):
  if not self.doc:return messagebox.showinfo('No save','Open a Resort save first.',parent=self)
  DonorMergeDialog(self,self.doc,self.player_index(),self.render)

 def export_archive_inventory(self):
  folder=filedialog.askdirectory(parent=self,title='Select a folder containing decrypted Sports2.dat snapshots')
  if not folder:return
  files=[]
  for p in Path(folder).rglob('*'):
   if len(files)>=600:break
   if not p.is_file() or p.suffix.lower() not in ('.dat','.bin'):continue
   try:
    if p.stat().st_size<1_000_000:
     with p.open('rb') as fh:header=fh.read(4)
     if header==b'WSP2':files.append(p)
   except OSError:continue
  if not files:return messagebox.showinfo('No snapshots','No decrypted WSP2-format Sports2.dat files found. Extract encrypted Wii backups first.',parent=self)
  path=filedialog.asksaveasfilename(parent=self,title='Save Mii & skill archive inventory CSV',defaultextension='.csv',initialfile='WSR_All_Miis_Inventory.csv',filetypes=[('CSV','*.csv')])
  if not path:return
  best=Path(path).with_name(Path(path).stem+'_Best_Skills.csv')
  try:
   summary=archive_inventory(files,path,best)
   messagebox.showinfo('Inventory exported',f'{summary["profiles"]} named Mii records across {summary["files"]} saves.\n\nAll: {path}\nBest skill per sport: {best}',parent=self)
  except Exception as e:messagebox.showerror('Inventory failed',str(e),parent=self)

 def fill_missing_stamps(self):
  if self.category.get()!='Stamps (20×5)' or not self.doc:
   return messagebox.showinfo('Choose Stamps','Switch to the Stamps category to fill missing stamps for the selected Mii.',parent=self)
  val=simpledialog.askstring('Stamp grant date','Grant missing stamps with date/time YYYY-MM-DD HH:MM (or cancel)',initialvalue='2026-11-10 12:00',parent=self)
  if not val:return
  from WSR_Known_Fields import encode_stamp
  try: encode_stamp(val)
  except Exception as ex:return messagebox.showerror('Invalid timestamp',str(ex),parent=self)
  idx=self.player_index()
  pending=[(sport,n) for sport in range(20) for n in range(5) if not read_stamp(self.doc.resort_bytes(),idx,sport,n)['acquired']]
  if not pending:return messagebox.showinfo('Complete','All 100 stamp date fields are nonzero.',parent=self)
  if not messagebox.askyesno('Grant stamps',f'Fill {len(pending)} missing stamp date(s) for {self.player.get()}?\nOriginal save is untouched; game acceptance not yet tested.',parent=self):return
  for sport,n in pending:patch_stamp(self.doc.resort_bytes(),idx,sport,n,val)
  resort_fix_checksum(self.doc.resort_bytes());self.render()
 def export_csv(self):
  if not self.doc:return
  path=filedialog.asksaveasfilename(title='Export WSR labeled fields',defaultextension='.csv',initialfile='WSR_labeled_fields.csv',filetypes=[('CSV','*.csv')])
  if not path:return
  try:
   with open(path,'w',newline='',encoding='utf-8-sig') as fp:
    w=csv.writer(fp);w.writerow(['Mii index','Mii name','Category','Sport','Mode','Value','Offset','Raw / flags','Editing note'])
    idx=self.player_index()
    for k in self.tree.get_children():
     row=self.tree.item(k,'values');w.writerow([idx,self.player.get(),self.category.get(),row[0],row[1],row[2],row[3],row[4],'Wii-wide fields are global; golf flags/cycling require care'])
   messagebox.showinfo('CSV saved','Exported the visible table for analysis. Edit values directly in the GUI; CSV import is not enabled for packed fields.',parent=self)
  except Exception as ex:messagebox.showerror('CSV export failed',str(ex),parent=self)
 def send_to_raw(self):
  sel=self.tree.selection()
  if not sel:return
  off=self.tree.item(sel[0],'values')[3]
  self.app.resort.offset.set(off)
  self.app.resort.write_type.set('U16 BE')
  self.app.resort.read_at_offset()
  self.app.nb.select(self.app.resort)
