"""Wii Sports Resort bulk edits and explicit cross-save per-Mii record merges.

Uses source-verified offset maps from WSR_Known_Fields. All target writes must
operate on an editable copy and be followed by the game's CRC32 repair.
Never copies a whole Mii block (avoids overwriting Mii identity and rankings).
"""
from __future__ import annotations
from pathlib import Path
import csv
from WSR_Known_Fields import (
    SPORT_SKILLS, STAMP_BASES, PERSONAL_FIELDS,
    read_skill, patch_skill, read_stamp, read_record, profile_names, offset,
)

PRESET_VALUES=(1000, 1999, 2000, 2500)


def _sports_indices(selected, labels):
    if selected == 'All': return list(range(len(labels)))
    if selected not in labels: return []
    return [labels.index(selected)]


def apply_skill_preset(blob:bytearray, profile:int, score:int, sport='All', history='current'):
    """Modify 1 or 25 packed entries per sport, preserving each entry's metadata.
    'current' is entry0; historical snapshots independently show newest-first.
    """
    score=int(score)
    if not 0<=score<=2500: raise ValueError('Skill should be from 0 to 2500')
    if history not in ('current','all'): raise ValueError('Choose current or all history')
    inds=_sports_indices(sport, SPORT_SKILLS)
    if not inds:raise ValueError('Unknown sport')
    count=0; changed=[]
    for s in inds:
        for h in (range(25) if history=='all' else [0]):
            old=read_skill(blob,profile,s,h)['score']
            if old != score:
                patch_skill(blob,profile,s,h,score)
                count+=1
                changed.append((SPORT_SKILLS[s],h+1,old,score))
    return {'sports':len(inds),'entries_changed':count,'entries_targeted':len(inds)*(25 if history=='all' else 1),'changes':changed}


def donor_merge(target:bytearray, target_profile:int, donor:bytes, donor_profile:int,
                *,sport='All', skills=True, skill_history=False, stamps=True, records=False):
    """Explicit donor to target merge of known field types, independent of Mii identity.

    Skill (default): copy *donor latest score* into target history 01, preserving
    target metadata; optional full history copies scores only (not donor metadata).
    Stamps: union earned dates; existing target dates remain intact.
    Records: copy known personal score numeric fields, plus neighboring validity
    flag bytes for golf/frisbee-golf. Does not touch Wii-wide records/holder IDs.
    Returns a change summary; caller repairs CRC32.
    """
    if not (skills or stamps or records):raise ValueError('Choose at least one merge category')
    result={'skills_changed':0,'stamps_added':0,'records_changed':0,'sources':{}}
    for si in _sports_indices(sport,SPORT_SKILLS):
        if not skills:break
        histories=range(25) if skill_history else [0]
        for h in histories:
            v=read_skill(donor,donor_profile,si,h)['score']
            if read_skill(target,target_profile,si,h)['score']!=v:
                patch_skill(target,target_profile,si,h,v)
                result['skills_changed']+=1
    if stamps:
        for si in _sports_indices(sport,[x[0] for x in STAMP_BASES]):
            for h in range(5):
                dest=read_stamp(target,target_profile,si,h)
                src=read_stamp(donor,donor_profile,si,h)
                if dest['raw']==0 and src['raw']!=0:
                    target[dest['offset']:dest['offset']+4]=donor[src['offset']:src['offset']+4]
                    result['stamps_added']+=1
    if records:
        for field in PERSONAL_FIELDS:
            if sport!='All' and field.sport!=sport:continue
            src=offset(field,donor_profile);dst=offset(field,target_profile)
            # Golf/Frisbee Golf: preserve donor record validity flag near score.
            n=4 if field.fmt=='s16_flag' else 2
            s=src-2 if n==4 else src
            t=dst-2 if n==4 else dst
            data=donor[s:s+n]
            if len(data)!=n or t<0 or t+n>len(target):raise ValueError('Donor record out of range')
            if target[t:t+n]!=data:
                target[t:t+n]=data
                result['records_changed']+=1
    return result


def archive_inventory(files, summary_path, best_path):
    """Read-only inventory of raw decrypted Sports2.dat backups.

    Each profile is treated as distinct, even when names match. Skill bests use
    newest history entry 01 rather than maximum in historical entries.
    """
    summary=[]; skills=[]; rejected=[]
    for path in sorted({Path(x) for x in files}):
        try:
            if path.stat().st_size>1_000_000:continue
            blob=path.read_bytes()
            if blob[:4]!=b'WSP2':continue
            from Wii_Score_Studio_Core import resort_validate
            ok,_,_=resort_validate(blob)
            if not ok:rejected.append((str(path),'invalid CRC'));continue
            for mii,name in profile_names(blob):
                current=[read_skill(blob,mii,s,0)['score'] for s in range(19)]
                earned=sum(read_stamp(blob,mii,s,h)['acquired'] for s in range(20) for h in range(5))
                summary.append([path.name,str(path),mii,name,earned,sum(x>=1000 for x in current),sum(x>=1999 for x in current),sum(x>=2000 for x in current),sum(x==2500 for x in current),*current])
                for si,v in enumerate(current):
                    if v>0:skills.append((si,v,path.name,str(path),mii,name))
        except (OSError,ValueError) as e:rejected.append((str(path),str(e)))
    header=['File','Full path','Mii index','Mii name','Stamps out of 100','Sports >=1000','Sports >=1999','Sports >=2000','Sports ==2500',*SPORT_SKILLS]
    with open(summary_path,'w',newline='',encoding='utf-8-sig') as f:
        w=csv.writer(f);w.writerow(header);w.writerows(summary)
    with open(best_path,'w',newline='',encoding='utf-8-sig') as f:
        w=csv.writer(f);w.writerow(['Sport','Best current skill','Source file','Full source path','Mii index','Mii name'])
        for si,sp in enumerate(SPORT_SKILLS):
            cand=[x for x in skills if x[0]==si]
            if cand:
                ix=max(cand,key=lambda x:x[1])
                w.writerow([sp,ix[1],ix[2],ix[3],ix[4],ix[5]])
            else:w.writerow([sp,'Not found','','','',''])
    return {'profiles':len(summary),'files':len(set(r[1] for r in summary)),'rejected':rejected}
