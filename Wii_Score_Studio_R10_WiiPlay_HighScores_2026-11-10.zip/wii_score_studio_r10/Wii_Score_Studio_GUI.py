#!/usr/bin/env python3
"""Wii Score Studio — Windows-friendly graphical editor for London 2012 & Wii Sports Resort."""
from __future__ import annotations
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
import zipfile, csv
from Wii_Save_Library import (scan_save_folder, get_saved_library_path, set_saved_library_path, BACKLOG)
from London_Event_Catalog import EVENTS, INTEGER_POINTS, parse_typed, SHOOTING_EVENT, parse_shooting_time
from Wii_Score_Studio_Core import (SaveDocument, LONDON_EVENTS, LONDON_EVENT_COUNT,
    LONDON_HEAD, LONDON_STRIDE, TYPE_FORMATS, scan_save_zips, resort_validate)

MAIN_BG='#f1f5f9';FG='#1e354b';ACC='#087b83';WARN='#88551b';FONT=('Segoe UI',10)

class SelectZip(tk.Toplevel):
 def __init__(self,root,choices):
  super().__init__(root);self.result=None;self.title('Choose saved game from ZIP');self.geometry('810x370');self.transient(root);self.grab_set()
  ttk.Label(self,text='Select the Wii save export you want to open:',style='Head.TLabel').pack(anchor='w',padx=15,pady=(14,6))
  f=ttk.Frame(self);f.pack(fill='both',expand=True,padx=15,pady=6)
  self.lb=tk.Listbox(f,font=('Consolas',10),selectmode='browse',activestyle='dotbox')
  vs=ttk.Scrollbar(f,orient='vertical',command=self.lb.yview);self.lb.configure(yscrollcommand=vs.set)
  self.lb.pack(side='left',fill='both',expand=True);vs.pack(side='right',fill='y')
  for n,g in choices:self.lb.insert('end',f'{g or "Wii"}  |  {n}')
  self.lb.selection_set(0);self.lb.bind('<Double-Button-1>',lambda _e:self.ok())
  r=ttk.Frame(self);r.pack(fill='x',padx=15,pady=10)
  ttk.Button(r,text='Open selected',command=self.ok,style='Accent.TButton').pack(side='right')
  ttk.Button(r,text='Cancel',command=self.destroy).pack(side='right',padx=8)
  self.choices=choices
 def ok(self):
  k=self.lb.curselection()
  if k:self.result=self.choices[k[0]][0];self.destroy()

class BaseTab(ttk.Frame):
 def __init__(self,notebook,app,game_name):
  super().__init__(notebook,padding=14);self.app=app;self.doc=None;self.game_name=game_name
  row=ttk.Frame(self);row.pack(fill='x',pady=(0,10))
  ttk.Button(row,text='Open save…',command=self.open_save,style='Accent.TButton').pack(side='left')
  ttk.Button(row,text='Save as Dolphin ZIP…',command=self.save_zip).pack(side='left',padx=8)
  ttk.Button(row,text='Save as folder…',command=self.save_dir).pack(side='left')
  ttk.Button(row,text='Undo all changes',command=self.reset).pack(side='right')
  self.info=tk.StringVar(value=f'Open a {game_name} Wii SD data.bin, ZIP, or Dolphin save folder.')
  ttk.Label(self,textvariable=self.info,foreground='#4b6173',wraplength=1150).pack(anchor='w',pady=(0,12))
 def open_save(self):
  fp=filedialog.askopenfilename(title='Choose Wii save, decrypted file, or ZIP',filetypes=[('Save files','*.bin *.dat *.zip System'),('All files','*.*')])
  if not fp:
   folder=filedialog.askdirectory(title='Or select a Dolphin save-data folder',mustexist=True)
   if folder:fp=folder
  if not fp:return
  try:
   entry=None;path=Path(fp)
   if path.suffix.lower()=='.zip':
    choices=scan_save_zips(path,self.game_name if self.game_name=='SIIP' else None)
    if self.game_name!='SIIP':choices=[x for x in choices if x[1] in ('RZTP','RZTE')]
    if not choices:raise ValueError(f'No {self.game_name} Wii data.bin found inside this ZIP')
    if len(choices)>1:
     dlg=SelectZip(self,choices);self.wait_window(dlg)
     if not dlg.result:return
     entry=dlg.result
   self.open_document(path,entry)
  except Exception as ex:messagebox.showerror('Could not open save',str(ex),parent=self)
 def open_document(self,path,entry=None):
  doc=SaveDocument.open(path,self.game_name,entry)
  if self.game_name=='SIIP' and doc.game!='SIIP':raise ValueError('Please open a London 2012 / SIIP save')
  if self.game_name!='SIIP' and doc.game not in ('RZTP','RZTE'):raise ValueError('Please open a Wii Sports Resort / RZTP or RZTE save')
  self.doc=doc;self.info.set(f'{doc.game} | {doc.description} | {len(doc.entries)} entries | 0 edited files')
  self.on_load()
 def on_load(self):pass
 def refresh_info(self):
  if self.doc:self.info.set(f'{self.doc.game} | {self.doc.description} | {len(self.doc.entries)} entries | {self.doc.changes} edited file(s)')
 def reset(self):
  if not self.doc:return
  if messagebox.askyesno('Undo edits','Restore all loaded score values to their original bytes?',parent=self):
   self.doc.undo_all();self.on_load();self.refresh_info()
 def save_zip(self):
  if not self.doc:return messagebox.showinfo('No save','Open a save first.',parent=self)
  dest=filedialog.asksaveasfilename(title='Save edited Dolphin NAND ZIP',defaultextension='.zip',initialfile=f'{self.doc.game}_EDITED_Dolphin_NAND.zip',filetypes=[('ZIP archives','*.zip')])
  if not dest:return
  try:
   # save dialog may select pre-existing file; require user approval, then remove it before export.
   p=Path(dest)
   if p.exists():
    if not messagebox.askyesno('Replace output?','Replace existing OUTPUT ZIP? The original loaded save will remain untouched.',parent=self):return
    p.unlink()
   self.doc.export_nand_zip(p)
   messagebox.showinfo('Saved',f'Edited, decrypted Dolphin NAND archive:\n{p}\n\nBack up the existing NAND folder and extract Wii/ into your active Dolphin user directory.\nThis is NOT an SD data.bin.',parent=self)
  except Exception as ex:messagebox.showerror('Export failed',str(ex),parent=self)
 def save_dir(self):
  if not self.doc:return messagebox.showinfo('No save','Open a save first.',parent=self)
  folder=filedialog.askdirectory(title='Choose empty destination for edited Dolphin NAND files')
  if not folder:return
  try:
   dest=self.doc.export_nand_folder(folder)
   messagebox.showinfo('Saved',f'Save files written under:\n{dest}\n\nOriginal loaded save remains unchanged.',parent=self)
  except Exception as ex:messagebox.showerror('Export failed',str(ex),parent=self)

class LondonTab(BaseTab):
 def __init__(self,notebook,app):
  super().__init__(notebook,app,'SIIP')
  filters=ttk.Frame(self);filters.pack(fill='x',pady=(0,8))
  ttk.Label(filters,text='Profile / save slot:',style='Head.TLabel').pack(side='left')
  self.slot=tk.StringVar();self.slotbox=ttk.Combobox(filters,textvariable=self.slot,width=13,state='readonly')
  self.slotbox.pack(side='left',padx=10);self.slotbox.bind('<<ComboboxSelected>>',lambda e:self.render())
  self.show_non_numeric=tk.BooleanVar(value=False)
  ttk.Checkbutton(filters,text='Show 6 non-numeric event slots',variable=self.show_non_numeric,command=self.render).pack(side='left',padx=10)
  ttk.Label(filters,text='Times: m:ss.mmm',foreground='#617185').pack(side='left',padx=10)
  fr=ttk.Frame(self);fr.pack(fill='both',expand=True)
  columns=('index','event','type','offset','value','raw','status')
  self.tree=ttk.Treeview(fr,columns=columns,show='headings',selectmode='browse',height=17)
  for k,t,w in [('index','#',48),('event','Event',225),('type','Stored format',100),('offset','Offset',85),('value','Current score',190),('raw','Raw U16 pair',125),('status','Confidence',115)]:
   self.tree.heading(k,text=t);self.tree.column(k,width=w,anchor='w' if k=='event' else 'center')
  sb=ttk.Scrollbar(fr,orient='vertical',command=self.tree.yview);self.tree.configure(yscrollcommand=sb.set)
  self.tree.pack(side='left',fill='both',expand=True);sb.pack(side='right',fill='y')
  self.tree.tag_configure('tentative',foreground='#926219');self.tree.tag_configure('unknown',foreground='#7b8797')
  self.tree.bind('<Double-Button-1>',lambda _e:self.edit());self.tree.bind('<Return>',lambda _e:self.edit())
  actions=ttk.Frame(self);actions.pack(fill='x',pady=8,before=fr)
  ttk.Button(actions,text='Edit selected score…',command=self.edit,style='Accent.TButton').pack(side='left')
  ttk.Button(actions,text='Export editable CSV…',command=self.csv_export).pack(side='left',padx=8)
  ttk.Button(actions,text='Apply CSV edits…',command=self.csv_import).pack(side='left')
  ttk.Button(actions,text='Compare another save…',command=self.compare).pack(side='left',padx=9)
  ttk.Label(actions,text='Changes remain in memory until Save As.',foreground='#617185').pack(side='right')
 def on_load(self):
  if not self.doc:return
  vals=[f'Slot{s:02d}' for s in self.doc.slots]
  self.slotbox['values']=vals
  if self.slot.get() not in vals:self.slot.set(vals[-1])
  self.render()
 def render(self):
  self.tree.delete(*self.tree.get_children())
  if not self.doc or not self.slot.get():return
  slot=int(self.slot.get()[-2:])
  for e in range(LONDON_EVENT_COUNT):
   if EVENTS[e]['kind']=='nonrecord' and not self.show_non_numeric.get():continue
   whole,part=self.doc.london_raw(slot,e)
   meta=EVENTS[e];name=meta['name'];stat=meta['confidence'].title()
   tag=() if stat in ('Strong','Verified') else ('unknown',) if stat in ('Unknown','Unmapped') else ('tentative',)
   self.tree.insert('', 'end',iid=str(e),values=(f'{e:02d}',name,meta['typed_precision'],f'0x{LONDON_HEAD+LONDON_STRIDE*e:04X}',self.doc.london_compound(slot,e),f'{whole} / {part}',stat),tags=tag)
  self.refresh_info()
 def edit(self):
  if not self.doc:return
  sel=self.tree.selection()
  if not sel:return messagebox.showinfo('Select an event','Select a row first.',parent=self)
  e=int(sel[0]);s=int(self.slot.get()[-2:]);w,p=self.doc.london_raw(s,e)
  win=tk.Toplevel(self);win.title(f'Edit Slot{s:02d} Event {e:02d}');win.resizable(False,False);win.transient(self);win.grab_set()
  f=ttk.Frame(win,padding=20);f.pack(fill='both',expand=True)
  ttk.Label(f,text=LONDON_EVENTS.get(e,'Unknown record field'),style='Title.TLabel').grid(row=0,column=0,columnspan=3,sticky='w')
  ttk.Label(f,text=f'Slot{s:02d} • Event {e:02d} • offset 0x{LONDON_HEAD+LONDON_STRIDE*e:04X}',foreground='#5e7785').grid(row=1,column=0,columnspan=3,sticky='w',pady=(1,15))
  dec=tk.StringVar(value=self.doc.london_human(s,e) if p<1000 else f'{w}.{p:03d}')
  whole=tk.StringVar(value=str(w));frac=tk.StringVar(value=str(p))
  ttk.Label(f,text=('Whole-number points (or edit raw fields)' if e in INTEGER_POINTS else 'Score (m, pts, seconds or m:ss.mmm; 0.001 precision)')).grid(row=2,column=0,columnspan=3,sticky='w')
  entry=ttk.Entry(f,textvariable=dec,width=32,font=('Consolas',12));entry.grid(row=3,column=0,columnspan=3,sticky='we',pady=(3,8));entry.focus_set()
  ttk.Button(f,text='Apply decimal',command=lambda:self.apply_edit(win,s,e,dec.get(),False),style='Accent.TButton').grid(row=4,column=0,columnspan=3,sticky='ew',pady=(0,18))
  ttk.Separator(f,orient='horizontal').grid(row=5,column=0,columnspan=3,sticky='ew',pady=(0,13))
  ttk.Label(f,text='Raw unsigned 16-bit components (use for unknown formats)').grid(row=6,column=0,columnspan=3,sticky='w')
  ttk.Label(f,text='Whole U16').grid(row=7,column=0,sticky='w')
  ttk.Label(f,text='Fraction U16').grid(row=7,column=1,sticky='w',padx=12)
  ttk.Entry(f,textvariable=whole,width=16).grid(row=8,column=0,sticky='w')
  ttk.Entry(f,textvariable=frac,width=16).grid(row=8,column=1,sticky='w',padx=12)
  ttk.Button(f,text='Apply raw pair',command=lambda:self.apply_edit(win,s,e,(whole.get(),frac.get()),True)).grid(row=8,column=2,padx=8)
  ttk.Label(f,text=('Confidence: '+EVENTS[e]['confidence']+' — '+EVENTS[e]['evidence'])[:104],foreground='#926219').grid(row=9,column=0,columnspan=3,pady=(15,0))
  if e==SHOOTING_EVENT:
   ttk.Separator(f,orient='horizontal').grid(row=10,column=0,columnspan=3,sticky='ew',pady=(12,8))
   ttk.Label(f,text='Shooting completion time (IN-GAME VERIFIED; separate from points)',foreground='#895b1d').grid(row=11,column=0,columnspan=3,sticky='w')
   time=tk.StringVar(value=self.doc.london_shooting_time(s))
   ttk.Entry(f,textvariable=time,width=24,font=('Consolas',12)).grid(row=12,column=0,columnspan=2,sticky='w',pady=(4,0))
   ttk.Button(f,text='Apply time only',command=lambda:self.apply_shooting_time(win,s,e,time.get()),style='Accent.TButton').grid(row=12,column=2,sticky='ew',padx=6)
   ttk.Label(f,text='Verified Slot03: 480 pts / 0:11.290. Field: 0x2F18–0x2F1B (seconds + milliseconds).',foreground='#895b1d').grid(row=13,column=0,columnspan=3,sticky='w',pady=(4,0))
  f.columnconfigure(0,weight=1)
 def apply_shooting_time(self,win,s,e,val):
  try:self.doc.london_patch_shooting_time(s,val)
  except Exception as ex:return messagebox.showerror('Invalid Shooting time',str(ex),parent=win)
  win.destroy();self.render();self.tree.selection_set(str(e));self.tree.see(str(e))
 def apply_edit(self,win,s,e,val,raw):
  try:
   if raw:self.doc.london_patch_raw(s,e,int(val[0],0) if str(val[0]).lower().startswith('0x') else int(val[0]),int(val[1],0) if str(val[1]).lower().startswith('0x') else int(val[1]))
   else:self.doc.london_patch_typed(s,e,val)
  except Exception as ex:return messagebox.showerror('Invalid score',str(ex),parent=win)
  win.destroy();self.render();self.tree.selection_set(str(e));self.tree.see(str(e))
 def csv_export(self):
  if not self.doc:return
  fp=filedialog.asksaveasfilename(title='Export London record CSV',defaultextension='.csv',initialfile='London2012_all_profiles_EDITABLE.csv',filetypes=[('CSV','*.csv')])
  if not fp:return
  try:
   with open(fp,'w',encoding='utf-8-sig',newline='') as f:
    w=csv.writer(f);w.writerow(['slot','event','event_name','score','shooting_time','formatted_readonly','format','raw_whole','raw_fraction','confidence','record_direction','notes'])
    for sl in self.doc.slots:
     for ev in range(LONDON_EVENT_COUNT):
      a,b=self.doc.london_raw(sl,ev);m=EVENTS[ev]
      editable=m['kind']!='nonrecord' and b<1000
      w.writerow([sl,ev,m['name'],(str(a) if ev in INTEGER_POINTS else f'{a}.{b:03d}') if editable else '',self.doc.london_shooting_time(sl) if ev==SHOOTING_EVENT else '',self.doc.london_compound(sl,ev),m['kind'],a,b,m['confidence'],m['better'],m['evidence']])
   messagebox.showinfo('CSV exported','Change values in the score column, then use Apply CSV edits.\nThe file does not include private full save data.',parent=self)
  except Exception as ex:messagebox.showerror('CSV export error',str(ex),parent=self)
 def csv_import(self):
  if not self.doc:return
  fp=filedialog.askopenfilename(title='Select edited scores CSV',filetypes=[('CSV','*.csv')]);
  if not fp:return
  try:
   with open(fp,encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
   if not rows or not {'slot','event','score'} <= set(rows[0]):raise ValueError('CSV must contain slot,event,score columns')
   # Validate all edits before applying; old R3 CSVs without shooting_time still import.
   proposed=[]; seen=set()
   for row in rows:
    raw=(row.get('score') or '').strip()
    rawtime=(row.get('shooting_time') or '').strip()
    if not raw and not rawtime:continue
    sl=int(row['slot']);ev=int(row['event'])
    if sl not in self.doc.slots or not 0<=ev<LONDON_EVENT_COUNT:raise ValueError(f'Invalid slot/event: {sl}/{ev}')
    if raw:
     if EVENTS[ev]['kind']=='nonrecord':
      if raw!=self.doc.london_display(sl,ev):raise ValueError(f'Event {ev} is unverified/non-scoring. Use raw U16 editing.')
     else:
      target=parse_typed(ev,raw)
      if self.doc.london_raw(sl,ev)!=target:
       key=('score',sl,ev)
       if key in seen:raise ValueError(f'Duplicate edited row: {key}')
       seen.add(key);proposed.append(('score',sl,ev,target))
    if rawtime:
     if ev!=SHOOTING_EVENT:raise ValueError('shooting_time column must be empty except event 12')
     pair=parse_shooting_time(rawtime)
     if self.doc.london_shooting_time_raw(sl)!=pair:
      key=('time',sl,ev)
      if key in seen:raise ValueError(f'Duplicate edited row: {key}')
      seen.add(key);proposed.append(('time',sl,ev,pair))
   if not proposed:return messagebox.showinfo('CSV','No changed scores found.',parent=self)
   if not messagebox.askyesno('Apply batch edits',f'Apply {len(proposed)} changed records from CSV to the loaded save (in memory)?',parent=self):return
   for typ,sl,ev,target in proposed:
    if typ=='time':self.doc.london_patch_shooting_time_raw(sl,*target)
    else:self.doc.london_patch_raw(sl,ev,*target)
   self.render();messagebox.showinfo('Applied',f'{len(proposed)} score fields updated. Use Save As to export.',parent=self)
  except Exception as ex:messagebox.showerror('CSV import error',str(ex),parent=self)
 def compare(self):
  if not self.doc:return
  fp=filedialog.askopenfilename(title='Compare with another London 2012 save',filetypes=[('Wii save','*.bin *.zip'),('All files','*.*')])
  if not fp:return
  try:
   second=SaveDocument.open(Path(fp),'SIIP')
   dif=[]
   for s in sorted(set(self.doc.slots)&set(second.slots)):
    for e in range(31):
     a=self.doc.london_compound(s,e);b=second.london_compound(s,e)
     if a!=b:dif.append(f'Slot{s:02d} | {e:02d} {LONDON_EVENTS.get(e,"unknown"):<25} | {a:>11} -> {b}')
   win=tk.Toplevel(self);win.title('London record comparison');win.geometry('790x530')
   text=tk.Text(win,wrap='none',font=('Consolas',10));text.pack(fill='both',expand=True)
   text.insert('1.0',f'{len(dif)} differing record fields (loaded → chosen)\n\n'+'\n'.join(dif));text.configure(state='disabled')
  except Exception as ex: messagebox.showerror('Compare failed',str(ex),parent=self)

from WSR_Labeled_Tab import ResortLabeledTab

class ResortTab(BaseTab):
 def __init__(self,notebook,app):
  super().__init__(notebook,app,'RZTP')
  banner=ttk.Label(self,text='Wii Sports Resort: raw score finder / editor. Known number encodings, game checksum repaired automatically. Event address mapping is still incomplete.',wraplength=1090,foreground='#88551b')
  banner.pack(fill='x',pady=(0,8))
  self.status=tk.StringVar(value='No file loaded')
  header=ttk.Frame(self);header.pack(fill='x',pady=(0,10))
  ttk.Label(header,textvariable=self.status,style='Head.TLabel').pack(side='left')
  ttk.Label(header,text='   Export game region:').pack(side='left')
  self.region=tk.StringVar(value='RZTP')
  region_combo=ttk.Combobox(header,textvariable=self.region,values=['RZTP','RZTE'],state='readonly',width=7)
  region_combo.pack(side='left',padx=7)
  region_combo.bind('<<ComboboxSelected>>',lambda _e:self.set_region())
  tools=ttk.LabelFrame(self,text='Search for a stored score',padding=10);tools.pack(fill='x')
  r=ttk.Frame(tools);r.pack(fill='x')
  ttk.Label(r,text='Value:').pack(side='left')
  self.search_text=tk.StringVar(value='1000');ttk.Entry(r,textvariable=self.search_text,width=18).pack(side='left',padx=7)
  ttk.Label(r,text='Interpret as:').pack(side='left')
  self.dtype=tk.StringVar(value='U16 BE');self.dtypebox=ttk.Combobox(r,values=list(TYPE_FORMATS),state='readonly',width=16,textvariable=self.dtype);self.dtypebox.pack(side='left',padx=7)
  ttk.Button(r,text='Find in Sports2.dat',command=self.search,style='Accent.TButton').pack(side='left')
  ttk.Label(r,text='Golf scores: S16 BE, canoe times: U16 / 100, some modes: U16 / 10.',foreground='#587487').pack(side='left',padx=14)
  outer=ttk.Frame(self);outer.pack(fill='both',expand=True,pady=9)
  self.tree=ttk.Treeview(outer,columns=('off','hex','u16','s16','u32'),show='headings',height=10)
  for key,label,width in [('off','Offset',130),('hex','Raw bytes',210),('u16','U16',110),('s16','S16',110),('u32','U32',135)]:
   self.tree.heading(key,text=label);self.tree.column(key,width=width,anchor='center')
  scroll=ttk.Scrollbar(outer,orient='vertical',command=self.tree.yview);self.tree.configure(yscrollcommand=scroll.set)
  self.tree.pack(side='left',fill='both',expand=True);scroll.pack(side='right',fill='y')
  self.tree.bind('<Double-Button-1>',lambda _e:self.select_result());self.tree.bind('<<TreeviewSelect>>',lambda _e:self.select_result())
  lf=ttk.LabelFrame(self,text='Edit selected offset (read raw byte location; save as copy)',padding=12);lf.pack(fill='x',before=outer)
  r=ttk.Frame(lf);r.pack(fill='x')
  ttk.Label(r,text='Offset (hex):').pack(side='left')
  self.offset=tk.StringVar(value='0x20');ttk.Entry(r,textvariable=self.offset,width=17).pack(side='left',padx=7)
  ttk.Label(r,text='Stored format:').pack(side='left')
  self.write_type=tk.StringVar(value='U16 BE');self.wbox=ttk.Combobox(r,values=list(TYPE_FORMATS),state='readonly',width=17,textvariable=self.write_type);self.wbox.pack(side='left',padx=7)
  self.wbox.bind('<<ComboboxSelected>>',lambda _e:self.read_at_offset())
  ttk.Button(r,text='Read here',command=self.read_at_offset).pack(side='left')
  ttk.Label(r,text='New value:').pack(side='left',padx=(14,0))
  self.newvalue=tk.StringVar();ttk.Entry(r,textvariable=self.newvalue,width=18).pack(side='left',padx=7)
  ttk.Button(r,text='Apply + repair CRC32',command=self.apply,style='Accent.TButton').pack(side='left',padx=6)
  self.preview=tk.StringVar(value='')
  ttk.Label(lf,textvariable=self.preview,foreground='#476176').pack(anchor='w',pady=(8,0))
  bar=ttk.Frame(self);bar.pack(fill='x',pady=8,before=outer)
  ttk.Button(bar,text='Compare another Sports2.dat…',command=self.compare).pack(side='left')
  ttk.Label(bar,text='Use your other backup for candidate verification before changing an offset.',foreground='#617185').pack(side='left',padx=10)
 def set_region(self):
  if self.doc:
   self.doc.game=self.region.get()
   self.on_load()
 def on_load(self):
  if not self.doc:return
  self.region.set(self.doc.game)
  is_ok,saved,computed=resort_validate(self.doc.resort_bytes())
  self.status.set(f'Sports2.dat: {len(self.doc.resort_bytes()):,} bytes | CRC32 {"VALID" if is_ok else "INVALID"} | 0x{saved:08X} | {self.doc.game}')
  self.tree.delete(*self.tree.get_children());self.read_at_offset();self.refresh_info()
  if hasattr(self.app,'resort_mii'):self.app.resort_mii.attach_document(self.doc)
  if hasattr(self.app,'resort_named'):self.app.resort_named.attach_document(self.doc)
 def parse_offset(self):
  s=self.offset.get().strip().lower()
  return int(s,16) if s.startswith('0x') or any(c in s for c in 'abcdef') else int(s)
 def read_at_offset(self):
  if not self.doc:return
  try:
   o=self.parse_offset();t=self.write_type.get()
   n=TYPE_FORMATS[t][0];b=self.doc.resort_bytes()
   current=self.doc.resort_read(o,t)
   self.preview.set(f'Offset 0x{o:06X} | bytes {b[o:o+n].hex(" ").upper()} | interpreted: {current} | 0x0C CRC32 protected')
   self.newvalue.set(current)
  except Exception as ex:self.preview.set('Read error: '+str(ex))
 def fill_result(self,o):
  b=self.doc.resort_bytes()
  import struct
  raw=b[o:o+4].ljust(4,b'\x00')
  u16=struct.unpack_from('>H',raw)[0];s16=struct.unpack_from('>h',raw)[0];u32=struct.unpack_from('>I',raw)[0]
  return (f'0x{o:06X}',raw.hex(' ').upper(),u16,s16,u32)
 def search(self):
  if not self.doc:return
  try:
   offsets,total=self.doc.resort_search(self.search_text.get().strip(),self.dtype.get())
   self.tree.delete(*self.tree.get_children())
   for ix,o in enumerate(offsets):self.tree.insert('', 'end',iid=f'{ix}',values=self.fill_result(o))
   self.status.set(f'{total:,} match(es), showing {len(offsets)}. File CRC {"OK" if resort_validate(self.doc.resort_bytes())[0] else "INVALID"}.')
  except Exception as ex:messagebox.showerror('Invalid search',str(ex),parent=self)
 def select_result(self):
  choice=self.tree.selection()
  if not choice:return
  off=self.tree.item(choice[0],'values')[0]
  self.offset.set(off);self.write_type.set(self.dtype.get());self.read_at_offset()
 def apply(self):
  if not self.doc:return
  try:
   o=self.parse_offset();fmt=self.write_type.get();nv=self.newvalue.get()
   if not messagebox.askyesno('Apply record edit',f'Write {nv} as {fmt} at offset 0x{o:X}?\nThe Sports2.dat checksum will be updated.\nYou can still undo everything before saving.',parent=self):return
   self.doc.resort_patch(o,fmt,nv)
   self.on_load()
  except Exception as ex:messagebox.showerror('Could not edit',str(ex),parent=self)
 def compare(self):
  if not self.doc:return
  fp=filedialog.askopenfilename(title='Compare with another Resort backup',filetypes=[('Save files','*.dat *.bin *.zip'),('All files','*.*')]);
  if not fp:return
  try:
   other=SaveDocument.open(Path(fp),None)
   if other.game=='SIIP':raise ValueError('Not a Wii Sports Resort save')
   a=self.doc.resort_bytes();b=other.resort_bytes();diff=[i for i,(x,y) in enumerate(zip(a,b)) if x!=y]
   win=tk.Toplevel(self);win.title('WSR byte comparison');win.geometry('760x500')
   t=tk.Text(win,wrap='none',font=('Consolas',10));t.pack(fill='both',expand=True)
   t.insert('1.0',f'{len(diff)} different byte(s) of {len(a)} — first 200 offsets\n\n'+ '\n'.join(f'0x{j:06X}  {a[j]:02X} → {b[j]:02X}' for j in diff[:200]));t.configure(state='disabled')
  except Exception as ex:messagebox.showerror('Compare failed',str(ex),parent=self)

class ResortMiiTab(ttk.Frame):
 """Exploratory named-Mii browser; shares ResortTab's SaveDocument in memory."""
 def __init__(self,notebook,app):
  super().__init__(notebook,padding=14);self.app=app;self.doc=None;self.miis=[]
  ttk.Label(self,text='Resort Mii records — experimental field map',style='Head.TLabel').pack(anchor='w')
  ttk.Label(self,text='Names and 0xDF4 player stride are verified on PAL + US saves. The adjacent 75 entries contain 16-bit skill-like numbers, but their event/history identities are NOT yet decoded. The third byte is preserved.',foreground='#88551b',wraplength=1050).pack(anchor='w',pady=(3,11))
  row=ttk.Frame(self);row.pack(fill='x',pady=(0,9))
  ttk.Label(row,text='Mii:',style='Head.TLabel').pack(side='left')
  self.player=tk.StringVar();self.pbox=ttk.Combobox(row,textvariable=self.player,state='readonly',width=43)
  self.pbox.pack(side='left',padx=8);self.pbox.bind('<<ComboboxSelected>>',lambda _e:self.render())
  self.summary=tk.StringVar(value='Open a Resort save through Game Library / Resort first.')
  ttk.Label(row,textvariable=self.summary,foreground='#476176').pack(side='left',padx=8)
  f=ttk.Frame(self);f.pack(fill='both',expand=True)
  col=('no','offset','value','extra','status')
  self.tree=ttk.Treeview(f,columns=col,show='headings',height=11,selectmode='browse')
  for k,label,w in [('no','#',55),('offset','Hex offset',115),('value','16-bit value',140),('extra','Extra byte (hex)',155),('status','Interpretation',330)]:
   self.tree.heading(k,text=label);self.tree.column(k,width=w,anchor='center')
  self.tree.pack(side='left',fill='both',expand=True)
  scroll=ttk.Scrollbar(f,orient='vertical',command=self.tree.yview);scroll.pack(side='right',fill='y');self.tree.configure(yscrollcommand=scroll.set)
  self.tree.bind('<<TreeviewSelect>>',lambda _e:self.select_entry())
  line=ttk.Frame(self);line.pack(fill='x',pady=(8,4))
  ttk.Label(line,text='Selected 16-bit value:').pack(side='left')
  self.entry_value=tk.StringVar()
  ttk.Entry(line,textvariable=self.entry_value,width=12).pack(side='left',padx=7)
  ttk.Button(line,text='Apply experimental edit + CRC32',command=self.apply_skill).pack(side='left')
  ttk.Button(line,text='Export these 75 entries to CSV…',command=self.export_candidates).pack(side='left',padx=9)
  search=ttk.LabelFrame(self,text='Find a known in-game score within selected Mii’s 3,572-byte record (candidate offsets only)',padding=8)
  search.pack(fill='x',pady=(6,4)); r=ttk.Frame(search);r.pack(fill='x')
  self.score=tk.StringVar(value='129.93');self.scale=tk.StringVar(value='100');self.tolerance=tk.StringVar(value='0')
  for lbl,var,width in [('Displayed score:',self.score,10),('Stored scale:',self.scale,6),('± tolerance:',self.tolerance,7)]:
   ttk.Label(r,text=lbl).pack(side='left',padx=(6,2));ttk.Entry(r,textvariable=var,width=width).pack(side='left',padx=(0,7))
  ttk.Button(r,text='Find candidates',command=self.scan_score).pack(side='left')
  self.match_summary=tk.StringVar(value='Example: Stray Ducklings 2:09.93 = 129.93 seconds, potentially /100; exact storage remains unknown.')
  ttk.Label(search,textvariable=self.match_summary,foreground='#617185',wraplength=1060).pack(anchor='w',pady=(4,0))
  self.results=ttk.Treeview(search,columns=('off','raw','value'),show='headings',height=4,selectmode='browse')
  for k,txt,w in [('off','Candidate hex offset',185),('raw','Raw U16',120),('value','Value at chosen scale',240)]:
   self.results.heading(k,text=txt);self.results.column(k,width=w,anchor='center')
  self.results.pack(fill='x',pady=(4,4))
  ttk.Button(search,text='Send selected offset to Resort raw editor…',command=self.send_offset).pack(anchor='e')
 def attach_document(self,doc):
  if doc and doc.game in ('RZTP','RZTE'):
   from WSR_Player_Layout import parse_miis
   self.doc=doc;self.miis=parse_miis(doc.resort_bytes())
   self.pbox['values']=[f'{p.index:02d}  {p.name}' for p in self.miis]
   self.player.set(self.pbox['values'][0] if self.miis else '')
   self.render()
 def current_mii(self):
  if not self.doc or not self.miis:return None
  key=self.player.get()
  return next((p for p in self.miis if key==f'{p.index:02d}  {p.name}'),None)
 def render(self):
  from WSR_Player_Layout import value_rows
  self.tree.delete(*self.tree.get_children());self.results.delete(*self.results.get_children())
  p=self.current_mii()
  if not p:return
  rows=value_rows(self.doc.resort_bytes(),p.index)
  for r in rows:
   self.tree.insert('','end',iid=str(r['index']),values=(r['index'],f'0x{r["offset"]:06X}',r['value'],f'0x{r["extra"]:02X}','skill-like candidate' if r['possible_skill'] else 'out-of-range/raw'))
  self.summary.set(f'{len(self.miis)} named profiles · Mii #{p.index} · name offset 0x{p.name_offset:X} · data 0x{p.value_offset:X}')
  self.entry_value.set('');self.app.resort.refresh_info()
 def select_entry(self):
  p=self.current_mii();s=self.tree.selection()
  if not p or not s:return
  row=self.tree.item(s[0],'values');self.entry_value.set(str(row[2]))
 def apply_skill(self):
  from WSR_Player_Layout import patch_candidate
  p=self.current_mii();s=self.tree.selection()
  if not p or not s:return
  try:
   n=int(s[0]);value=int(self.entry_value.get())
   if not messagebox.askyesno('Experimental skill-like entry',f'Mii {p.name}, entry {n}: set 16-bit value to {value}?\nThis field has NOT been assigned a sport; its extra byte will remain unchanged.\nEdited copy only; Resort CRC32 will be repaired.',parent=self):return
   from Wii_Score_Studio_Core import resort_fix_checksum
   patch_candidate(self.doc.resort_bytes(),p.index,n,value,resort_fix_checksum)
   chosen=self.player.get();self.app.resort.on_load();self.player.set(chosen);self.render();self.tree.selection_set(str(n));self.tree.see(str(n))
  except Exception as ex:messagebox.showerror('Could not edit',str(ex),parent=self)
 def export_candidates(self):
  from WSR_Player_Layout import value_rows
  p=self.current_mii()
  if not p:return
  fn=filedialog.asksaveasfilename(title='Export Mii values',defaultextension='.csv',initialfile=f'WSR_Mii_{p.index:02d}_candidates.csv',filetypes=[('CSV','*.csv')])
  if not fn:return
  try:
   if Path(fn).exists() and not messagebox.askyesno('Overwrite CSV?', 'Replace existing CSV output?',parent=self):return
   with open(fn,'w',encoding='utf-8-sig',newline='') as f:
    w=csv.writer(f);w.writerow(['Mii index','Mii name','Value index','Hex offset','U16 BE','Extra byte','Status'])
    for v in value_rows(self.doc.resort_bytes(),p.index):w.writerow([p.index,p.name,v['index'],f'0x{v["offset"]:X}',v['value'],f'0x{v["extra"]:02X}','unmapped skill-like candidate'])
   messagebox.showinfo('Exported',f'Saved 75 candidate entries for Mii {p.name}.',parent=self)
  except Exception as ex:messagebox.showerror('CSV export error',str(ex),parent=self)
 def scan_score(self):
  from WSR_Player_Layout import candidates_for_score
  from decimal import Decimal
  p=self.current_mii()
  if not p:return
  try:
   raw=self.score.get().strip()
   if ':' in raw:
    m,ss=raw.split(':',1);raw=str(Decimal(int(m)*60)+Decimal(ss))
   results,total=candidates_for_score(self.doc.resort_bytes(),p.index,raw,int(self.scale.get()),self.tolerance.get())
   self.results.delete(*self.results.get_children())
   for j,v in enumerate(results):self.results.insert('','end',iid=str(j),values=(f'0x{v["offset"]:06X}',v['raw'],v['display']))
   self.match_summary.set(f'{total} candidate(s) in {p.name}’s record; displaying first {len(results)}. Candidate only: confirm with a controlled save difference or in-game validation.')
  except Exception as ex:messagebox.showerror('Candidate scan failed',str(ex),parent=self)
 def send_offset(self):
  s=self.results.selection()
  if not s:return
  off=self.results.item(s[0],'values')[0]
  self.app.resort.offset.set(off)
  self.app.resort.write_type.set('U16 / 100' if self.scale.get()=='100' else 'U16 / 10' if self.scale.get()=='10' else 'U16 BE')
  self.app.resort.read_at_offset();self.app.nb.select(self.app.resort)

class GameLibraryTab(ttk.Frame):
 """Index title folders; send only recognized games to an existing editor tab."""
 def __init__(self,notebook,app):
  super().__init__(notebook,padding=14);self.app=app;self.discovered=[]
  heading=ttk.Frame(self);heading.pack(fill='x',pady=(0,10))
  ttk.Label(heading,text='Choose one root folder to discover all its Wii saves',style='Head.TLabel').pack(anchor='w')
  ttk.Label(heading,text='SD: private/wii/title/   or   Dolphin NAND: User/Wii/title/. Supports a game ID folder, title folder, SD root or Dolphin User root.',foreground='#587487',wraplength=1100).pack(anchor='w',pady=(4,0))
  row=ttk.Frame(self);row.pack(fill='x',pady=(3,12))
  self.root=tk.StringVar(value=get_saved_library_path())
  ttk.Entry(row,textvariable=self.root).pack(side='left',fill='x',expand=True,padx=(0,7))
  ttk.Button(row,text='Browse folder…',command=self.browse).pack(side='left',padx=3)
  ttk.Button(row,text='Scan saves',command=self.scan,style='Accent.TButton').pack(side='left',padx=3)
  self.summary=tk.StringVar(value='Select your Wii save root, then Scan saves. Unsupported games are listed without modification.')
  ttk.Label(self,textvariable=self.summary,foreground='#475d71',wraplength=1100).pack(anchor='w',pady=(0,9))
  fr=ttk.Frame(self);fr.pack(fill='both',expand=True)
  self.tree=ttk.Treeview(fr,columns=('name','gameid','source','status','size','files'),show='headings',height=12,selectmode='browse')
  for col,title,w in [('name','Game / save',285),('gameid','Game ID',100),('source','Save type',140),('status','Editor availability',210),('size','Size',96),('files','Files',70)]:
   self.tree.heading(col,text=title)
   self.tree.column(col,width=w,anchor='w' if col in ('name','status') else 'center')
  sy=ttk.Scrollbar(fr,orient='vertical',command=self.tree.yview);self.tree.configure(yscrollcommand=sy.set)
  self.tree.pack(side='left',fill='both',expand=True);sy.pack(side='right',fill='y')
  self.tree.bind('<<TreeviewSelect>>',lambda _ev:self._update_path())
  self.tree.bind('<Double-Button-1>',lambda _ev:self.open_selected())
  self.tree.bind('<Return>',lambda _ev:self.open_selected())
  action=ttk.Frame(self);action.pack(fill='x',pady=(8,7))
  ttk.Button(action,text='Open selected save',command=self.open_selected,style='Accent.TButton').pack(side='left')
  ttk.Button(action,text='Copy selected path',command=self.copy_path).pack(side='left',padx=7)
  self.file_info=tk.StringVar(value='')
  ttk.Label(self,textvariable=self.file_info,foreground='#536d81',wraplength=1150).pack(anchor='w',pady=(0,7))
  backlog=ttk.Labelframe(self,text='Future game research — not yet editable',padding=8)
  backlog.pack(fill='x',pady=(4,0))
  ttk.Label(backlog,text='Mario Party 8/9 · Rayman · Fortune Street · Virtua Tennis 2009 · Wii Sports training & fitness · Wii Play (editable) · Wii Fit · Galaxy 2 · DKCR · Kirby',foreground='#536777',wraplength=990).pack(side='left',fill='x',expand=True)
  ttk.Button(backlog,text='View full research backlog…',command=self.show_backlog).pack(side='right',padx=(10,0))

 def show_backlog(self):
  win=tk.Toplevel(self);win.title('Wii Score Studio — planned game research');win.geometry('810x430');win.transient(self)
  ttk.Label(win,text='These games are research candidates, not enabled editors.',style='Head.TLabel').pack(anchor='w',padx=16,pady=12)
  fr=ttk.Frame(win);fr.pack(fill='both',expand=True,padx=14,pady=(0,12))
  tree=ttk.Treeview(fr,columns=('game','focus','status'),show='headings')
  for col,label,width in [('game','Game',245),('focus','Research target',395),('status','Status',150)]:
   tree.heading(col,text=label);tree.column(col,width=width,anchor='w')
  sy=ttk.Scrollbar(fr,orient='vertical',command=tree.yview);tree.configure(yscrollcommand=sy.set)
  tree.pack(side='left',fill='both',expand=True);sy.pack(side='right',fill='y')
  for game,focus,status in BACKLOG:tree.insert('', 'end',values=(game,focus,status))

 def browse(self):
  folder=filedialog.askdirectory(title='Select private/wii/title, Dolphin User/Wii/title, or a parent directory',mustexist=True)
  if folder:self.root.set(folder);self.scan()

 def scan(self):
  path=self.root.get().strip()
  if not path:
   return messagebox.showinfo('Select a folder','Choose your SD private folder, Dolphin User folder, or title folder.',parent=self)
  try:
   results=scan_save_folder(path)
  except (OSError,ValueError) as e:
   return messagebox.showerror('Scan failed',str(e),parent=self)
  self.discovered=results
  self.tree.delete(*self.tree.get_children())
  for i,r in enumerate(results):
   self.tree.insert('', 'end', iid=str(i), values=(r.label,r.game_id,r.kind,r.status,r.pretty_size,r.file_count))
  editable=sum(bool(r.editor) for r in results)
  self.summary.set(f'{len(results)} Wii save(s) found • {editable} supported save(s) • {len(results)-editable} research-only title(s). The source folders are read-only in this scanner.')
  self.file_info.set('Double-click an editable save to open the appropriate editor. The save stays untouched until you export a new copy.')
  if results:self.tree.selection_set('0');self._update_path()
  try:set_saved_library_path(path)
  except OSError:
   # Save discovery still works on locked down Windows folders.
   pass

 def _selected(self):
  sel=self.tree.selection()
  if not sel:return None
  idx=int(sel[0]);return self.discovered[idx] if 0<=idx<len(self.discovered) else None

 def _update_path(self):
  r=self._selected()
  if r:self.file_info.set(f'{r.game_id} • {r.title_type} • {r.path}')

 def copy_path(self):
  r=self._selected()
  if r:self.clipboard_clear();self.clipboard_append(str(r.path))

 def open_selected(self):
  r=self._selected()
  if not r:
   return messagebox.showinfo('Select a save','Select a discovered save first.',parent=self)
  if r.editor is None:
   return messagebox.showinfo('Research-only game',f'Found game ID {r.game_id} at:\n{r.path}\n\nIts save format is not mapped yet. No files have been modified.',parent=self)
  self.app.open_library_save(r)


class WiiSportsOriginalTab(BaseTab):
 """Experimental, checksum-corrected original Wii Sports float32 skill editor.

 Mii identity is shown by index and raw IDs, not guessed names. Training and
 Wii Fitness fields are *not* edited until mapped separately.
 """
 def __init__(self,notebook,app):
  super().__init__(notebook,app,'RSPP')
  from WS_Original import SKILLS
  ttk.Label(self,text='Original Wii Sports: 100 Mii slots. Only the five float32 skill fields are currently mapped. Mii IDs are shown instead of guessing names.',wraplength=1110,foreground=WARN).pack(anchor='w',pady=7)
  f=ttk.Frame(self);f.pack(fill='both',expand=True)
  self.tree=ttk.Treeview(f,columns=('index','status','mii','system',*SKILLS),show='headings',height=17)
  for col,width in [('index',60),('status',65),('mii',130),('system',130)]+[(x,105) for x in SKILLS]:
   self.tree.heading(col,text=col);self.tree.column(col,width=width,anchor='center')
  sy=ttk.Scrollbar(f,orient='vertical',command=self.tree.yview);self.tree.configure(yscrollcommand=sy.set)
  self.tree.pack(side='left',fill='both',expand=True);sy.pack(side='right',fill='y')
  row=ttk.Frame(self);row.pack(fill='x',pady=12)
  ttk.Label(row,text='Sport:').pack(side='left')
  self.sport=tk.StringVar(value='Tennis')
  ttk.Combobox(row,textvariable=self.sport,values=list(SKILLS),width=18,state='readonly').pack(side='left',padx=6)
  ttk.Button(row,text='Edit selected Mii skill…',command=self.edit,style='Accent.TButton').pack(side='left',padx=10)
  ttk.Button(row,text='Set selected sport to verified maximum',command=self.maximum).pack(side='left')
  ttk.Button(row,text='Set all five verified maxima',command=self.allmax).pack(side='left',padx=10)
  ttk.Label(self,text='Enter decimal or exact float32 bits (0x4515FFF6). The exported save is a Dolphin NAND ZIP, not an SD data.bin. Skill changes are NOT yet in-game verified.',wraplength=1110).pack(anchor='w')
 def open_save(self):
  fp=filedialog.askopenfilename(parent=self,title='Choose original Wii Sports save (RSPP / RSPE)',filetypes=[('Wii save','*.bin *.dat *.zip'),('All','*.*')])
  if not fp:
   folder=filedialog.askdirectory(parent=self,title='Or choose decrypted Wii Sports NAND folder')
   if folder:fp=folder
  if not fp:return
  try:
   path=Path(fp);entry=None
   if path.suffix.lower()=='.zip':
    choices=[x for x in scan_save_zips(path) if x[1] in ('RSPP','RSPE')]
    if not choices:raise ValueError('No original Wii Sports data.bin in the selected ZIP')
    if len(choices)>1:
     dlg=SelectZip(self,choices);self.wait_window(dlg)
     if not dlg.result:return
     entry=dlg.result
   self.open_document(path,entry)
  except Exception as e:messagebox.showerror('Cannot load Wii Sports',str(e),parent=self)
 def open_document(self,path,entry=None):
  self.doc=SaveDocument.open(Path(path),'RSPP',entry)
  if self.doc.game not in ('RSPP','RSPE'):raise ValueError('Not original Wii Sports')
  self.on_load();self.refresh_info()
 def on_load(self):
  self.tree.delete(*self.tree.get_children())
  if not self.doc:return
  from WS_Original import player_info
  b=self.doc._file('RPSports.dat')
  for i in range(100):
   p=player_info(b,i)
   if not p['active']:continue
   vals=[str(int(p['skill_float32'][x])) if p['skill_float32'][x]<1000000 else f'{p["skill_float32"][x]:.6g}' for x in ('Tennis','Baseball','Bowling','Golf','Boxing')]
   self.tree.insert('', 'end',iid=str(i),values=(i,p['status'],p['mii_id_hex'],p['system_id_hex'],*vals))
 def selected(self):
  if not self.doc:raise ValueError('Open original Wii Sports save first')
  sel=self.tree.selection()
  if not sel:raise ValueError('Select a Mii entry first')
  return int(sel[0])
 def edit(self):
  try:
   from WS_Original import patch_skill,player_info
   idx=self.selected();sport=self.sport.get()
   p=player_info(self.doc._file('RPSports.dat'),idx)
   old=p['skill_bits'][sport]
   val=simpledialog.askstring('Edit float32 skill',f'Mii {idx}: {sport}\nCurrent: {p["skill_float32"][sport]} ({old})\n\nEnter decimal or 0xXXXXXXXX bits:',parent=self)
   if val is None:return
   result=patch_skill(self.doc._file('RPSports.dat'),idx,sport,val)
   self.on_load();self.tree.selection_set(str(idx));self.refresh_info()
  except Exception as e:messagebox.showerror('Edit failed',str(e),parent=self)
 def maximum(self):
  try:
   from WS_Original import patch_skill,MAX_KNOWN
   idx=self.selected();sp=self.sport.get()
   if not messagebox.askyesno('Confirm skill edit',f'Set Mii slot {idx} {sp} to verified maximum float32 bits 0x{MAX_KNOWN[sp]:08X}?',parent=self):return
   patch_skill(self.doc._file('RPSports.dat'),idx,sp,hex(MAX_KNOWN[sp]))
   self.on_load();self.tree.selection_set(str(idx));self.refresh_info()
  except Exception as e:messagebox.showerror('Edit failed',str(e),parent=self)
 def allmax(self):
  try:
   from WS_Original import patch_skill,MAX_KNOWN,SKILLS
   idx=self.selected()
   if not messagebox.askyesno('Confirm five skill edits',f'Set all five float32 skill fields for Mii slot {idx} to their experimentally confirmed maxima?\n\nMii identity and other saved fields stay untouched.',parent=self):return
   for sp in SKILLS:patch_skill(self.doc._file('RPSports.dat'),idx,sp,hex(MAX_KNOWN[sp]))
   self.on_load();self.tree.selection_set(str(idx));self.refresh_info()
  except Exception as e:messagebox.showerror('Edit failed',str(e),parent=self)

class WiiPlayTab(BaseTab):
 """Editable Wii Play scores per Mii and minigame. Status bytes preserved."""
 def __init__(self,notebook,app):
  super().__init__(notebook,app,'RHAP')
  from WP_Play import GAMES
  ttk.Label(self,text='Wii Play: nine games, each with five ranked scores per Mii. Editing automatically repairs the save checksum. Medal/status bytes are preserved. In-game acceptance still needs testing.',foreground=WARN,wraplength=1100).pack(anchor='w',pady=(0,8))
  top=ttk.Frame(self);top.pack(fill='x',pady=5)
  ttk.Label(top,text='Mii record:').pack(side='left')
  self.mii=tk.StringVar()
  self.mii_box=ttk.Combobox(top,textvariable=self.mii,state='readonly',width=56)
  self.mii_box.pack(side='left',padx=8)
  self.mii_box.bind('<<ComboboxSelected>>',lambda _e:self.render())
  ttk.Label(top,text='Game:').pack(side='left',padx=(12,1))
  self.sport=tk.StringVar(value=GAMES[0])
  self.sport_box=ttk.Combobox(top,textvariable=self.sport,values=list(GAMES),state='readonly',width=20)
  self.sport_box.pack(side='left',padx=8)
  self.sport_box.bind('<<ComboboxSelected>>',lambda _e:self.render())
  ttk.Label(top,text='Top five saved scores (rank 1 = best)',foreground='#5e7785').pack(side='left')
  fr=ttk.Frame(self);fr.pack(fill='both',expand=True)
  self.tree=ttk.Treeview(fr,columns=('rank','score','offset'),show='headings',height=10)
  for col,width in [('rank',110),('score',170),('offset',155)]:
   self.tree.heading(col,text=col.title());self.tree.column(col,width=width,anchor='center')
  self.tree.pack(side='left',fill='both',expand=True)
  row=ttk.Frame(self);row.pack(fill='x',pady=10)
  ttk.Button(row,text='Edit selected rank…',command=self.edit,style='Accent.TButton').pack(side='left')
  ttk.Button(row,text='New top score (shift old top five down)…',command=self.top_score).pack(side='left',padx=10)
  self.state_label=tk.StringVar(value='')
  ttk.Label(self,textvariable=self.state_label,foreground=WARN,wraplength=1050).pack(anchor='w')
 def open_save(self):
  fp=filedialog.askopenfilename(parent=self,title='Open Wii Play save',filetypes=[('Wii save','*.zip *.bin *.dat'),('All files','*.*')])
  if not fp:
   fp=filedialog.askdirectory(parent=self,title='Or choose decrypted Wii Play NAND folder')
  if not fp:return
  try:
   path=Path(fp);entry=None
   if path.suffix.lower()=='.zip':
    choices=[x for x in scan_save_zips(path) if x[1] in ('RHAP','RHAE')]
    if not choices:raise ValueError('No Wii Play SD data.bin in this archive')
    if len(choices)>1:
     dlg=SelectZip(self,choices);self.wait_window(dlg)
     if not dlg.result:return
     entry=dlg.result
   self.open_document(path,entry)
  except Exception as ex:messagebox.showerror('Cannot open Wii Play',str(ex),parent=self)
 def open_document(self,path,entry=None):
  d=SaveDocument.open(Path(path),'RHAP',entry)
  if d.game not in ('RHAP','RHAE'):raise ValueError('Not Wii Play')
  self.doc=d;self.on_load();self.refresh_info()
 def on_load(self):
  from WP_Play import active_players,player_identity
  if not self.doc:return
  b=self.doc._file('RPParty.dat')
  values=[f'{idx:02d} | {player_identity(b,idx)}' for idx in active_players(b)]
  self.mii_box['values']=values
  if self.mii.get() not in values:self.mii.set(values[0] if values else '')
  self.render()
 def selected(self):
  from WP_Play import GAMES
  if not self.doc or not self.mii.get():raise ValueError('Open a Wii Play save and choose a Mii')
  return int(self.mii.get().split('|')[0].strip()),GAMES.index(self.sport.get())
 def render(self):
  self.tree.delete(*self.tree.get_children())
  if not self.doc or not self.mii.get():return
  from WP_Play import read_scores,score_offset,read_status
  idx,game=self.selected();blob=self.doc._file('RPParty.dat')
  scores=read_scores(blob,idx,game)
  for rank,score in enumerate(scores):
   self.tree.insert('','end',iid=str(rank),values=(rank+1,score,f'0x{score_offset(idx,game,rank):04X}'))
  self.state_label.set(f'Raw status for this game: {read_status(blob,idx,game)} (not editable or conclusively decoded). Changes are in memory until Save As.')
  self.refresh_info()
 def edit(self):
  try:
   from WP_Play import read_scores,patch_score
   idx,g=self.selected();sel=self.tree.selection()
   if not sel:raise ValueError('Select one of the five ranked results')
   rank=int(sel[0]);blob=self.doc._file('RPParty.dat')
   val=simpledialog.askinteger('Edit Wii Play result',f'Current rank {rank+1}: {read_scores(blob,idx,g)[rank]}\nEnter replacement (0–4,294,967,295):',initialvalue=read_scores(blob,idx,g)[rank],minvalue=0,maxvalue=4294967295,parent=self)
   if val is None:return
   patch_score(blob,idx,g,rank,val);self.render();self.tree.selection_set(str(rank))
  except Exception as ex:messagebox.showerror('Wii Play edit failed',str(ex),parent=self)
 def top_score(self):
  try:
   from WP_Play import read_scores,patch_score
   idx,g=self.selected();b=self.doc._file('RPParty.dat');old=read_scores(b,idx,g)
   val=simpledialog.askinteger('New Wii Play top result',f'Current best {old[0]}\nEnter new best (higher is better):',initialvalue=old[0]+1,minvalue=0,maxvalue=4294967295,parent=self)
   if val is None:return
   if val<=old[0]:raise ValueError('This button inserts a higher best score; use Edit selected rank to lower it')
   for rank,v in enumerate(([val]+old[:4])):patch_score(b,idx,g,rank,v)
   self.render();self.tree.selection_set('0')
  except Exception as ex:messagebox.showerror('Wii Play edit failed',str(ex),parent=self)

class App(tk.Tk):
 def __init__(self):
  super().__init__();self.title('Wii Score Studio R10 — Wii Play + Wii Sports + Resort + London');self.geometry('1270x865');self.minsize(950,690)
  style=ttk.Style(self)
  try:style.theme_use('clam')
  except:pass
  style.configure('TFrame',background=MAIN_BG);style.configure('TLabel',background=MAIN_BG,font=FONT,foreground=FG)
  style.configure('Head.TLabel',font=('Segoe UI',11,'bold'))
  style.configure('Title.TLabel',font=('Segoe UI',17,'bold'))
  style.configure('TButton',font=FONT,padding=(11,7));style.configure('Accent.TButton',background=ACC,foreground='#ffffff',font=('Segoe UI',10,'bold'))
  style.map('Accent.TButton',background=[('active','#065e68')])
  style.configure('Treeview',font=('Segoe UI',10),rowheight=25);style.configure('Treeview.Heading',font=('Segoe UI',10,'bold'))
  style.configure('TLabelframe',background=MAIN_BG);style.configure('TLabelframe.Label',background=MAIN_BG,font=('Segoe UI',10,'bold'))
  style.configure('TNotebook',background=MAIN_BG);style.configure('TNotebook.Tab',font=('Segoe UI',11,'bold'),padding=(18,10))
  top=ttk.Frame(self,padding=(22,16));top.pack(fill='x')
  ttk.Label(top,text='Wii Score Studio',style='Title.TLabel').pack(anchor='w')
  ttk.Label(top,text='London 2012 checksum repair • reversible editing • Dolphin NAND export • Resort CRC32 repair',foreground='#587487').pack(anchor='w',pady=(3,0))
  self.nb=ttk.Notebook(self);self.nb.pack(fill='both',expand=True,padx=12,pady=(0,12))
  self.library=GameLibraryTab(self.nb,self);self.london=LondonTab(self.nb,self);self.resort=ResortTab(self.nb,self);self.resort_named=ResortLabeledTab(self.nb,self);self.wii_sports=WiiSportsOriginalTab(self.nb,self);self.wii_play=WiiPlayTab(self.nb,self)
  self.nb.add(self.library,text='Game Library — auto-detect saves')
  self.nb.add(self.london,text='London 2012 — four save slots');self.nb.add(self.resort,text='Wii Sports Resort — score finder');self.nb.add(self.resort_named,text='Resort — Scores / Skills / Stamps');self.nb.add(self.wii_sports,text='Wii Sports — Float32 Skills');self.nb.add(self.wii_play,text='Wii Play — Nine Games')
  bottom=ttk.Label(self,text='Edits are never applied to the loaded source. Export an edited NAND ZIP/folder, copy into a BACKED-UP Dolphin user directory, then test in game.',foreground='#476176',padding=(17,8),wraplength=1200)
  bottom.pack(fill='x')
  if self.library.root.get() and Path(self.library.root.get()).is_dir():
   self.after_idle(self.library.scan)

 def open_library_save(self,location):
  # New formats can add another editor tab + one registry entry without changing the scanner.
  editor_tabs={'London 2012':self.london,'Wii Sports Resort':self.resort,'Wii Sports original':self.wii_sports,'Wii Play':self.wii_play}
  tab=editor_tabs.get(location.editor)
  if tab is None: return
  try:
   tab.open_document(location.path)
   self.nb.select(tab)
  except Exception as err:
   messagebox.showerror('Could not open the selected save',str(err),parent=self)

if __name__=='__main__':
 App().mainloop()
